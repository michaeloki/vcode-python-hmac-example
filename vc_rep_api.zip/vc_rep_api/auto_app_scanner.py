""" Generate a report by scanning all the apps/services in production especially the ones not scanned in the last 90 days"""
#Use veracode's API to start
import csv
import sys
import requests
import argparse

from veracode_api_signing.plugin_requests import RequestsAuthPluginVeracodeHMAC

from datetime import datetime

api_base = "https://eu.veracode.com/api/1.0/scans"

headers = {"User-Agent": "VCApiPipeline"}

tag = "Security"

formatted_datetime = ""

generic_page_number = 0

def api_call():
    print("Running the API...")
    # Get profile IDs and use it to make the API Call