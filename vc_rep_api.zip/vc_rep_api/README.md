# vc-report-api

This project calls the Veracode API for report generation. The generated report can be found in the report folder.

# Local installation
Run `sh scripts/install.sh && sh scripts/vc_report.sh --arg1 "$VERACODE_API_KEY_ID" --arg2 "$VERACODE_API_KEY_SECRET"`
