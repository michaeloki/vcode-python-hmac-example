import csv
import sys
import requests
import argparse

from veracode_api_signing.plugin_requests import RequestsAuthPluginVeracodeHMAC

from datetime import datetime

api_base = "https://api.veracode.com"

headers = {"User-Agent": "VCApiPipeline"}

tag = "Security"

formatted_datetime = ""

generic_page_number = 0

def get_summary_report(guid: str, app_name: str, key_id: str, secret: str):
    try:
        response = (requests.get
                    (api_base + "/appsec/v2/applications/" + guid + "/summary_report?policy_compliance_checked_after"
                                                                    "=2024-05-10T08:23:59.000Z",
                     auth=RequestsAuthPluginVeracodeHMAC
                     (api_key_id=key_id,
                      api_key_secret=secret),
                     headers=headers))
    except requests.RequestException as rex:
        print("Static scan failed with " + str(rex))
        sys.exit(1)

    if response.ok:
        data = response.json()
        #check the response payload
        try:
            all_findings = data["_embedded"]["findings"]
            num_of_findings = len(all_findings)
            print(f"findings size {num_of_findings}")
            for index in range(num_of_findings):
                status = data["_embedded"]["findings"][index]["finding_status"]["status"]
                print(f"status is {status} for {app_name}")
                if status.upper() == "OPEN":
                    first_found = data["_embedded"]["findings"][index]["finding_status"]["first_found_date"]
                    last_seen = data["_embedded"]["findings"][index]["finding_status"]["last_seen_date"]
                    cwe_id = data["_embedded"]["findings"][index]["finding_details"]["cwe"]["id"]
                    cwe = data["_embedded"]["findings"][index]["finding_details"]["cwe"]["name"]
                    severity = data["_embedded"]["findings"][index]["finding_details"]["severity"]

                    with open('summary_reports.csv', 'a', newline='') as f:
                        summary_writer = csv.writer(f)
                        summary_writer.writerow([severity, "Generic", cwe, cwe_id, first_found, app_name])
        except Exception as ex:
            print("")
    else:
        print(f"Summary Report:::: {response.status_code}")


def get_sast_findings(guid: str, app_name: str, key_id: str, secret: str):
        print(f"====::::STATIC FINDINGS::::==== with GUID {guid} and app name {app_name}")
        try:
            response = (requests.get
                        (api_base + "/appsec/v2/applications/" + guid + "/findings?scan_type=STATIC&status=UNRESOLVED"
                                                                        "&severity_gte=4",
                         auth=RequestsAuthPluginVeracodeHMAC
                         (api_key_id=key_id,
                          api_key_secret=secret),
                         headers=headers))
        except requests.RequestException as re:
            print("Static scan failed with " + str(re))
            sys.exit(1)

        if response.ok:
            data = response.json()
            try:
                all_findings = data["_embedded"]["findings"]
                num_of_findings = len(all_findings)
                print("Checking " + str(num_of_findings) + " SAST findings(s)")
                for index in range(len(all_findings)):
                    status = data["_embedded"]["findings"][index]["finding_status"]["status"]
                    if status.upper() == "OPEN" or status.upper() == "UNRESOLVED":
                        first_found = data["_embedded"]["findings"][index]["finding_status"]["first_found_date"]
                        last_seen = data["_embedded"]["findings"][index]["finding_status"]["last_seen_date"]
                        cwe_id = data["_embedded"]["findings"][index]["finding_details"]["cwe"]["id"]
                        cwe = data["_embedded"]["findings"][index]["finding_details"]["cwe"]["name"]
                        severity = data["_embedded"]["findings"][index]["finding_details"]["severity"]
                        if severity == 3:
                            severity_desc = "Medium"
                        elif severity == 4:
                            severity_desc = "High"
                        else:
                            severity_desc = "Critical"

                        with open('sast.csv', 'a', newline='') as sast_file:
                            sast_writer = csv.writer(sast_file)
                            sast_writer.writerow([severity_desc, "SAST", cwe, cwe_id, first_found, app_name])
            except Exception as e:
                print("SAST EXCEPTION experienced " + str(e))
        else:
            print(f"get_findings:::: {response.status_code}")

            print(f"content is {response.content}")


def get_sca_findings(guid: str, app_name: str, key_id: str, secret: str):
    try:
        response = (requests.get
                    (api_base + "/appsec/v2/applications/" + guid + "/findings?scan_type=SCA&severity_gte=3",
                     auth=RequestsAuthPluginVeracodeHMAC
                     (api_key_id=key_id,
                      api_key_secret=secret),
                     headers=headers))
    except requests.RequestException as re:
        print("Static scan failed with " + str(re))
        sys.exit(1)

    if response.ok:
        data = response.json()
        try:
            all_findings = data["_embedded"]["findings"]
            num_of_findings = len(all_findings)
            print("Checking " + str(num_of_findings) + " SCA findings(s)")
            severity_desc = ""
            for index, app in enumerate(all_findings):
                scan_type = app['scan_type']
                res_status = app['finding_status']['resolution']
                if scan_type == "SCA" and res_status != "RESOLVED":
                    severity = app['finding_details']['severity']
                    cwe_id = app['finding_details']['cwe']['id']
                    cwe_name = app['finding_details']['cwe']['name']
                    lib_name = app["finding_details"]["component_filename"]
                    lib_ver = app["finding_details"]["version"]
                    first_found = app["finding_status"]["first_found_date"]
                    last_seen = app["finding_status"]["last_seen_date"]
                    if severity == 3:
                        severity_desc = "Medium"
                    elif severity == 4:
                        severity_desc = "High"
                    elif severity == 5:
                        severity_desc = "Critical"
                    with open("monthly_sca_reports.csv", 'a', newline='') as csv_file:
                        csv_writer = csv.writer(csv_file)
                        csv_writer.writerow(
                            [severity_desc, "SCA", cwe_name, cwe_id, first_found, last_seen, app_name, lib_name,
                             lib_ver])

        except Exception as e:
            print("SCA EXCEPTION experienced " + str(e))
    else:
        print(f"SCA HTTP Error:::: {response.status_code}")


def get_app_by_tag(key_id: str, secret: str, page_number: int, current_date: str):
    print("Get app by tag..")
    try:
        tag_response = (requests.get
                        (api_base + "/appsec/v1/applications?page=" + str(page_number) + "&size=200",
                         auth=RequestsAuthPluginVeracodeHMAC
                         (api_key_id=key_id,
                          api_key_secret=secret),
                         headers=headers))
        if tag_response.ok:
            data = tag_response.json()
            all_findings = data["_embedded"]["applications"]
            num_of_findings = len(all_findings)
            print(f"The Number of app profiles is {num_of_findings}")
            for index, appx in enumerate(all_findings):
                get_sca_findings(appx["guid"], appx["profile"]["name"], key_id, secret)
        else:
            print(f"tag response content is not OK {tag_response.content}")
    except requests.RequestException as re:
        print("Static scan failed with " + str(re))
        sys.exit(1)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--arg1", type=str, help="First string argument:key_id")
    parser.add_argument("--arg2", type=str, help="Second string argument:secret")

    args = parser.parse_args()

    try:
        current_datetime = datetime.now()
        formatted_datetime = current_datetime.strftime('%d_%m_%Y_%H_%M_%S')
        with open("monthly_sca_reports.csv", 'a', newline='') as static_file:
            static_writer = csv.writer(static_file)
            static_writer.writerow(
                ["Description", "SCA", "CWE", "CWE ID", "First found", "Last found", "Profile", "Component",
                 "Version"])
        get_app_by_tag(args.arg1, args.arg2, generic_page_number, formatted_datetime)
    except requests.RequestException as e:
        print("Critical Exception!")
        print(e)
        sys.exit(1)
