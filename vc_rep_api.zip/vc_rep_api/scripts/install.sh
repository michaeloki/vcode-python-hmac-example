#!/bin/bash

echo "A little housekeeping"
key_id=$1
secret=$2

if python3 --version &>/dev/null; then
    pip3_check=$(whereis pip3)
    if [ -z "$pip3_check" ]; then
      apt-get -y install python3-venv python-pip-whl python3-distutils python3-lib2to3 python3.9-venv > /dev/null 2>&1
    fi
    if python3 -m pip list | grep -i requests; then
      python3 -m venv vcenv
      source vcenv/bin/activate
      sh scripts/vc_report.sh "$key_id" "$secret"
      deactivate
    else
      echo "Installing dependencies..."
      apt-get -y install python3-venv python-pip-whl python3-distutils python3-lib2to3 python3.9-venv > /dev/null 2>&1
      python3 -m venv vcenv
      source vcenv/bin/activate
      pwd
      echo "About to install py dependencies "
      pip3 install -r requirements.txt -q
      if [ $? -eq 0 ]; then
        if pip3 list | grep -q requests; then
          sh scripts/vc_report.sh "$key_id" "$secret"
          deactivate
        fi
      else
        echo "Error installing required packages: $?"
      fi
    fi
else
  echo "Python 3 is not installed. Please install Python 3 first."
  exit 1
fi
