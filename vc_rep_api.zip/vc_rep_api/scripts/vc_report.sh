#!/bin/bash
echo "This script will call the Veracode APIs"

key_id=$1
secret=$2

report_runner() {
  if [ -z "$key_id" ] || [ -z "$secret" ]; then
    echo "The required parameters are missing"
  else
    pip3 install -r requirements.txt -q
    if [ $? -eq 0 ]; then
      echo "About to generate the report"
      python3 monthly_report.py --arg1 "$key_id" --arg2 "$secret"
    else
      echo "Error installing package: $?"
    fi
  fi
}

report_runner
