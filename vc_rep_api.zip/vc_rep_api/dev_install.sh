#!/bin/bash
source vcenv/bin/activate
# sh scripts/install.sh
python3 monthly_report.py --arg1 "d321efc528ac779caf5811224fde7ec5" --arg2 "1ffc8053aa059d3ef6697b43e9c53c1df58677c536f511ec9184110d7fcb57a5817e177516d1098e236cabf1221cce31468052f54d49015527501d891c8ba817"
