#!/bin/bash
source generic_response.sh

# Meta data.
gitlab_short_name="$(basename "$(dirname "$CALLING_CI_PROJECT_PATH")")/$(basename "$CALLING_CI_PROJECT_PATH")"
project_name="${gitlab_short_name}[gl${CALLING_CI_PROJECT_ID}]"
short_sha=$(git rev-parse --short "${CALLING_CI_COMMIT_SHA}")
scanTypeMsg="internal_dep_scan"

# Is this a master-branch commit triggered scan ?
[ "$CALLING_SCAN_MASTER_BRANCH" != "" ] && master_branch=$CALLING_SCAN_MASTER_BRANCH || master_branch="master"
is_master_commit=
[ "$CALLING_CI_COMMIT_BRANCH" == "$master_branch" ] && is_master_commit=1
echo "Current dir for local_dependency_check_wrapper is $(pwd)"
[ ! $is_master_commit ] && echo "No master-ish branch commit. No need for scan." && echo "SKIP SCAN" > "$CALLING_CI_COMMIT_SHA".txt && exit 0
#[ ! $is_master_commit ] && echo "No master-ish branch commit. No need for scan." && echo "current dir is $(pwd)" && exit 0



# Fetch artifacts.
url="${CI_API_V4_URL}/projects/${source_ci_project_id}/jobs/${source_ci_job_id}/artifacts"
output=$(curl --location --fail --output artifacts.zip --header "PRIVATE-TOKEN: $GL_SECURITY_PAT" \
  "$url" 2>&1) || stop_feedback "Unable to fetch artifacts from [${url}]: \n ${output}" "$scanTypeMsg"
unzip artifacts.zip -d ./artifacts | tac | tac
[ "${PIPESTATUS[0]}" -ne 0 ] && stop_feedback "Unable to unzip artifacts archive" "$scanTypeMsg"
[ -f artifacts/.npmrc ] && rm -f artifacts/.npmrc


# Scan.
output=$(local_dependency_check/dep_analysis.cli.js \
  --path=artifacts \
  --blocklist=deps_blocklist.yml \
  --format=csv | tee violating_deps.csv 2>&1)
status=${PIPESTATUS[0]}

# Problem.
[ $status -ne 0 ] && [ $status -ne 2 ] && stop_feedback "$output" "$scanTypeMsg"

if [ $status -eq 0 ]; then
  # No issues found; report empty csv to close old findings.
  csv='"Date","Title","CweId","Url","Severity","Description","Mitigation","Impact","References","Active","Verified"'"\n"
  echo -e "$csv" > violating_deps.csv
fi

# Report to DD.
output=$(./dd_import_report.sh "violating_deps.csv" "$project_name" \
  "Generic Findings Import" "internal_dep_scan_${short_sha}" "internal_dep_scan" 2>&1) || stop_feedback "$output" "$scanTypeMsg"

# Convert findings-found status code (2) to ok (0).
exit 0
