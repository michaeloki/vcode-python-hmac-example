#!/bin/bash
#eXPORT XML file name in codeAnalysis
#Source it here and check the file
# Read the XML file
xml_file="report.xml"

# Extract the severity value
severity=$(xmlstarlet sel -t -v "//finding/severity" $xml_file)

# Print the severity value
echo "Severity: $severity"