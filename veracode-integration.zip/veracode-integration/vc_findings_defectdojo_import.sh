#!/bin/bash
source generic_response.sh
scanTypeMsg="import:sast_results_to_defectdojo"
# prerequisites:
# - debian/ubuntu
# - curl, xmllint
# - java
app_name=
# Check integration stuff.
# [ -z $CI_API_V4_URL ] && echo "No Gitlab API defined" && exit 1
[ "$DD_API_KEY" = "" ] && stop_feedback "Wrapper: No API key defined for defectdojo ($DD_API_KEY)" "$scanTypeMsg"
[ "$MAX_CONCURRENT_IMPORTS" = "" ] && MAX_CONCURRENT_IMPORTS=3

# Defaults
my_dir=$(cd "$(dirname "$0")" && pwd)
export basepwd=$PWD
problem_file="${basepwd}/.vc_dd_import_kaput"

# Setup veracode API.
source "${my_dir}/_api.sh"

function push_report_to_dd() {
  _app_name=$1
  _report_file=$2
  "${my_dir}/vc_dd_import_scan.sh" "$_report_file" "$_app_name" &
}

function hold_until_process_room() {
  while true; do
    _jobnr=$(jobs -r | grep Running | wc -l)
    [ $_jobnr -lt $MAX_CONCURRENT_IMPORTS ] && break
    sleep 1
  done
}

# Fetch all latest detailed reports for all apps in account.
echo "Fetching all latest detailed XML reports for account. Might take quite a while."
outputf=./reports
api alldetailedreports -onlylatest true -outputfolderpath "$outputf" >/dev/null
[ $? -ne 0 ] && stop_feedback "ERROR fetching all latest reports" "$scanTypeMsg"
_nr=$(ls -l "$outputf" | wc -l)
echo "Need to import [$_nr] reports"

for f in "$outputf"/*.xml; do
    hold_until_process_room

    app_id=
    app_id=$(xmllint --xpath "string(//*[local-name()='detailedreport']/@app_id)" "$f")
    app_name=$(xmllint --xpath "string(//*[local-name()='detailedreport']/@app_name)" "$f")
    push_report_to_dd "${app_name}" "${f}"
done

# Wait for jobs to finish.
echo "Waiting for all import-jobs to finish..."
SECONDS=0
while true; do
  proc=$(jobs -r | grep "Running")
  [ "$proc" = "" ] && break
  sleep 1
done
echo "done"


[ -f "$problem_file" ] && stop_feedback "One of the import-jobs failed" "$scanTypeMsg"
