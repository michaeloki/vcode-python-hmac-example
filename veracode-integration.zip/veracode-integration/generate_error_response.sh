#!/bin/bash
# This status_text will be set to FAIL when the raw output from Veracode CLI in the analysis stage is used as a fallback option in the next MR
status_text="PASS"
summary_text=$1
app_name="unknown project"
filename="pipeline_generic_message.txt"
python3 file_generator.py --arg1 "$status_text" --arg2 "$summary_text" --arg3 "$app_name" --arg4 "$filename"
