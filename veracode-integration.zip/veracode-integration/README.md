# Veracode Integration

This project exposes a pipeline trigger that is to be used from application projects.
See https://gitlab.payconiq.io/DEV/commons/gitlab-ci-templates/-/blob/master/README.md on how to use that.

_Note, to edit the allow/block list, please fork the project and propose a merge-request._

## Blacklist / whitelist projects
Use the blacklist (`scan_projects_blacklist`) to prevent projects from being scanned.
Since this allows regex patterns, use the whitelist (`scan_projects_whitelist`) to scan projects that
fall in a blacklisted pattern.

The system first checks against the blacklist, and then (if something is blacklisted) against the whitelist.

Regex patterns are allowed (without `^` and `$`).

_Please note that the [security-coverage-miner](https://gitlab.payconiq.io/sre/devops/security/security-coverage-miner/) has the same behavior,
based on both files in the repository._

## Blacklisting Criteria:

When excluding repositories from CI security scanners, consider the following criteria:

**Exclude helper or API repositories:** Exclude repositories that contain code that is not directly related to the application's security, such as utility functions or third-party libraries. These repositories may not provide any valuable information related to the security of the application and may only serve to slow down the scan or generate false positives **(this third-party componentes will be checked manually quaterly)**.

**Exclude non-code repositories:** Exclude repositories that do not contain any code, such as documentation or build scripts.

**Exclude non-executed code repositories:** Exclude repositories that contain code that is not executed at runtime, such as test code.

example: https://gitlab.payconiq.io/DEV/Currence/ideal-gateway-commons/

**Review excluded repositories:** Before excluding a repository from the CI security scan, review the contents to ensure that it does not contain any sensitive or security-critical code that could potentially introduce a security vulnerability.

To blacklist a repository, add it to the [BLACKLIST](https://gitlab.payconiq.io/sec/veracode-integration/-/blob/master/scan_projects_blacklist) for the CI security scanner being used. Make sure to document the reason for blacklisting the repository and the date it was added to the exclusion list.

By following these criteria for blacklisting repositories, you can ensure that the CI security scanner is only analysing code that is relevant to the application's security and that it is not wasting time scanning irrelevant code or generating false positives.

## Open source license violations

This project also scans for license violations. The use of high risk (too restrictive) license might have
legal implications.

To add licenses or libraries to the allowlist or blocklist, edit (fork/MR) [OS_license.yml](https://gitlab.payconiq.io/sec/vc_js_utils/-/blob/master/OS_license.yml).
Refer to https://spdx.org/licenses/ for the correct identifiers.
To allow a library, use format `[vendor].[library]`, for example `socketio.engine.io-parser`.

Note that if a used library has any license which is on the allow list, it is _not_ reported as an issue.

## Operational / dev info

### Input params (env)

|Parameter|Required|Input|
|-|-|-|
|CI_JOB_URL|x|Used in report messages|
|CI_API_V4_URL|x|Gitlab base URL|
|GL_SECURITY_PAT|x|Gitlab personal access token to interact with GL API's|
|CALLING_CI_JOB_TOKEN|x|Useful to download artifact from job. Not used atm.|
|CALLING_CI_JOB_ID|x|Needed to download artifact|
|CALLING_CI_PIPELINE_ID|x|Used to label veracode build|
|CALLING_CI_PROJECT_ID|x|Used to download artifact and post feedback messages to MR|
|CALLING_CI_PROJECT_NAME|x|Project name to map gitlab / veracode|
|CALLING_CI_COMMIT_BRANCH|x|This influences scan type|
|CALLING_CI_COMMIT_SHA|x|Used to label veracode build / sandbox|
|CALLING_CI_MERGE_REQUEST_IID||If present, we post feedback messages to the MR|
|CALLING_SCAN_IOS_BCA||If present, this provides the relative path of the (iOS) .bca file (or .zip containing .bca file + `Podfile.lock`) in the job artifact|
|CALLING_SCAN_ANDR_APK||If present, this provides the relative path of the (Android) .apk file in the job artifact|
|CALLING_SCAN_MASTER_BRANCH||If present, this overrides the assumed master-branch, to trigger policy scans|
|VERACODE_GUIDING_DOC_URL||If present, overrides the documentation URL in the MR feedback messages|
|VERACODE_DEFAULT_TEAM||Define a default team name for new projects. Defaults to `IT_Dept`|
|CVSS_THRESHOLD||If present, overrides the default threshold of 7. Vulnerable dependencies with CVE's higher than this yield a warning in the MR feedback message|
|WAIT_TIMEOUT_SEC||Overrides the default timeout (3200 seconds) to wait for veracode reports|

### CI diagram
![veracode-integration](veracode_ci.png)

### Test / try the veracode API

Use this to easily setup API interaction in your terminal,
mostly similar to what you see in `codeAnalysis.sh`:

```shell script
export VERACODE_API_KEY_ID=[ID, generate in VC]
export VERACODE_API_KEY_SECRET=[API key, generate in VC]

export basepwd=$PWD
VERACODE_WRAPPER_VERSION=$(curl -sS "https://repo1.maven.org/maven2/com/veracode/vosp/api/wrappers/vosp-api-wrappers-java/maven-metadata.xml" | xmllint --xpath "/metadata/versioning/release/text()" -)
curl -sS -o "${basepwd}/veracode-wrapper.jar" "https://repo1.maven.org/maven2/com/veracode/vosp/api/wrappers/vosp-api-wrappers-java/${VERACODE_WRAPPER_VERSION}/vosp-api-wrappers-java-${VERACODE_WRAPPER_VERSION}.jar"

function api() {
  java -jar "${basepwd}/veracode-wrapper.jar" -vid "$VERACODE_API_KEY_ID" -vkey "$VERACODE_API_KEY_SECRET" -action "$@"
}
```

After this you can interact with the API like this:
```shell script
api getapplist
```

Run `api` to get help info.  
VC's documentation on the API wrapper is here: https://help.veracode.com/reader/orRWez4I0tnZNaA_i0zn9g/Zv3bRwDWR3__7bKptjEPhQ .

# Manually running gitleaks

This docker image can be used to run a gitleaks scan on any folder.

Note that the volume mount for veracode-integration assumes (so change it) a path.  
It's solely used to find the gitleaks config file.

```bash
docker run --rm \
  -v "$PWD":/app \
  -v $HOME/Projects/veracode-integration:/vc registry.acc.payconiq.io/security-ci-image:gitleaks \
  /usr/local/bin/gitleaks \
  --config /vc/gitleaks_conf.toml \
  --log-opts "-n 100" \
  --report-path /app/gitleaks-report.txt \
  --source /app
```

# Using local dependency analysis
This is a small custom node JS tool, specifically built to scan a maven or npm project for _internal_ dependencies
that were put on our blacklist.

Especially suitable for libraries developed by SRE Dev, so that we can prevent old and vulnerable versions from being used.

Build:
`cd local_dependency_check && npm install`

Run:
`local_dependency_check/dep_analysis.cli.js --path=/Users/reinier/Projects/security/old-merchant-portal-bff --blocklist=deps_blocklist.yml --format=csv`
