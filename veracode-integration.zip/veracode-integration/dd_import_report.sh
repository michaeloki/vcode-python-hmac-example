#!/bin/bash

# prerequisites:
# - debian/ubuntu
# - curl, jq

# Set DD_IMPORT_VERBOSE to not empty to echo API response.
scanTypeMsg=""
function unexpected_error () {
  msg=$1
  echo "$msg"
  if [ -f "pipeline_stage_tracker.txt" ]; then
    content=$(cat pipeline_stage_tracker.txt)
    modified_content=$(echo "$content" | jq '.scanType += ['\""$scanTypeMsg"\"']' )
    echo "$modified_content" > pipeline_stage_tracker.txt
    echo "The new content of pipeline_stage_tracker.txt is $modified_content"
  else
    json_object=$(echo '{}' | jq '. + {"status": "FAIL", "summary":'"$msg"', "appName": "", "scanType": ["'"$scanTypeMsg"'"], "message": "The analysis stage failed"}')
    echo "$json_object" > pipeline_stage_tracker.txt
    echo "No project namespace, a $json_object was successfully saved in $(pwd)"
  fi
  exit 1
}
# Check integration stuff.
[ "$DD_API_KEY" = "" ] && unexpected_error 'No API key defined for defectdojo (DD_API_KEY)'

REPORT_FILE=$1
DD_APP_NAME=$2
DD_REPORT_TYPE=$3
DD_ENGAGEMENT_NAME=$4
DD_IMPORT_TAG=$5

function print_usage() {
  echo "Usage: $0 [report file] [product-name] [scan-type] [engagement-name] [tag]"
  echo "  report file       : Filename to send to defectdojo. Put '-' to only generate an empty engagement"
  echo "  product-name      : The full name of the defectdojo product"
  echo "  scan-type         : e.g. 'Veracode Scan' or 'Gitleaks Scan'"
  echo "  engagement-name   : e.g. 'veracode_auto_import_eg95kj' or 'gitleaks_auto_import_eg95kj"
  echo "  tag               : (optional) tag to add to findings"
}
if [ "$REPORT_FILE" = "" ] || [ "$DD_APP_NAME" = "" ] \
  || [ "$DD_REPORT_TYPE" = "" ] || [ "$DD_ENGAGEMENT_NAME" = "" ]; then
    print_usage
    unexpected_error "There are some missing params REPORT_FILE: $REPORT_FILE, DD_APP_NAME: $DD_APP_NAME,
    DD_REPORT_TYPE: $DD_REPORT_TYPE, DD_ENGAGEMENT_NAME $DD_ENGAGEMENT_NAME"
fi
empty_engagement=
[ "$REPORT_FILE" = "-" ] && empty_engagement=1 && echo "No report, just creating an engagement [${DD_IMPORT_TAG}]."
[ ! -f "$REPORT_FILE" ] && [ ! $empty_engagement ] && unexpected_error "Report file doesn't exist: $REPORT_FILE"

# Default params
DD_API="https://dms.payconiq.io"
DD_DEFAULT_NEW_APP_DESCR="App. Automatically created because of veracode scan"
curl_opts=( "--silent" "-H"  "Authorization: Token ${DD_API_KEY}" "-H"  "accept: application/json" "-H" "Connection: keep-alive" "--keepalive-time" 2 )
DD_PRODUCT_TYPE="-to be determined-"

# Defaults
export basepwd=$PWD
pid=$$
my_dir=$(cd "$(dirname "$0")" && pwd)

function _print() {
  msg="  > [${pid}] "$1
  echo "$msg"
}

function _exit_error() {
  _print "$1"
  exit 1
}

# Echo external (gitlab) id from app-name if found.
function parseGlIdFromName() {
  _app_name=$1
  _external_id=$("${my_dir}/node_modules/.bin/vc_find_app_in_applist_xml" --id_from_name --app_name "$_app_name") \
    && echo "$_external_id"
}

# Echo legacy appname from full appname (including gitlab ID).
function parseLegacyNameFromFAN() {
  _app_name=$1
  _legacy_app_name=$("${my_dir}/node_modules/.bin/vc_find_app_in_applist_xml" --legacy_name_from_id --app_name "$_app_name") \
    && echo "$_legacy_app_name"
}

echo "Set DD_IMPORT_VERBOSE=1 to show DD's API response on report import"

if [ ! -d "$my_dir"/node_modules ]; then
  oldpwd=$PWD
  cd "$my_dir"
  _npm_out=$(npm install 2>&1)
  [ $? -ne 0 ] && _exit_error "Cannot install NPM packages; make sure to fix permissions or package.json:\n${_npm_out}".
  cd "$oldpwd"
fi

# Get DD product type ID by name.
product_type_id=
output_pt=$(curl "${DD_API}/api/v2/product_types/" \
  "${curl_opts[@]}" \
  --get \
  --data-urlencode "name=$DD_PRODUCT_TYPE" 2>/dev/null)
product_type_id=$(echo "${output_pt}" | jq -r ".results[0].id")
#output_pt=$(curl -X GET 'https://dms.payconiq.io/api/v2/product_types/' --header 'Authorization: Token '"${DD_API_KEY}"' ')
# echo "Raw response ${output_pt}"
#product_type_id=$(echo "$output_pt" | jq '.results[] | select(.name == "-to be determined-") | .id')

# Compare the old and new product IDs
#old_productid() {
#old_product_type_id=$(echo "${output_pt}" | jq -r ".results[0].id")
#echo "old product_id is $old_product_type_id"
#return $?
#}
#old_productid
# if ! old_productid; then
#   echo "Oops! Unable to get the old product Id"
# fi


echo "The product_type_id is ${product_type_id}"
if [ "$product_type_id" = "" ] || [ "$product_type_id" = "null" ]; then
  _exit_error "(error) Product-type with name ${DD_PRODUCT_TYPE} doesn't exist.\n${output_pt}"
fi

# Get DD product ID by appname, or create new one.
_print "Requesting product [${DD_APP_NAME}] from DefectDojo"
app_id=
dd_app_name_found=

# Find by Gitlab ID ?
external_id=$(parseGlIdFromName "$DD_APP_NAME")
echo "external_id is $external_id "
if [ "$external_id" != "" ]; then
  _print "Trying to find app based on gitlab ID [${external_id}]."
  output=$(curl "${DD_API}/api/v2/products/" \
    "${curl_opts[@]}" \
    --get \
    --data-urlencode "name=[${external_id}]" 2>/dev/null)
  app_id=$(echo "${output}" | jq -r ".results[] | select(.name | test(\"[${external_id}]\")).id")
  echo "app_id is $app_id"
  dd_app_name_found=$(echo "${output}" | jq -r ".results[] | select(.name | test(\"[${external_id}]\")).name")
  echo "dd_app_name_found is $dd_app_name_found"
fi

# Plan B: find by legacy name.
if [ "$app_id" = "" ] || [ "$app_id" = "null" ]; then
  legacy_app_name=$(parseLegacyNameFromFAN "$DD_APP_NAME")
  _print "App not found by Gitlab ID. Trying legacy name [${legacy_app_name}]."
  output=$(curl "${DD_API}/api/v2/products/" \
    "${curl_opts[@]}" \
    --get \
    --data-urlencode "name=${legacy_app_name}" 2>/dev/null)
  app_id=$(echo "${output}" | jq -r ".results[] | select(.name==\"${legacy_app_name}\").id")
  echo "app_id is $app_id by legacy name"
  dd_app_name_found=$(echo "${output}" | jq -r ".results[] | select(.name==\"${legacy_app_name}\").name")
  echo "dd_app_name_found is $dd_app_name_found by legacy name"
fi

# App found in DD, but not the same (anymore). Update it.
echo "App found in DD, but not the same (anymore), let's update it"
echo "app_id is $app_id, dd_app_name_found is $dd_app_name_found, DD_APP_NAME is $DD_APP_NAME "
if [ "$app_id" != "" ] && [ "$dd_app_name_found" != "" ] && [ "$dd_app_name_found" != "$DD_APP_NAME" ]; then
  _print "Update DefectDojo product: [${dd_app_name_found}] > [${DD_APP_NAME}]"
  output=$(curl -X PATCH "https://dms.payconiq.io/api/v2/products/${app_id}/" \
    "${curl_opts[@]}" \
    -H  "Content-Type: application/json" \
    -d "{  \"name\": \"${DD_APP_NAME}\"}") \
      && _print "Updated DD product name"
fi

# Still not found. Create it.
if [ "$app_id" = "" ] || [ "$app_id" = "null" ]; then
  # App doesn't exist (yet).
  _print "Product [${DD_APP_NAME}] doesn't exist, creating now"
  output=$(curl -X POST "https://dms.payconiq.io/api/v2/products/" \
    "${curl_opts[@]}" \
    -H  "Content-Type: application/json" \
    -d "{  \"name\": \"${DD_APP_NAME}\", \"prod_type\": \"${product_type_id}\",  \"description\": \"${DD_DEFAULT_NEW_APP_DESCR}\",  \"business_criticality\": \"very high\"}")
  app_id=$( echo -e "${output}" | jq -r ".id")
  if [ "$app_id" = "" ] || [ "$app_id" = "null" ]; then
    _print "Unable to create new product with name ${DD_APP_NAME}"
    _exit_error "${output}"
  fi
fi

_print "Product ID: ${app_id}"

# Get engagement for product, or create new one.
engagement_id=
engagement_id=$(curl "${DD_API}/api/v2/engagements/" \
  "${curl_opts[@]}" \
  --get \
  --data-urlencode "product=${app_id}" \
  --data-urlencode "name=${DD_ENGAGEMENT_NAME}" \
   | jq -r ".results[0].id")
if [ "$engagement_id" = "" ] || [ "$engagement_id" = "null" ]; then
  # Engagement doesn't exist (yet).
  _print "Engagement [${DD_ENGAGEMENT_NAME}] doesn't exist, creating now"
  _date=$(date +%Y-%m-%d)
  engagement_tag=
  [ "$DD_IMPORT_TAG" != "" ] && engagement_tag="\"${DD_IMPORT_TAG}\""
  engagement_id=$(curl -X POST "https://dms.payconiq.io/api/v2/engagements/" \
    "${curl_opts[@]}" \
    -H  "Content-Type: application/json" \
    -d "{  \"name\": \"${DD_ENGAGEMENT_NAME}\", \"tags\": [${engagement_tag}],  \"target_start\": \"${_date}\",  \"target_end\": \"${_date}\",  \"product\": ${app_id}, \"status\": \"Completed\"}" \
     | jq -r ".id")
  if [ "$engagement_id" = "" ] || [ "$engagement_id" = "null" ]; then
    _exit_error "Unable to create new engagement for product ${app_id}"
  fi
fi
_print "Engagement ID: ${engagement_id}"
#echo "{"engagement_name": $DD_ENGAGEMENT_NAME, "engagement_id": "$engagement_id"}" > params.txt
echo '{"engagement_name": "'"$DD_ENGAGEMENT_NAME\", \"engagement_id\": $engagement_id}" > params.txt
#echo "$engagement_id" > params.txt


[ $empty_engagement ] && exit 0

# Send report to defectdojo.
tag_opts=
[ "$DD_IMPORT_TAG" != "" ] && tag_opts=( "-F" "tags=\"$DD_IMPORT_TAG\"" )
response=$(curl -X POST "${DD_API}/api/v2/import-scan/" \
  "${curl_opts[@]}" \
  -w "\n%{http_code}" \
  -H "Content-Type: multipart/form-data" \
  -F file=@"$REPORT_FILE" \
  -F active="true" \
  -F verified="true" \
  -F scan_type="$DD_REPORT_TYPE" \
  -F engagement="$engagement_id" \
  "${tag_opts[@]}" \
  -F close_old_findings="true")
status=$?
response=(${response[@]}); statuscode=${response[-1]}; body=${response[@]::${#response[@]}-1}
[ ! -z "$DD_IMPORT_VERBOSE" ] && echo -e "DD API response (${statuscode}):\n===${body}\n===\n"


if [ $status -eq 0 ] && [ "$statuscode" = "201" ]; then
  _print "Successfully imported '$DD_REPORT_TYPE' report for project '${DD_APP_NAME}'"
  exit 0
else
  echo "Skipping DD_IMPORT"
  exit 0
  _print "Failed importing '$DD_REPORT_TYPE' report for project '${DD_APP_NAME}'"
  _exit_error "Statuscode ${statuscode}:\n${body}"
fi
