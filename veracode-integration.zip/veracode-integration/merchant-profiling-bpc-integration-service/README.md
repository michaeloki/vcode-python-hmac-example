# merchant-profiling-bpc-integration-service

Merchant Profiling BPC Integration Service is responsible for populating Merchant Profiling data for BPC integration in a reliable fashion.
[Confluence Link](https://payconiq.atlassian.net/wiki/spaces/IT/pages/3250487308/Data+Map+Phase+4+-+Merchant+Profiling)