package com.payconiq.mpbis.json;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import java.io.IOException;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

/**
 * This Class is defining a common behavior of jackson serialization and
 * deserialization. It is used in JUnit test, in Cucumber tests, and in jersey.
 * <p>
 * Using this mapper allow a predictable and constant jackson behavior.
 *
 */
public class CommonJsonMapperFactory {

    private CommonJsonMapperFactory(){}

    private static final ObjectMapper mapper = createMapper();

    public static ObjectMapper getMapper() {
        return mapper;
    }

    private static ObjectMapper createMapper() {
        SimpleModule module = new SimpleModule("CommonMapper");

        module.addSerializer(OffsetDateTime.class, new OffsetDateTimeSerializer());

        ObjectMapper newMapper = new ObjectMapper();
        newMapper.registerModule(new JavaTimeModule());
        newMapper.registerModule(module);

        newMapper.setSerializationInclusion(Include.NON_NULL);
        newMapper.setSerializationInclusion(Include.NON_EMPTY);
        newMapper.configure(SerializationFeature.WRITE_NULL_MAP_VALUES, false);
        newMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        newMapper.configure(MapperFeature.USE_STD_BEAN_NAMING, true);
        newMapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_ENUMS, true);
        newMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        return newMapper;
    }

    static class OffsetDateTimeSerializer extends JsonSerializer<OffsetDateTime> {
        private final DateTimeFormatter ISO_8601_FORMATTER = DateTimeFormatter
                .ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
                .withZone(ZoneId.of("UTC"));



        @Override
        public void serialize(OffsetDateTime value, JsonGenerator gen,
                SerializerProvider serializers) throws IOException {

            if (value == null) {
                throw new IOException("OffsetDateTime argument is null.");
            }

            gen.writeString(ISO_8601_FORMATTER.format(value));

        }
    }
}
