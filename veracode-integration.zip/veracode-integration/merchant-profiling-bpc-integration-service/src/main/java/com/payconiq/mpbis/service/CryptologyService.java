package com.payconiq.mpbis.service;

import com.payconiq.mpbis.exception.ProfiledMerchantDataProcessingException;
import org.bouncycastle.util.io.pem.PemObject;
import org.bouncycastle.util.io.pem.PemReader;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Service;

import java.io.Reader;
import java.io.StringReader;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.Security;
import java.security.spec.PKCS8EncodedKeySpec;

@Service
public class CryptologyService implements InitializingBean {
    public static PrivateKey getPrivateKey(Reader reader) {
        try (PemReader pemReader = new PemReader(reader)) {
            PemObject pemObject = pemReader.readPemObject();
            PKCS8EncodedKeySpec privateKeySpec = new PKCS8EncodedKeySpec(pemObject.getContent());
            KeyFactory factory = KeyFactory.getInstance("RSA");
            return factory.generatePrivate(privateKeySpec);
        } catch (Exception e) {
            throw new ProfiledMerchantDataProcessingException("Invalid data or key", e);
        }
    }

    public static PrivateKey getPrivateKey(String pemString) {
        return getPrivateKey(new StringReader(pemString));
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
    }
}