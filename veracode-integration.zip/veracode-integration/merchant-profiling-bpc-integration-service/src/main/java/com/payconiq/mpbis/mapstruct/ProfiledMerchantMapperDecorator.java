package com.payconiq.mpbis.mapstruct;

import com.payconiq.integration.bpc.datasharing.merchant_profiling.v1.model.PutProfilingMerchantRequest;
import com.payconiq.merchant.profiling.v1.topic.MerchantProfilingV1;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public abstract class ProfiledMerchantMapperDecorator implements ProfiledMerchantMapper {

    @Autowired
    public ProfiledMerchantMapper profiledMerchantMapper;

    @Override
    public void mapProfiledMerchantProtoToProfiledMerchantPojo(
            MerchantProfilingV1.ProfiledMerchant profiledMerchantProto, PutProfilingMerchantRequest profilingMerchantRequestModel) {
        profiledMerchantMapper.mapProfiledMerchantProtoToProfiledMerchantPojo(profiledMerchantProto, profilingMerchantRequestModel);
    }
}

