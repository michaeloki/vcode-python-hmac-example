package com.payconiq.mpbis.constant;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class CommonConstant {

    public static final String PMBPCDS = "PMBPCDS";
}
