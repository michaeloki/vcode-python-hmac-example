package com.payconiq.mpbis.config;

import com.google.common.util.concurrent.RateLimiter;
import com.payconiq.merchant.profiling.v1.topic.MerchantProfilingV1;
import com.payconiq.mpbis.exception.RetryableException;
import com.payconiq.mpbis.serde.ProfiledMerchantProtobufSerde;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.common.serialization.Serdes;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.config.KafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.ConcurrentMessageListenerContainer;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.listener.DefaultErrorHandler;
import org.springframework.util.backoff.BackOff;
import org.springframework.util.backoff.FixedBackOff;

@Configuration
@EnableKafka
@RequiredArgsConstructor
@EnableConfigurationProperties(KafkaProperties.class)
@Slf4j
public class KafkaConfig {

    @Value("${kafka.consumer.concurrency}")
    private int kafkaConsumerConcurrency;

    @Value("${kafka.consumer.backoff-period}")
    private long backoffPeriod;

    @Value("${kafka.consumer.rate-limit}")
    private double consumerRateLimit;

    @Bean
    public KafkaListenerContainerFactory<ConcurrentMessageListenerContainer<String, MerchantProfilingV1.ProfiledMerchant>>
    consumerContainerFactory(KafkaProperties kafkaProperties) {
        var factory = new ConcurrentKafkaListenerContainerFactory<String, MerchantProfilingV1.ProfiledMerchant>();
        factory.setConsumerFactory(consumerFactory(kafkaProperties));
        factory.getContainerProperties().setAckMode(ContainerProperties.AckMode.MANUAL_IMMEDIATE);
        factory.setCommonErrorHandler(errorHandler());
        factory.setConcurrency(kafkaConsumerConcurrency);
        return factory;
    }

    @Bean
    public DefaultErrorHandler errorHandler() {
        BackOff fixedBackOff = new FixedBackOff(backoffPeriod, Long.MAX_VALUE);
        DefaultErrorHandler errorHandler = new DefaultErrorHandler((consumerRecord, exception) -> log.info("Retry attempts are exhausted for event: {}", consumerRecord.toString()), fixedBackOff);
        errorHandler.addRetryableExceptions(RetryableException.class);
        return errorHandler;
    }

    private ConsumerFactory<String, MerchantProfilingV1.ProfiledMerchant> consumerFactory(KafkaProperties kafkaProperties) {
        var props = kafkaProperties.buildConsumerProperties();

        var keyDeserializer = Serdes.String().deserializer();
        var valueDeserializer = new ProfiledMerchantProtobufSerde.ProfiledMerchantProtobufDeserializer();

        return new DefaultKafkaConsumerFactory<>(props, keyDeserializer, valueDeserializer);
    }

    @Bean
    public RateLimiter rateLimiter() {
        return RateLimiter.create(consumerRateLimit);
    }

}
