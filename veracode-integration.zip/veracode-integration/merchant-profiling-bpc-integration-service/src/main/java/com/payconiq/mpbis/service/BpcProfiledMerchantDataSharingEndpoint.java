package com.payconiq.mpbis.service;

import com.payconiq.integration.bpc.datasharing.merchant_profiling.v1.model.PutProfilingMerchantRequest;
import com.payconiq.mpbis.config.BPCServiceProperties;
import com.payconiq.mpbis.json.JsonUtil;
import com.payconiq.mpbis.util.JWSHelper;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.UUID;

@Slf4j
@Service
@RequiredArgsConstructor
public class BpcProfiledMerchantDataSharingEndpoint {

    private final BPCServiceProperties bpcServiceProperties;
    @Qualifier("bpc-web-client")
    private final WebClient mtlsWebClient;
    private final JWSHelper jwsHelper;

    @SneakyThrows
    public ResponseEntity<Void> processProfiledMerchantRequest(PutProfilingMerchantRequest profiledMerchant,
                                                               String profiledMerchantId) {

        String payload = JsonUtil.serialize(profiledMerchant);

        final String requestId = UUID.randomUUID().toString();
        log.info("ProfiledMerchantId :{}", profiledMerchantId);

        final String signature = jwsHelper
                .signRequest(payload, profiledMerchantId,
                        bpcServiceProperties.getPutUri().concat(profiledMerchantId), requestId);

        return mtlsWebClient
                .put()
                .uri(bpcServiceProperties.getPutUri().concat(profiledMerchantId))
                .bodyValue(payload)
                .headers(headers -> {
                    headers.add("X-Request-ID", requestId);
                    headers.add("Signature", signature);
                    headers.add("Content-Type", "application/json");
                })
                .retrieve()
                .toBodilessEntity()
                .block();
    }
}
