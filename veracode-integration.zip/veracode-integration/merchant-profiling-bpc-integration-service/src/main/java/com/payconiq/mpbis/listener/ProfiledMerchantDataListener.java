package com.payconiq.mpbis.listener;

import com.newrelic.api.agent.Trace;
import com.payconiq.merchant.profiling.v1.topic.MerchantProfilingV1;
import com.payconiq.mpbis.exception.ProfiledMerchantDataProcessingException;
import com.payconiq.mpbis.exception.Retryable;
import com.payconiq.mpbis.service.ProfiledMerchantDataProcessService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import static com.newrelic.api.agent.NewRelic.noticeError;


@Slf4j
@Component
@RequiredArgsConstructor
public class ProfiledMerchantDataListener {
    private final ProfiledMerchantDataProcessService profiledMerchantDataProcessService;


    @Trace(dispatcher = true, metricName = "MerchantProfilingListener")
    @KafkaListener(topics = "${kafka.topic.name}", containerFactory = "consumerContainerFactory")
    public void onProfiledMerchantEvent(
            @Payload MerchantProfilingV1.ProfiledMerchant profiledMerchant,
            @Header(KafkaHeaders.RECEIVED_PARTITION) int partition,
            @Header(KafkaHeaders.RECEIVED_TOPIC) String topic,
            @Header(KafkaHeaders.OFFSET) long offset,
            @Header(KafkaHeaders.GROUP_ID) String groupId,
            Acknowledgment acknowledgment) {

        log.info("ProfiledMerchantDataListener : onProfiledMerchantEvent : start with Merchant ID : {}", profiledMerchant.getMerchantId());
        log.info("Merchant ID : {}, Partition Id : {}, Topic : {}, Offset : {}, Group Id : {}",
                profiledMerchant.getMerchantId(), partition, topic, offset, groupId);
        try {
            profiledMerchantDataProcessService.processData(profiledMerchant);
            acknowledgment.acknowledge();
        } catch (Exception exception) {
            if (exception instanceof Retryable) {
                throw exception;
            }
            log.error("Unhandled exception occurred for Merchant Id : {}, Exception : {}", profiledMerchant.getMerchantId(), exception.getMessage(), exception);
            var ex = new ProfiledMerchantDataProcessingException(exception.getMessage(), exception);
            noticeError(ex);
        }
        log.info("ProfiledMerchantDataListener : onProfiledMerchantEvent : end");
    }
}
