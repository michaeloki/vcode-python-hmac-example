package com.payconiq.mpbis.client;

import com.payconiq.shared.security.oauth2.jwt.token.Subject;
import com.payconiq.shared.security.oauth2.jwt.token.TokenBuilder;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class JsonWebTokenService {
    private static final String EMPLOYEE = "EMPLOYEE";
    private static final String EMPLOYEE_ID = "consumer-profiling-service";

    private final TokenBuilder tokenBuilder;

    @Value("${jwt-expires-in-sec}")
    private int expiresInSec;

    public String generateMerchantToken() {

        Subject subject = Subject.builder().type(EMPLOYEE).id(EMPLOYEE_ID).build();

        return tokenBuilder.newBuilder()
                .authority("PQ_MERCHANT_MASTER")
                .subject(subject)
                .issuedAt(System.currentTimeMillis())
                .expiresSec(expiresInSec)
                .build();
    }
}

