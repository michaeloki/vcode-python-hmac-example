package com.payconiq.mpbis.exception;

public class ProfiledMerchantDataProcessingException extends RuntimeException{

    public ProfiledMerchantDataProcessingException(final String message, Throwable e) {
        super(message,e);
    }
}
