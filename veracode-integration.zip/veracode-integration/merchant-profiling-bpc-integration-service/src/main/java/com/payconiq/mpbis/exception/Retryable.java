package com.payconiq.mpbis.exception;

public interface Retryable {
}
