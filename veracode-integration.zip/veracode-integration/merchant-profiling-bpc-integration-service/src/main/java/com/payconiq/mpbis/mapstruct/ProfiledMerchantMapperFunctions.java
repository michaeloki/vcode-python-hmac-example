package com.payconiq.mpbis.mapstruct;

import com.google.protobuf.Timestamp;
import com.payconiq.integration.bpc.datasharing.merchant_profiling.v1.model.Country;
import com.payconiq.integration.bpc.datasharing.merchant_profiling.v1.model.EventType;
import com.payconiq.integration.bpc.datasharing.merchant_profiling.v1.model.Result;
import com.payconiq.merchant.profiling.v1.topic.MerchantProfilingV1;
import org.mapstruct.Named;
import org.springframework.stereotype.Service;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.EnumSet;
import java.util.Optional;

@Service
public class ProfiledMerchantMapperFunctions {

    private ProfiledMerchantMapperFunctions() {}

    @Named("mapTimeStampToOffsetDateTimeUTC")
    static OffsetDateTime mapTimeStampToOffsetDateTimeUTC(Timestamp timestamp) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        return OffsetDateTime.parse(Instant.ofEpochSecond(timestamp.getSeconds(), timestamp.getNanos()).atOffset(ZoneOffset.UTC).format(formatter));
    }

    @Named("mapLocalDateTimeToOffsetDateTimeUTC")
    static OffsetDateTime mapLocalDateTimeToOffsetDateTimeUTC(LocalDateTime dateTime) {
        if (null == dateTime) return null;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        return OffsetDateTime.parse(dateTime.atOffset(ZoneOffset.UTC).format(formatter));
    }

    @Named("mapTimeStampToLocalDateTimeUTC")
    public static LocalDate mapTimeStampToLocalDateTimeUTC(Timestamp timestamp) {
        if (timestamp == null || !timestamp.isInitialized()) {
            return null;
        }
        return LocalDate.ofInstant(Instant.ofEpochSecond(timestamp.getSeconds(), timestamp.getNanos()), ZoneId.of("UTC"));
    }

    @Named("mapScreeningEventType")
    static EventType mapScreeningEventType(MerchantProfilingV1.ScreeningData.ScreeningEventType eventType) {
        return getEnum(EventType.class, eventType.name(), EventType.UNRECOGNIZED);
    }

    @Named("mapResult")
    static Result mapResult(MerchantProfilingV1.ScreeningData.ScreeningDataResult result) {
        return getEnum(Result.class, result.name(), Result.UNRECOGNIZED);
    }

    @Named("mapCountry")
    static Country mapCountry(String country) {
        return getEnum(Country.class, country, Country.UNRECOGNIZED);
    }


    private static <E extends Enum<E>> E getEnum(Class<E> clazz, String s, Enum<E> returnVal) {
        Optional<E> optional = EnumSet.allOf(clazz).stream().filter(v -> v.name().equalsIgnoreCase(s)).findFirst();
        return optional.orElseGet(() -> (E) returnVal);
    }

}

