package com.payconiq.mpbis.util;


import com.payconiq.merchant.profiling.v1.topic.MerchantProfilingV1;
import com.payconiq.merchant.service.api.v1.model.CddStatus;
import com.payconiq.merchant.service.api.v1.model.MerchantDetails;
import com.payconiq.mpbis.client.MerchantApiClient;
import com.payconiq.mpbis.constant.CommonConstant;
import com.payconiq.mpbis.constant.Country;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;

@Slf4j
@Component
@RequiredArgsConstructor
public class ProfiledMerchantValidator {

    private static final LocalDate UNREGISTERED_MERCHANT_DATE = LocalDate.of(2023, 05, 01);
    private final MerchantApiClient merchantApiClient;
    @Value("${profiled-merchant-company-name-check:false}")
    public Boolean profiledMerchantCompanyNameCheck;

    /**
     * @param profiledMerchant : profiled merchant entity which comes from external stream event
     * @return Method will return True if it can be transferred
     * @implNote This method will check related merchant whether is valid or not
     */
    public boolean isBPCProfiledMerchant(final MerchantProfilingV1.ProfiledMerchant profiledMerchant) {
        if (ObjectUtils.isEmpty(profiledMerchant)) {
            return false;
        }
        if (BooleanUtils.isFalse(accProfiledMerchantCheck(profiledMerchant))) {
            return false;
        }
        if (profiledMerchant.getActive()) {
            return Country.BEL.name().equalsIgnoreCase(profiledMerchant.getCountry());
        } else {
            final MerchantDetails merchantDetails = merchantApiClient.getMerchantDetailsById(profiledMerchant.getMerchantId());
            boolean val = ObjectUtils.isNotEmpty(merchantDetails) && isBelgiumMerchant(merchantDetails);
            log.info("Profiled Merchant country is {} Belgium", val ? "" : "not");
            return val && isValidUnregisteredMerchant(merchantDetails);
        }
    }

    private boolean accProfiledMerchantCheck(final MerchantProfilingV1.ProfiledMerchant profiledMerchant) {
        if (BooleanUtils.isTrue(profiledMerchantCompanyNameCheck)) {

            if (isBPCDSProfiledMerchant(ObjectUtils.isNotEmpty(profiledMerchant.getBusinessScreeningData(0)) ?
                    profiledMerchant.getBusinessScreeningData(0).getCompanyName() : StringUtils.EMPTY)) {
                return true;
            } else {
                log.debug("Acc data check fail to transfer profiled merchant [{}] to BPC.", profiledMerchant.getMerchantId());
                return false;
            }
        }
        // return true for default data
        return true;
    }

    private boolean isBPCDSProfiledMerchant(final String companyName) {
        return companyName.equalsIgnoreCase(CommonConstant.PMBPCDS);
    }

    private boolean isValidUnregisteredMerchant(final MerchantDetails merchant) {
        CddStatus cddStatus = merchant.getCddData().getCddStatus();
        if (cddStatus == CddStatus.UNREGISTERED
                || cddStatus == CddStatus.ABORTED) {
            if (ObjectUtils.isEmpty(merchant.getUnregisteredAt())) {
                log.debug("Found {} Merchant [{}], without Unregistered Date", cddStatus.name(),
                        merchant.getId());
                return false;
            }
            final OffsetDateTime merchantUnregisterDate = merchant.getUnregisteredAt();
            final LocalDate localUnregisterDate = merchantUnregisterDate.atZoneSameInstant(ZoneOffset.UTC).toLocalDate();
            log.debug("Found {} Merchant [{}], with Unregistered Date [{}]", cddStatus.name(), merchant.getId(),
                    localUnregisterDate);
            return localUnregisterDate.isAfter(UNREGISTERED_MERCHANT_DATE);
        }
        return true;
    }

    private boolean isBelgiumMerchant(final MerchantDetails merchant) {
        return ObjectUtils.isNotEmpty(merchant)
                && ObjectUtils.isNotEmpty(merchant.getPqCountry())
                && Country.BEL.name().equals(merchant.getPqCountry().name());
    }

}
