package com.payconiq.mpbis.config;

import com.payconiq.commons.mtls.client.ClientMTlsProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "app.mutual-tls")
public class MutualTlsProperties extends ClientMTlsProperties {
}
