package com.payconiq.mpbis.json;

import lombok.SneakyThrows;


public class JsonUtil {

    private JsonUtil() {}

    @SneakyThrows
    public static String serialize(Object object) {
        return CommonJsonMapperFactory.getMapper().writeValueAsString(object);
    }

}
