package com.payconiq.mpbis.exception;

public class RetryableException extends RuntimeException implements Retryable {

    public RetryableException(String message) {
        super(message);
    }

    public RetryableException(String message, Throwable throwable) {
        super(message, throwable);
    }
}
