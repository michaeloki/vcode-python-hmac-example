package com.payconiq.mpbis.constant;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public enum Country {
    BEL
}
