package com.payconiq.mpbis.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "app.jws-config")
@Getter
@Setter
public class JwsConfig {
    private String kid;
    private String alg;
    private String key;
    private boolean enableJws;

    /*JWS Headers*/
    private String iat;
    private String jti;
    private String path;
    private String iss;
    private String sub;
    private String typ;
    private String typValue;
    private String issuerValue;
    /*JWS Headers*/
}
