package com.payconiq.mpbis.mapstruct;

import com.payconiq.integration.bpc.datasharing.merchant_profiling.v1.model.BusinessScreeningData;
import com.payconiq.integration.bpc.datasharing.merchant_profiling.v1.model.PersonScreeningData;
import com.payconiq.integration.bpc.datasharing.merchant_profiling.v1.model.PutProfilingMerchantRequest;
import com.payconiq.merchant.profiling.v1.topic.MerchantProfilingV1;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.*;

@Mapper(
        componentModel = "spring",
        unmappedTargetPolicy = ReportingPolicy.WARN,
        uses = {ProfiledMerchantMapperFunctions.class})
@DecoratedWith(ProfiledMerchantMapperDecorator.class)
public interface ProfiledMerchantMapper {

    @Mapping(source = "lastModified", target = "lastModified", qualifiedByName = "mapTimeStampToOffsetDateTimeUTC")
    @Mapping(source = "periodicScreeningCheckDate", target = "periodicScreeningCheckDate", qualifiedByName = "mapTimeStampToOffsetDateTimeUTC")
    @Mapping(source = "country", target = "country", qualifiedByName = "mapCountry")
    void mapProfiledMerchantProtoToProfiledMerchantPojo(MerchantProfilingV1.ProfiledMerchant profiledMerchantProto,
                                                        @MappingTarget PutProfilingMerchantRequest profilingMerchantRequestModel);


    @Mapping(source = "companyName", target = "businessScreeningFields.companyName")
    @Mapping(source = "chamberOfCommerceId", target = "businessScreeningFields.chamberOfCommerceId")
    @Mapping(source = "screeningData.checkDate", target = "checkDate", qualifiedByName = "mapTimeStampToOffsetDateTimeUTC")
    @Mapping(source = "screeningData.eventType", target = "eventType", qualifiedByName = "mapScreeningEventType")
    @Mapping(source = "screeningData.result", target = "result", qualifiedByName = "mapResult")
    @Mapping(source = "screeningData.hitReasonsList", target = "lexisNexisAlert.lexisNexisHitReasons")
    @Mapping(source = "screeningData.alertId", target = "lexisNexisAlert.alertId")
    @Mapping(source = "screeningData.alertClosed", target = "lexisNexisAlert.closed")
    BusinessScreeningData mapBusinessScreeningDataToBusinessScreeningFields(MerchantProfilingV1.BusinessScreeningData businessScreeningData);

    @Mapping(source = "dateOfBirth", target = "personScreeningFields.dateOfBirth", qualifiedByName = "mapTimeStampToOffsetDateTimeUTC")
    @Mapping(source = "firstName", target = "personScreeningFields.firstName")
    @Mapping(source = "lastName", target = "personScreeningFields.lastName")
    @Mapping(source = "nationality", target = "personScreeningFields.nationality", qualifiedByName = "mapCountry")
    @Mapping(source = "countryOfResidence", target = "personScreeningFields.countryOfResidence", qualifiedByName = "mapCountry")
    @Mapping(source = "screeningData.checkDate", target = "checkDate", qualifiedByName = "mapTimeStampToOffsetDateTimeUTC")
    @Mapping(source = "screeningData.eventType", target = "eventType", qualifiedByName = "mapScreeningEventType")
    @Mapping(source = "screeningData.result", target = "result", qualifiedByName = "mapResult")
    @Mapping(source = "screeningData.hitReasonsList", target = "lexisNexisAlert.lexisNexisHitReasons")
    @Mapping(source = "screeningData.alertId", target = "lexisNexisAlert.alertId")
    @Mapping(source = "screeningData.alertClosed", target = "lexisNexisAlert.closed")
    PersonScreeningData mapPersonScreeningDataProtoToPersonScreeningFields(MerchantProfilingV1.PersonScreeningData personScreeningData);

    @AfterMapping
    default void setNullEmptyObjects(@MappingTarget PutProfilingMerchantRequest profilingMerchantRequestModel) {
        profilingMerchantRequestModel.getBusinessScreeningDataList().forEach(businessScreeningData -> {
            if (StringUtils.isBlank(businessScreeningData.getLexisNexisAlert().getAlertId())) {
                businessScreeningData.setLexisNexisAlert(null);
            }
        });

        profilingMerchantRequestModel.getPersonScreeningDataList().forEach(personScreeningData -> {
            if (StringUtils.isBlank(personScreeningData.getLexisNexisAlert().getAlertId())) {
                personScreeningData.setLexisNexisAlert(null);
            }
        });
    }
}