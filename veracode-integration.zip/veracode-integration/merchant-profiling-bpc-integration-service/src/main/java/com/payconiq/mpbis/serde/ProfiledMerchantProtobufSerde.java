package com.payconiq.mpbis.serde;


import com.payconiq.merchant.profiling.v1.topic.MerchantProfilingV1;
import lombok.SneakyThrows;
import org.apache.kafka.common.serialization.Deserializer;
import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serializer;

import java.util.Map;

public class ProfiledMerchantProtobufSerde implements Serde<MerchantProfilingV1.ProfiledMerchant> {

    private final ProfiledMerchantProtobufSerializer profiledMerchantProtobufSerializer;
    private final ProfiledMerchantProtobufDeserializer profiledMerchantProtobufDeserializer;

    public ProfiledMerchantProtobufSerde() {
        profiledMerchantProtobufSerializer = new ProfiledMerchantProtobufSerializer();
        profiledMerchantProtobufDeserializer = new ProfiledMerchantProtobufDeserializer();
    }

    @Override
    public void configure(Map<String, ?> map, boolean b) {
        // Nothing
    }

    @Override
    public void close() {
        // No resource to close
    }

    @Override
    public Serializer<MerchantProfilingV1.ProfiledMerchant> serializer() {
        return profiledMerchantProtobufSerializer;
    }

    @Override
    public Deserializer<MerchantProfilingV1.ProfiledMerchant> deserializer() {
        return profiledMerchantProtobufDeserializer;
    }

    public static class ProfiledMerchantProtobufSerializer implements Serializer<MerchantProfilingV1.ProfiledMerchant> {

        @Override
        public void configure(Map<String, ?> map, boolean b) {
            // Nothing
        }

        @Override
        public byte[] serialize(String topic, MerchantProfilingV1.ProfiledMerchant profiledMerchant) {
            return profiledMerchant.toByteArray();
        }

        @Override
        public void close() {
            // Nothing
        }
    }

    public static class ProfiledMerchantProtobufDeserializer implements Deserializer<MerchantProfilingV1.ProfiledMerchant> {

        @Override
        public void configure(Map<String, ?> map, boolean b) {
            // Nothing
        }

        @Override
        @SneakyThrows
        public MerchantProfilingV1.ProfiledMerchant deserialize(String topic, byte[] bytes) {
            return MerchantProfilingV1.ProfiledMerchant.parseFrom(bytes);
        }

        @Override
        public void close() {
            // Nothing
        }
    }
}
