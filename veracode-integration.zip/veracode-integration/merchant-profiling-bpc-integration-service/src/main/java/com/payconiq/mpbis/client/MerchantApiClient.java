package com.payconiq.mpbis.client;

import com.payconiq.merchant.service.api.v1.model.MerchantDetails;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Slf4j
@Component
@RequiredArgsConstructor
public class MerchantApiClient {
    private final RestTemplate merchantRestTemplate;
    private final JsonWebTokenService webTokenService;
    @Value("${merchant-service-url}")
    private String merchantURL;

    public MerchantDetails getMerchantDetailsById(final String merchantId) {
        log.info("Calling getMerchantDetailsById :: MerchantId [{}] ", merchantId);
        ResponseEntity<MerchantDetails> response = null;
        try {
            String url = merchantURL.replace("{merchantId}", merchantId);
            response = merchantRestTemplate.exchange(url, HttpMethod.GET, getHttpEntity(), MerchantDetails.class);
            log.debug("Merchant [{}] retrieved with response Code :{}", merchantId, response.getStatusCode());
        } catch (Exception e) {
            log.error("Unable to process Merchant Id : {}", merchantId, e);
        }

        MerchantDetails merchantDetails = null;
        if (null != response) {
            merchantDetails = response.getBody();
        }
        return merchantDetails;
    }

    private HttpEntity getHttpEntity() {
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(webTokenService.generateMerchantToken());
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
        return new HttpEntity<>(headers);
    }
}