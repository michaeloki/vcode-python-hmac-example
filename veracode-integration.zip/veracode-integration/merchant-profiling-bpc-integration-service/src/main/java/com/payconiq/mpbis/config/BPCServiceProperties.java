package com.payconiq.mpbis.config;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "client")
@Getter
@Setter
public class BPCServiceProperties {

    String putUri;
    ProxyConfig proxyConfig;

    @Data
    public static class ProxyConfig {

        private String hostname;
        private Integer port;
    }
}
