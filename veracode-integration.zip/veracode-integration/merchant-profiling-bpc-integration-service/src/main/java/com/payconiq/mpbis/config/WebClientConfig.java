package com.payconiq.mpbis.config;

import com.payconiq.commons.mtls.client.SSLContextUtil;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.jetty.client.HttpClient;
import org.eclipse.jetty.client.HttpProxy;
import org.eclipse.jetty.client.transport.HttpClientTransportDynamic;
import org.eclipse.jetty.io.ClientConnector;
import org.eclipse.jetty.util.ssl.SslContextFactory;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.JettyClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.Base64;


@RequiredArgsConstructor
@Configuration
@EnableConfigurationProperties(MutualTlsProperties.class)
@Slf4j
public class WebClientConfig {
    private static final String BASE64_PREFIX = "file-base64://";
    private static final String WEBCLIENT_BUILDER_BEAN_NAME = "webClientBuilder";

    private final MutualTlsProperties mutualTlsProperties;
    private final BPCServiceProperties bpcServiceProperties;


    @Bean
    @Qualifier(WEBCLIENT_BUILDER_BEAN_NAME)
    @ConditionalOnMissingBean
    public WebClient.Builder issuerWebClientBuilder() {
        return WebClient.builder();
    }

    @Bean("bpc-web-client")
    public WebClient mtlsWebClient(@Qualifier(WEBCLIENT_BUILDER_BEAN_NAME) WebClient.Builder webClientBuilder) {
        // Keystore
        final SslContextFactory.Client sslContextFactory = new SslContextFactory.Client(false);
        sslContextFactory.setKeyStore(loadKeyStore(
                mutualTlsProperties.getKeyStoreLocation(),
                mutualTlsProperties.getKeyStorePassword(),
                mutualTlsProperties.getKeyStoreType()
        ));
        sslContextFactory.setKeyStorePassword(mutualTlsProperties.getKeyStorePassword());
        // Truststore
        sslContextFactory.setTrustStore(loadKeyStore(
                mutualTlsProperties.getTrustStoreLocation(),
                mutualTlsProperties.getTrustStorePassword(),
                mutualTlsProperties.getTrustStoreType()
        ));
        sslContextFactory.setTrustStorePassword(mutualTlsProperties.getTrustStorePassword());

        //HttpClient configuration
        ClientConnector clientConnector = new ClientConnector();
        clientConnector.setSslContextFactory(sslContextFactory);
        HttpClient httpClient = new HttpClient(new HttpClientTransportDynamic(clientConnector)); // trusts all

        // Proxy
        final BPCServiceProperties.ProxyConfig proxyConfig = bpcServiceProperties.getProxyConfig();
        if (StringUtils.isNotBlank(proxyConfig.getHostname()) && proxyConfig.getPort() != null) {
            HttpProxy proxy = new HttpProxy(proxyConfig.getHostname(),
                    proxyConfig.getPort());
            httpClient.getProxyConfiguration().addProxy(proxy);
        }

        JettyClientHttpConnector jettyClientHttpConnector = new JettyClientHttpConnector(httpClient);

        return webClientBuilder.clientConnector(jettyClientHttpConnector).build();
    }

    @Bean
    public ModelMapper modelMapper() {
        return new ModelMapper();
    }

    @SneakyThrows
    private KeyStore loadKeyStore(String resourcePath, String password, String format) {
        try (var is = keyStoreStream(resourcePath)) {
            var keystore = KeyStore.getInstance(format);
            keystore.load(is, password.toCharArray());
            return keystore;
        }
    }

    private InputStream keyStoreStream(String resourcePath) {
        InputStream is;
        if (resourcePath.contains(BASE64_PREFIX)) {
            String base64String = resourcePath.replace(BASE64_PREFIX, "").replace("\n", "");
            is = new ByteArrayInputStream(Base64.getDecoder().decode(base64String.getBytes(StandardCharsets.UTF_8)));
        } else {
            is = SSLContextUtil.class.getClassLoader().getResourceAsStream(resourcePath);
        }
        return is;
    }
}
