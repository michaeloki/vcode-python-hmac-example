package com.payconiq.mpbis.service;

import com.payconiq.integration.bpc.datasharing.merchant_profiling.v1.model.PutProfilingMerchantRequest;
import com.payconiq.merchant.profiling.v1.topic.MerchantProfilingV1;
import com.payconiq.mpbis.exception.RetryableException;
import com.payconiq.mpbis.mapstruct.ProfiledMerchantMapper;
import com.payconiq.mpbis.util.ProfiledMerchantValidator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClientException;

@Slf4j
@Service
@RequiredArgsConstructor
public class ProfiledMerchantDataProcessService {

    private final ProfiledMerchantMapper profiledMerchantMapper;

    private final BpcProfiledMerchantDataSharingEndpoint bpcProfiledMerchantDataSharingEndpoint;

    private final ProfiledMerchantValidator profiledMerchantValidator;


    public void processData(final MerchantProfilingV1.ProfiledMerchant profiledMerchantProto) {

        log.debug("ProfiledMerchantDataProcessService :: processData with Profiled Merchant ID [{}]: start",
                profiledMerchantProto.getMerchantId());

        if (BooleanUtils.isFalse(profiledMerchantValidator.isBPCProfiledMerchant(profiledMerchantProto))) {
            log.debug("Not a valid profiled merchant to be processed : Profiled Merchant Id : {} "
                    , profiledMerchantProto.getMerchantId());
            return;
        }

        PutProfilingMerchantRequest profiledMerchantModel = new PutProfilingMerchantRequest();
        profiledMerchantMapper.mapProfiledMerchantProtoToProfiledMerchantPojo(profiledMerchantProto, profiledMerchantModel);
        sendProfiledMerchantToBPCEndpoint(profiledMerchantModel, profiledMerchantProto.getMerchantId());

    }

    private void sendProfiledMerchantToBPCEndpoint(PutProfilingMerchantRequest profiledMerchantModel, String profiledMerchantId) {
        try {
            ResponseEntity<Void> responseEntity = bpcProfiledMerchantDataSharingEndpoint
                    .processProfiledMerchantRequest(profiledMerchantModel, profiledMerchantId);
            if (null != responseEntity) {
                if (BooleanUtils.isFalse(responseEntity.getStatusCode().equals(HttpStatus.OK))) {
                    throw new RetryableException(String.format("Received unsuccessful status from BPC: %s Operation will be retried for profiledMerchantId: %s ",
                            responseEntity.getStatusCode(), profiledMerchantId));
                }
                log.info("Received Response: [{}] from BPC for Profiled Merchant ID [{}].", responseEntity.getStatusCode(),
                        profiledMerchantId);
                log.debug("[ProfiledMerchantDataProcessService :: processData with ProfiledMerchantId ID [{}] : end]", profiledMerchantId);
            } else {
                throw new RetryableException(
                        String.format("Unable to received response from BPC, Operation will be retried for profiledMerchantId: %s ", profiledMerchantId));

            }
        } catch (WebClientException exception) {
            throw new RetryableException(String.format("WebClientException, Operation will be retried for profiledMerchantId: %s", profiledMerchantId), exception);
        }
    }

}
