package com.payconiq.mpbis.util;

import com.payconiq.mpbis.config.JwsConfig;
import com.payconiq.mpbis.service.CryptologyService;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.jose4j.jws.JsonWebSignature;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.security.PrivateKey;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;

@Component
@RequiredArgsConstructor
@Slf4j
public class JWSHelper {

    private final JwsConfig jwsConfig;

    @SneakyThrows
    public String signRequest(String payload, String sub, String path, String requestId) {

        /**
         * According to target service capability JWS signature creation can bypass*/
        if (jwsConfig.isEnableJws()) {
            try {
                PrivateKey privateKey = CryptologyService.getPrivateKey(jwsConfig.getKey());

                JsonWebSignature jws = new JsonWebSignature();

                jws.setHeader(jwsConfig.getTyp(), jwsConfig.getTypValue());
                jws.setKeyIdHeaderValue(jwsConfig.getKid());
                jws.setAlgorithmHeaderValue(jwsConfig.getAlg());
                jws.setHeader(jwsConfig.getSub(), sub);

                jws.setHeader(jwsConfig.getIat(), OffsetDateTime.now(ZoneOffset.UTC));
                jws.setHeader(jwsConfig.getJti(), requestId);
                jws.setHeader(jwsConfig.getPath(), path);
                jws.setHeader(jwsConfig.getIss(), jwsConfig.getIssuerValue());
                jws.setPayloadBytes(payload.getBytes(StandardCharsets.UTF_8));
                jws.setKey(privateKey);
                String signature = jws.getCompactSerialization();
                log.info("JWS Signed for Merchant ID [{}] ", sub);
                return signature;
            } catch (Exception e) {
                log.error("JWS signing error", e);
            }
        }
        return "";
    }
}
