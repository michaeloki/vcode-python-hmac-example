package com.payconiq.mpbis.acceptance.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

@Configuration
@EnableMongoRepositories(
        basePackages = "com.payconiq.mpbis.acceptance.repository.profiledMerchantRepository",
        mongoTemplateRef = "ProfiledMerchantMongoTemplate")

public class ProfiledMerchantMongoConfig {
}
