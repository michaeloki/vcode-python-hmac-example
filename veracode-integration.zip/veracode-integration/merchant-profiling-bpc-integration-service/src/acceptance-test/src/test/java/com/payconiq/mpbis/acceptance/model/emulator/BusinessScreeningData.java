package com.payconiq.mpbis.acceptance.model.emulator;

import lombok.Data;

import java.util.Date;

@Data
public class BusinessScreeningData {
    private BusinessScreeningFields businessScreeningFields;
    private Date checkDate;
    private ScreeningEventType eventType;
    private MerchantScreeningResult result;
    private LexisNexisAlert lexisNexisAlert;
}
