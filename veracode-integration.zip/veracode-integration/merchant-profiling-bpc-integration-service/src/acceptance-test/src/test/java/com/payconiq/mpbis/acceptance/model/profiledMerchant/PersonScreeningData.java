package com.payconiq.mpbis.acceptance.model.profiledMerchant;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

import java.util.Date;

@Data
public class PersonScreeningData {


    private Date checkDate;
    private ScreeningEventType eventType;
    private String result;
    private PersonScreeningFields personScreeningFields;
    @JsonIgnore
    private String alert;

}
