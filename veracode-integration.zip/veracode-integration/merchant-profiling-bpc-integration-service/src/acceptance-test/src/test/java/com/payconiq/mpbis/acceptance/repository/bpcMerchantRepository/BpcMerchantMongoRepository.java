package com.payconiq.mpbis.acceptance.repository.bpcMerchantRepository;

import com.payconiq.mpbis.acceptance.model.emulator.BpcMerchant;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface BpcMerchantMongoRepository extends MongoRepository<BpcMerchant, String> {
    void deleteBpcMerchantByMerchantId(final String merchantId);
}
