package com.payconiq.mpbis.acceptance.model.profiledMerchant;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.Set;


@Data
public class LexisNexisAlert {

    String alertId;
    @JsonProperty("lexisNexisHitReasons")
    Set<LexisNexisHitReason> reasons;
    boolean closed;
}
