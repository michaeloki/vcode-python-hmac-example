package com.payconiq.mpbis.acceptance.model.profiledMerchant;


import lombok.Data;

@Data
public class Address {
    private String street;
    private String number;
    private String postalCode;
    private String city;
    private String country;
}
