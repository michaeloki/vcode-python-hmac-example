package com.payconiq.mpbis.acceptance.model.profiledMerchant;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;


@Data
public class BusinessScreeningFields {
    private String companyName;
    private String chamberOfCommerceId;
    @JsonIgnore
    private Address address;
}
