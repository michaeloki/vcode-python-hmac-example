package com.payconiq.mpbis.acceptance.model.profiledMerchant;


import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.annotation.Id;

import java.util.Date;
import java.util.List;

@Data
@Document(collection = "profiledMerchants")

public class ProfiledMerchant {
   @Id
   @JsonIgnore
    private ObjectId id;
    private Date lastModified;
    private Boolean active;
    private String country;
    @JsonIgnore
    private Boolean reviewed;
    private Date periodicScreeningCheckDate;
    private List<BusinessScreeningData> businessScreeningDataList;
    private List<PersonScreeningData> personScreeningDataList;
}
