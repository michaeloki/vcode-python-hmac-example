package com.payconiq.mpbis.acceptance.model.profiledMerchant;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;


@Slf4j
@Getter
@RequiredArgsConstructor
public enum LexisNexisHitReason {
    PEP,
    ADVERSE_MEDIA,
    SANCTION,
    OTHER;
}
