package com.payconiq.mpbis.acceptance.repository.profiledMerchantRepository;


import com.payconiq.mpbis.acceptance.model.profiledMerchant.ProfiledMerchant;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface ProfiledMerchantMongoRepository extends MongoRepository<ProfiledMerchant, ObjectId> {

}
