package com.payconiq.mpbis.acceptance.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

@Configuration
@EnableMongoRepositories(
        basePackages = "com.payconiq.mpbis.acceptance.repository.payconiqMerchantRepository",
        mongoTemplateRef = "PayconiqMerchantMongoTemplate")

public class PayconiqMerchantMongoConfig {
}
