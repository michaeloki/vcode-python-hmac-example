package com.payconiq.mpbis.acceptance.config;

import com.mongodb.ConnectionString;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import org.springframework.context.annotation.Bean;
import org.springframework.data.mongodb.core.MongoTemplate;

public class GeneralConfig {
    @Bean
    public ConnectionString connectionString() {
        String mongoUri = TestConstants.getConfigKey("mongo.uri");

        return new ConnectionString(mongoUri);
    }
    @Bean
    public MongoClient mongoClient(ConnectionString connectionString) {
        return MongoClients.create(connectionString);
    }
    @Bean("BpcProfiledMerchantMongoTemplate")
    public MongoTemplate bpcProfiledMerchantMongoTemplate(MongoClient mongoClient) {
        return new MongoTemplate(mongoClient, TestConstants.getConfigKey("database.bpcDataSharingEmulator"));
    }
    @Bean("BpcMerchantMongoTemplate")
    public MongoTemplate bpcMerchantMongoTemplate(MongoClient mongoClient) {
        return new MongoTemplate(mongoClient, TestConstants.getConfigKey("database.bpcDataSharingEmulator"));
    }
    @Bean("PayconiqMerchantMongoTemplate")
    public MongoTemplate payconiqMerchantMongoTemplate(MongoClient mongoClient) {
        return new MongoTemplate(mongoClient, TestConstants.getConfigKey("database.merchant"));
    }
    @Bean("ProfiledMerchantMongoTemplate")
    public MongoTemplate profiledMerchantMongoTemplate(MongoClient mongoClient) {
        return new MongoTemplate(mongoClient, TestConstants.getConfigKey("database.merchantProfilingService"));
    }
}
