package com.payconiq.mpbis.acceptance.model.emulator;

import lombok.Data;

import java.util.Date;

@Data
public class PersonScreeningData {


    private Date checkDate;
    private ScreeningEventType eventType;
    private String result;
    private PersonScreeningFields personScreeningFields;

}
