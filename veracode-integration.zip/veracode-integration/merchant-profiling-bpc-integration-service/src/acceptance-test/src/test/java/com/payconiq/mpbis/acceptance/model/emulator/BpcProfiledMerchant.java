package com.payconiq.mpbis.acceptance.model.emulator;


import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.MongoId;


import java.util.Date;
import java.util.List;

@Data
@Document(collection = "profiledMerchants")

public class BpcProfiledMerchant {
    @MongoId
    @JsonIgnore
    private String id;
    private Date lastModified;
    private Boolean active;
    private String country;
    @JsonIgnore
    private Boolean reviewed;
    private Date periodicScreeningCheckDate;
    private List<BusinessScreeningData> businessScreeningDataList;
    private List<PersonScreeningData> personScreeningDataList;

}
