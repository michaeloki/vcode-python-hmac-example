package com.payconiq.mpbis.acceptance.services;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.payconiq.merchant.service.api.v1.model.*;
import com.payconiq.mpbis.acceptance.config.TestConstants;
import com.payconiq.mpbis.acceptance.model.emulator.BpcProfiledMerchant;
import com.payconiq.mpbis.acceptance.model.profiledMerchant.ProfiledMerchant;
import com.payconiq.mpbis.acceptance.repository.bpcMerchantRepository.BpcMerchantMongoRepository;
import com.payconiq.mpbis.acceptance.repository.bpcMerchantRepository.BpcProfiledMerchantMongoRepository;
import com.payconiq.mpbis.acceptance.repository.payconiqMerchantRepository.PayconiqMerchantMongoRepository;
import com.payconiq.mpbis.acceptance.repository.profiledMerchantRepository.ProfiledMerchantMongoRepository;
import com.payconiq.testing.data.generator.model.merchant.Merchant;
import com.payconiq.testing.data.generator.services.MerchantGenerationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.awaitility.Awaitility;
import org.bson.types.ObjectId;
import org.json.JSONException;
import org.junit.jupiter.api.Assertions;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

import static org.assertj.core.api.Assertions.assertThat;

@Service
@RequiredArgsConstructor
@Slf4j
public class MerchantService {

    @Autowired
    private PayconiqMerchantMongoRepository payconiqMerchantMongoRepository;

    @Autowired
    private BpcProfiledMerchantMongoRepository bpcProfiledMerchantMongoRepository;

    @Autowired
    private ProfiledMerchantMongoRepository profiledMerchantMongoRepository;

    @Autowired
    private BpcMerchantMongoRepository bpcMerchantMongoRepository;

    public Merchant merchantWithCdd(
            String firstName,
            String billingIban,
            String pqCountry,
            String unregisteredReason,
            String unregisteredNote) {

        MerchantGenerationService merchantGenerationService = new MerchantGenerationService();

        return merchantGenerationService.generateMerchantWithCdd(firstName, billingIban, pqCountry, unregisteredReason, unregisteredNote, this.cddData());
    }

    private CddData cddData() {
        CddData cddData = new CddData();
        cddData.setCddStatus(CddStatus.ACCEPTED);
        cddData.setLegalName(TestConstants.CDD_DATA_LEGAL_NAME);
        cddData.setTradeNames(tradeNames());
        cddData.setChamberOfCommerceId(TestConstants.CHAMBER_OF_COMMERCE_ID);
        cddData.setStatutoryAddress(this.addressHit());
        cddData.setPersons(List.of(this.person()));
        return cddData;
    }

    private List<String> tradeNames() {
        List<String> tradeNames = new ArrayList<>();
        tradeNames.add(TestConstants.TRADE_NAME);

        return tradeNames;
    }

    private Address address() {
        Address statutoryAddress = new Address();
        statutoryAddress.setCity("Brussels");
        statutoryAddress.setCountry(Country.BEL);
        statutoryAddress.setNo("123");
        statutoryAddress.setPostalCode("1050");
        statutoryAddress.setStreet("Rue du midi");
        return statutoryAddress;
    }

    private Address addressHit() {
        Address statutoryAddress = new Address();
        statutoryAddress.setCity("San Andrea");
        statutoryAddress.setCountry(Country.COL);
        statutoryAddress.setNo("37");
        statutoryAddress.setPostalCode("7904");
        statutoryAddress.setStreet(TestConstants.STREET_NAME);
        return statutoryAddress;
    }

    private CddPerson person() {
        CddPerson person = new CddPerson();
        person.firstName(bpcRandomName());
        person.lastName(bpcRandomName());
        person.gender(Gender.M);
        person.placeOfBirth("Belgium");
        person.dateOfBirth(LocalDate.now());
        person.nationality(TestConstants.NATIONALITY);
        person.roles(List.of(CddPerson.RolesEnum.UBO, CddPerson.RolesEnum.LR));
        person.personalAddress(this.address());
        return person;
    }

    public ObjectId insertMerchant(Merchant merchantObject) {
        payconiqMerchantMongoRepository.save(merchantObject);
        System.out.println("merchantId = " + merchantObject.getId());

        return merchantObject.getId();
    }

    public Optional<Merchant> findCreatedMerchantInMerchantMongo(ObjectId merchantId) {
        log.info("{} merchant has been created", merchantId);
        return payconiqMerchantMongoRepository.findById(merchantId);
    }

    public Optional<ProfiledMerchant> findProfiledMerchantInProfiledMerchantMongo(ObjectId merchantId) {
        log.info("{} merchant has been profiled", merchantId);
        return profiledMerchantMongoRepository.findById(merchantId);

    }

    public Optional<BpcProfiledMerchant> findStreamedProfiledMerchantInBpcProfiledMongo(String id) {
        log.info("{} merchant has been streamed to profiledMerchants collection in bpcDataSharingEmulator", id);
        return bpcProfiledMerchantMongoRepository.findById(id);

    }

    public String bpcRandomName() {
        return TestConstants.FIRST_NAME + (int) (Math.random() * 1000);
    }

    public void assertBpcMerchantIsCreated(ObjectId merchantId) {
        try {
            Awaitility.await()
                    .atMost(5, TimeUnit.SECONDS)
                    .untilAsserted(() -> assertThat(findCreatedMerchantInMerchantMongo(merchantId)).isNotEmpty());
        } catch (Exception e) {
            throw new RuntimeException("Merchant has not been created --> " + e.getMessage());
        }
    }

    public void assertBpcMerchantIsProfiled(ObjectId merchantId) {
        try {
            Awaitility.await()
                    .atMost(30, TimeUnit.SECONDS)
                    .untilAsserted(() -> assertThat(findProfiledMerchantInProfiledMerchantMongo(merchantId)).isNotEmpty());
        } catch (Exception e) {
            throw new RuntimeException("Merchant has not been profiled --> " + e.getMessage());
        }
    }

    public void assertProfiledBpcMerchantIsStreamed(String id) {
        try {
            Awaitility.await()
                    .pollDelay(3, TimeUnit.SECONDS)
                    .untilAsserted(() -> {
                        final Optional<BpcProfiledMerchant> profiledMerchantInBpcMongo = findStreamedProfiledMerchantInBpcProfiledMongo(id);
                        assertThat(profiledMerchantInBpcMongo).isNotNull();
                        assertThat(profiledMerchantInBpcMongo.get().getId()).isEqualTo(id);

                    });
        } catch (Exception e) {
            throw new RuntimeException("Merchant has not been streamed to Emulator --> " + e.getMessage());
        }

    }

    public void assertMappingValues(ObjectId merchantId) throws JSONException, JsonProcessingException {

        ObjectMapper objectMapper = new ObjectMapper();
        String profiledMerchant = objectMapper.writeValueAsString(findProfiledMerchantInProfiledMerchantMongo(merchantId).get());
        String profiledMerchantInEmulator = objectMapper.writeValueAsString(findStreamedProfiledMerchantInBpcProfiledMongo(merchantId.toString()).get());
        Assertions.assertEquals(findProfiledMerchantInProfiledMerchantMongo(merchantId).get().getId().toString(), findStreamedProfiledMerchantInBpcProfiledMongo(merchantId.toString()).get().getId());
        Assertions.assertNotEquals(findProfiledMerchantInProfiledMerchantMongo(merchantId).get().getReviewed(), findStreamedProfiledMerchantInBpcProfiledMongo(merchantId.toString()).get().getReviewed());

        JSONAssert.assertEquals(profiledMerchant, profiledMerchantInEmulator, JSONCompareMode.LENIENT);

    }


    public void deleteCreatedMerchantFromMerchantsCollection(ObjectId merchantId) {
        payconiqMerchantMongoRepository.deleteById(merchantId);
        log.info("{} is deleted from payconiqMerchant/merchants collection", merchantId);
    }

    public void deleteProfiledMerchantFromProfiledMerchantCollection(ObjectId merchantId) {
        profiledMerchantMongoRepository.deleteById(merchantId);
        log.info("{} is deleted from merchantProfilingService/profiledMerchants collection", merchantId);
    }

    public void deleteStreamedMerchantFromEmulator(String merchantId) {
        bpcMerchantMongoRepository.deleteBpcMerchantByMerchantId(merchantId);
        log.info("{} is deleted from bpcDataSharingEmulator/merchants collection", merchantId);
    }

    public void deleteProfiledMerchantFromEmulator(String merchantId) {
        bpcProfiledMerchantMongoRepository.deleteBpcProfiledMerchantById(merchantId);
        log.info("{} is deleted from bpcDataSharingEmulator/profiledMerchants collection", merchantId);

    }

}
