package com.payconiq.mpbis.acceptance.model.emulator;

import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.MongoId;
@Data
@Document(collection = "merchants")
public class BpcMerchant {
    @MongoId
    private String merchantId;
}
