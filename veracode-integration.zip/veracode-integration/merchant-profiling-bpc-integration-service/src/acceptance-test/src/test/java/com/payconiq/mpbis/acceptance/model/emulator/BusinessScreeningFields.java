package com.payconiq.mpbis.acceptance.model.emulator;

import lombok.Data;

@Data
public class BusinessScreeningFields {
    private String companyName;
    private String chamberOfCommerceId;;
}
