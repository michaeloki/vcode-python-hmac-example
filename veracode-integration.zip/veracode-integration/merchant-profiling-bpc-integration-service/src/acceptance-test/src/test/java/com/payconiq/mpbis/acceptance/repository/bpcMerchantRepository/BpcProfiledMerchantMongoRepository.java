package com.payconiq.mpbis.acceptance.repository.bpcMerchantRepository;


import com.payconiq.mpbis.acceptance.model.emulator.BpcProfiledMerchant;
import org.jetbrains.annotations.NotNull;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface BpcProfiledMerchantMongoRepository extends MongoRepository<BpcProfiledMerchant, String> {

    @NotNull
    Optional<BpcProfiledMerchant> findById(final String id);

    void deleteBpcProfiledMerchantById(final String id);

}

