package com.payconiq.mpbis.acceptance.config;

import com.payconiq.testing.config.Configuration;
import lombok.experimental.UtilityClass;

@UtilityClass
public class TestConstants {


public static final String FIRST_NAME = "Bpcds";
    public static final String CDD_DATA_LEGAL_NAME ="PMBPCDS";
    public static final String TRADE_NAME ="CORPORACION HOTELERA DEL CARIBE LIMITADA";
    public static final String STREET_NAME ="Avenida Colombia";
    public static final String CHAMBER_OF_COMMERCE_ID ="CoC_01";
    public static final String TEST_IBAN = "BE69549564556178";
    public static final String PQ_COUNTRY = "BEL";
    public static final String NATIONALITY = "BEL";
    private static final Configuration configuration = new Configuration();

    public static String getConfigKey(String key) {
        return configuration.get(key);
    }
}
