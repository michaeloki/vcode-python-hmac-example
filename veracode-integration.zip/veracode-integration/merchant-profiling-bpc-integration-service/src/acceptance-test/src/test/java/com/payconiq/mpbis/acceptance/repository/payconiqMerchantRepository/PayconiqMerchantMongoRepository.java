package com.payconiq.mpbis.acceptance.repository.payconiqMerchantRepository;

import com.payconiq.testing.data.generator.model.merchant.Merchant;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PayconiqMerchantMongoRepository extends MongoRepository<Merchant, ObjectId> {
}
