package com.payconiq.mpbis.acceptance.model.profiledMerchant;


import lombok.Getter;

@Getter
public enum ScreeningEventType {
     PERIODIC,
     INITIAL,
     MERCHANT_UPDATE;


}
