package com.payconiq.mpbis.acceptance.model.emulator;


import lombok.Getter;

@Getter
public enum ScreeningEventType {
     PERIODIC,
     INITIAL,
     MERCHANT_UPDATE;


}
