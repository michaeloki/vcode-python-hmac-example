package com.payconiq.mpbis.acceptance.test;

import com.epam.reportportal.junit5.ReportPortalExtension;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.payconiq.mpbis.acceptance.config.*;
import com.payconiq.mpbis.acceptance.repository.bpcMerchantRepository.BpcMerchantMongoRepository;
import com.payconiq.mpbis.acceptance.services.MerchantService;
import lombok.extern.slf4j.Slf4j;
import org.bson.types.ObjectId;
import org.json.JSONException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;


@ExtendWith(SpringExtension.class)
@ExtendWith(ReportPortalExtension.class)
@ContextConfiguration(classes = {GeneralConfig.class,
        BpcProfiledMerchantMongoConfig.class,
        PayconiqMerchantMongoConfig.class,
        ProfiledMerchantMongoConfig.class,
        BpcMerchantMongoRepository.class,
        MerchantService.class,
})
@Slf4j

public class MPBISAcceptanceTest {
    @Autowired
    private MerchantService merchantService;

    @Test
    @DisplayName("When a merchant is onboarded it should be profiled")
    public void bpc_merchant_should_be_streamed_to_bpcDataSharingEmulator() throws JSONException, JsonProcessingException {
        String userFirstName = merchantService.bpcRandomName();
        final ObjectId merchantId = merchantService.insertMerchant(
                merchantService.merchantWithCdd(
                        userFirstName,
                        TestConstants.TEST_IBAN,
                        TestConstants.PQ_COUNTRY,
                        "BpcdsTest",
                        "BpcdsTest"));

        // Assert the created Bpc Merchant data in payconiqMerchant/merchants collection
        merchantService.assertBpcMerchantIsCreated(merchantId);

        // Assert the created Bpc Merchant is profiled
        merchantService.assertBpcMerchantIsProfiled(merchantId);

        // Assert the profiled Bpc Merchant is streamed
        merchantService.assertProfiledBpcMerchantIsStreamed(merchantId.toString());

        // Assert the profiled Merchant Mapper
        merchantService.assertMappingValues(merchantId);

        // Delete created and streamed data
        merchantService.deleteCreatedMerchantFromMerchantsCollection(merchantId);
        merchantService.deleteProfiledMerchantFromProfiledMerchantCollection(merchantId);
        merchantService.deleteStreamedMerchantFromEmulator(merchantId.toString());
        merchantService.deleteProfiledMerchantFromEmulator(merchantId.toString());


    }

}
