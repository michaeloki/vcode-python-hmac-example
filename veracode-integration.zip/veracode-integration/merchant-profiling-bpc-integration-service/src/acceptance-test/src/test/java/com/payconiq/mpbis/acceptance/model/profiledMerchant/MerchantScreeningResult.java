package com.payconiq.mpbis.acceptance.model.profiledMerchant;

import lombok.Getter;

@Getter
public enum MerchantScreeningResult {
    HIT,
    NO_HIT,
    FALSE_POSITIVE
}
