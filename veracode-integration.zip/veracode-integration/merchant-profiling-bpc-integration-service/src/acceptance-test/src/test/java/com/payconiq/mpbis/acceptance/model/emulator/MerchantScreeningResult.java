package com.payconiq.mpbis.acceptance.model.emulator;

import lombok.Getter;

@Getter
public enum MerchantScreeningResult {
    HIT,
    NO_HIT,
    FALSE_POSITIVE
}
