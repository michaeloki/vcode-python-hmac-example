package com.payconiq.mpbis.acceptance.model.profiledMerchant;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.Date;
@Data
public class BusinessScreeningData {
    private BusinessScreeningFields businessScreeningFields;
    private Date checkDate;
    private ScreeningEventType eventType;
    private MerchantScreeningResult result;
    @JsonProperty("lexisNexisAlert")
    private LexisNexisAlert alert;
}
