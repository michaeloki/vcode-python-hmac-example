package com.payconiq.mpbis.acceptance.model.emulator;

import lombok.Getter;

@Getter
public enum LexisNexisHitReason {
    PEP,
    ADVERSE_MEDIA,
    SANCTION,
    OTHER;
}
