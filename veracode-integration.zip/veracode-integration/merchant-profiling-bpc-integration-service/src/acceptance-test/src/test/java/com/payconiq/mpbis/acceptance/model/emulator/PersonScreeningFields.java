package com.payconiq.mpbis.acceptance.model.emulator;

import lombok.Data;

import java.util.Date;
@Data
public class PersonScreeningFields {
    private String firstName;
    private String lastName;
    private Date dateOfBirth;
    private String nationality;
    private String countryOfResidence;
}
