package com.payconiq.mpbis.util;


import com.payconiq.merchant.profiling.v1.topic.MerchantProfilingV1;
import com.payconiq.merchant.service.api.v1.model.CddStatus;
import com.payconiq.merchant.service.api.v1.model.CompleteCddData;
import com.payconiq.merchant.service.api.v1.model.MerchantDetails;
import com.payconiq.merchant.service.api.v1.model.PqCountry;
import com.payconiq.mpbis.client.MerchantApiClient;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class ProfiledMerchantValidatorTest {
    @Mock
    private MerchantApiClient merchantApiClient;

    @InjectMocks
    private ProfiledMerchantValidator profiledMerchantValidator;

    private MerchantDetails activeBELMerchant;
    private MerchantDetails inactiveBELMerchant;
    private MerchantDetails unregisteredBELMerchant;
    private MerchantDetails unregisteredBELMerchantBeforeMay2;
    private MerchantDetails unregisteredBELMerchantAfterMay2;

    @BeforeEach
    void setUp() {
        activeBELMerchant = new MerchantDetails();
        activeBELMerchant.setPqCountry(PqCountry.BEL);

        inactiveBELMerchant = new MerchantDetails();
        inactiveBELMerchant.setPqCountry(PqCountry.BEL);

        unregisteredBELMerchant = new MerchantDetails();
        unregisteredBELMerchant.setPqCountry(PqCountry.BEL);
        unregisteredBELMerchant.setCddData(new CompleteCddData());
        unregisteredBELMerchant.getCddData().setCddStatus(CddStatus.UNREGISTERED);
        unregisteredBELMerchant.setUnregisteredAt(OffsetDateTime.now());

        unregisteredBELMerchantBeforeMay2 = new MerchantDetails();
        unregisteredBELMerchantBeforeMay2.setPqCountry(PqCountry.BEL);
        unregisteredBELMerchantBeforeMay2.setCddData(new CompleteCddData());
        unregisteredBELMerchantBeforeMay2.getCddData().setCddStatus(CddStatus.UNREGISTERED);
        unregisteredBELMerchantBeforeMay2.setUnregisteredAt(OffsetDateTime.of(2023, 5, 1, 15, 0, 0, 0, ZoneOffset.UTC));

        unregisteredBELMerchantAfterMay2 = new MerchantDetails();
        unregisteredBELMerchantAfterMay2.setPqCountry(PqCountry.BEL);
        unregisteredBELMerchantAfterMay2.setCddData(new CompleteCddData());
        unregisteredBELMerchantAfterMay2.getCddData().setCddStatus(CddStatus.UNREGISTERED);
        unregisteredBELMerchantAfterMay2.setUnregisteredAt(OffsetDateTime.of(2023, 5, 2, 0, 0, 1, 0, ZoneOffset.UTC));
    }

    @Test
    void testIsTestProfiledMerchantNullProfiledMerchantReturnsFalse() {
        assertFalse(profiledMerchantValidator.isBPCProfiledMerchant(null));
    }

    @Test
    void testIsTestProfiledstudentActiveBELMerchantReturnsTrue() {
        MerchantProfilingV1.ProfiledMerchant profiledMerchant =
                MerchantProfilingV1.ProfiledMerchant.newBuilder().
                        setActive(true).
                        setCountry("BEL").
                        build();

        assertTrue(profiledMerchantValidator.isBPCProfiledMerchant(profiledMerchant));
    }

    @Test
    void testIsValidUnregisteredBELMerchantReturnsTrue() {
        MerchantProfilingV1.ProfiledMerchant profiledMerchant =
                MerchantProfilingV1.ProfiledMerchant.newBuilder().
                        setActive(false).
                        setCountry("BEL").
                        setMerchantId("123").
                        build();

        when(merchantApiClient.getMerchantDetailsById("123")).thenReturn(unregisteredBELMerchant);
        assertTrue(profiledMerchantValidator.isBPCProfiledMerchant(profiledMerchant));
    }

    @Test
    void testIsUnregisteredBELMerchantBeforeMay2ReturnsFalse() {
        MerchantProfilingV1.ProfiledMerchant profiledMerchant =
                MerchantProfilingV1.ProfiledMerchant.newBuilder().
                        setActive(false).
                        setCountry("BEL").
                        setMerchantId("123").
                        build();

        when(merchantApiClient.getMerchantDetailsById("123")).thenReturn(unregisteredBELMerchantBeforeMay2);
        assertFalse(profiledMerchantValidator.isBPCProfiledMerchant(profiledMerchant));
    }

    @Test
    void testIsUnregisteredBELMerchantAfterMay2ReturnsTrue() {
        MerchantProfilingV1.ProfiledMerchant profiledMerchant =
                MerchantProfilingV1.ProfiledMerchant.newBuilder().
                        setActive(false).
                        setCountry("BEL").
                        setMerchantId("123").
                        build();

        when(merchantApiClient.getMerchantDetailsById("123")).thenReturn(unregisteredBELMerchantAfterMay2);
        assertTrue(profiledMerchantValidator.isBPCProfiledMerchant(profiledMerchant));
    }
}
