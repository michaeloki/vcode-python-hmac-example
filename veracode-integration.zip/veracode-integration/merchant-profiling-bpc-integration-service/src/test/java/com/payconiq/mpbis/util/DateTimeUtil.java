package com.payconiq.mpbis.util;

import com.google.protobuf.Timestamp;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;

public class DateTimeUtil {
    public static Timestamp timeStampFromLocalDate(LocalDate localDate) {
        Instant instant = localDate.atStartOfDay(ZoneOffset.UTC).toInstant();

        return Timestamp.newBuilder()
                .setSeconds(instant.getEpochSecond())
                .setNanos(instant.getNano())
                .build();
    }
}
