package com.payconiq.mpbis.listener;

import com.payconiq.integration.bpc.datasharing.merchant_profiling.v1.model.PutProfilingMerchantRequest;
import com.payconiq.merchant.profiling.v1.topic.MerchantProfilingV1;
import com.payconiq.mpbis.client.MerchantApiClient;
import com.payconiq.mpbis.config.BPCServiceProperties;
import com.payconiq.mpbis.exception.RetryableException;
import com.payconiq.mpbis.json.JsonUtil;
import com.payconiq.mpbis.mapstruct.ProfiledMerchantMapper;
import com.payconiq.mpbis.service.BpcProfiledMerchantDataSharingEndpoint;
import com.payconiq.mpbis.service.ProfiledMerchantDataProcessService;
import com.payconiq.mpbis.util.JWSHelper;
import com.payconiq.mpbis.util.ProfiledMerchantValidator;
import com.payconiq.mpbis.util.TestUtil;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okhttp3.mockwebserver.RecordedRequest;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.reactive.function.client.WebClient;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertThrows;

@Slf4j
public class ProfiledMerchantDataListenerTest extends AbstractControllerIT {

    @Autowired
    private JWSHelper jwsHelper;
    @Autowired
    private ProfiledMerchantMapper profiledMerchantMapper;
    @Autowired
    private BPCServiceProperties bpcServiceProperties;

    private WebClient webClient;

    private ProfiledMerchantDataListener profiledMerchantDataListener;

    private ProfiledMerchantValidator profiledMerchantValidator;

    private ProfiledMerchantDataProcessService profiledMerchantDataProcessService;

    private BpcProfiledMerchantDataSharingEndpoint bpcProfiledMerchantDataSharingEndpoint;

    private final MockWebServer mockWebServer = new MockWebServer();

    private MerchantApiClient merchantApiClient;

    @BeforeEach
    @SneakyThrows
    public void setup() {
        mockWebServer.start();
        webClient = WebClient.builder().build();

        bpcServiceProperties.setPutUri(mockWebServer.url("/profiled-merchants/").toString());
        bpcProfiledMerchantDataSharingEndpoint =
                new BpcProfiledMerchantDataSharingEndpoint(bpcServiceProperties, webClient, jwsHelper);

        profiledMerchantValidator = new ProfiledMerchantValidator(merchantApiClient);
        profiledMerchantDataProcessService = new ProfiledMerchantDataProcessService(profiledMerchantMapper, bpcProfiledMerchantDataSharingEndpoint, profiledMerchantValidator);

        profiledMerchantDataListener = new ProfiledMerchantDataListener(profiledMerchantDataProcessService);
    }

    @Test
    @SneakyThrows
    public void shouldReturnSuccessfulNoContent() {
        sendEventAndCheckResult(HttpStatus.OK);
    }

    @SneakyThrows
    private void sendEventAndCheckResult(HttpStatus status) {

        MockResponse mockResponse = new MockResponse().setResponseCode(status.value());

        final String profiledMerchantId = TestUtil.getProfiledMerchantId();
        MerchantProfilingV1.ProfiledMerchant profiledMerchantProto = TestUtil.createProfiledMerchantProto(profiledMerchantId);
        PutProfilingMerchantRequest putProfilingMerchantRequest = new PutProfilingMerchantRequest();

        try {
            profiledMerchantMapper.mapProfiledMerchantProtoToProfiledMerchantPojo(profiledMerchantProto, putProfilingMerchantRequest);
        } catch (Exception e) {
            log.error(e.getMessage());
        }

        String requestBodyString = JsonUtil.serialize(putProfilingMerchantRequest);
        mockWebServer.enqueue(mockResponse.setBody(requestBodyString));

        callOnConsumerEvent(profiledMerchantProto);

        RecordedRequest recordedRequest = mockWebServer.takeRequest();
        Assertions.assertEquals("PUT", recordedRequest.getMethod());
        Assertions.assertEquals(bpcServiceProperties.getPutUri().concat(profiledMerchantId), String.valueOf(recordedRequest.getRequestUrl()));
        Assertions.assertEquals(requestBodyString, recordedRequest.getBody().readUtf8());
    }

    private void callOnConsumerEvent(final MerchantProfilingV1.ProfiledMerchant profiledMerchantProto) {

        profiledMerchantDataListener.onProfiledMerchantEvent(
                profiledMerchantProto,
                2,
                "event.merchant-profiling-service.profiled-merchants.test.v1",
                3345,
                "test-topic",
                () -> log.info("message consumed")
        );
    }

    @Test
    @SneakyThrows
    public void shouldReturnExceptionBadRequest() {
        sendEventAndAssertRetriableExceptions(HttpStatus.BAD_REQUEST);
    }


    @Test
    @SneakyThrows
    public void shouldReturnExceptionUnauthorized() {
        sendEventAndAssertRetriableExceptions(HttpStatus.UNAUTHORIZED);
    }

    @Test
    @SneakyThrows
    public void shouldReturnExceptionForbidden() {
        sendEventAndAssertRetriableExceptions(HttpStatus.FORBIDDEN);
    }

    @Test
    @SneakyThrows
    public void shouldReturnExceptionInternalServerError() {
        sendEventAndAssertRetriableExceptions(HttpStatus.INTERNAL_SERVER_ERROR);
    }

    private void sendEventAndAssertRetriableExceptions(HttpStatus status) {
        RetryableException thrown = assertThrows(
                RetryableException.class,
                () -> sendEventAndCheckResult(HttpStatus.INTERNAL_SERVER_ERROR),
                "this should throw RetryableException"
        );
        assertTrue(thrown.getMessage().contains("Operation will be retried for profiledMerchantId"));
    }

    @AfterEach
    @SneakyThrows
    public void tearDown() {
        mockWebServer.shutdown();
    }

}
