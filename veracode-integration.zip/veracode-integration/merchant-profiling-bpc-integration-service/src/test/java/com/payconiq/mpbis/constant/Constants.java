package com.payconiq.mpbis.constant;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class Constants {

    public static final String BPCDS = "BPCDS";

    public static final String COUNTRY = "BEL";

    public static final String IBAN = "NL45HMRQ9320785755";

    public static final String NAME = "Name";
}
