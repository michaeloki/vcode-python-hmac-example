package com.payconiq.mpbis.util;

import com.payconiq.merchant.profiling.v1.topic.MerchantProfilingV1;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.kafka.clients.consumer.ConsumerRecord;

import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.List;


public class TestUtil {


    public static ConsumerRecord<String, MerchantProfilingV1.ProfiledMerchant> createProfiledMerchantEventRecord(String profiledMerchantId) {
        MerchantProfilingV1.ProfiledMerchant profiledMerchant = createProfiledMerchantProto(profiledMerchantId);
        return new ConsumerRecord<>("event.merchant-profiling-service.profiled-merchants.test.v1",
                2, 39045, profiledMerchantId, profiledMerchant);
    }

    public static MerchantProfilingV1.ProfiledMerchant createProfiledMerchantProto(String profiledMerchantId) {
        return MerchantProfilingV1.ProfiledMerchant.newBuilder()
                .setMerchantId(profiledMerchantId)
                .setLastModified(DateTimeUtil.timeStampFromLocalDate(LocalDate.now(ZoneOffset.UTC)))
                .setActive(true)
                .setCountry("BEL")
                .setReviewed(true)
                .setPeriodicScreeningCheckDate(DateTimeUtil.timeStampFromLocalDate(LocalDate.now(ZoneOffset.UTC)))
                .addBusinessScreeningData(createBusinessScreeningData())
                .addPersonScreeningData(createPersonScreeningData())
                .build();
    }

    private static MerchantProfilingV1.PersonScreeningData createPersonScreeningData() {
        return MerchantProfilingV1.PersonScreeningData.newBuilder()
                .setLastName("Van de Verde")
                .setDateOfBirth(DateTimeUtil.timeStampFromLocalDate(LocalDate.now(ZoneOffset.UTC).minusYears(50L)))
                .setFirstName("Dave")
                .setNationality("NLD")
                .setCountryOfResidence("NLD")
                .setScreeningData(createScreeningData())
                .build();
    }

    private static MerchantProfilingV1.BusinessScreeningData createBusinessScreeningData() {
        return MerchantProfilingV1.BusinessScreeningData.newBuilder()
                .setCompanyName("Company co")
                .setChamberOfCommerceId(getProfiledMerchantId())
                .setAddress(createAddress())
                .setScreeningData(createScreeningData())
                .build();
    }

    private static MerchantProfilingV1.ScreeningData createScreeningData() {
        return MerchantProfilingV1.ScreeningData.newBuilder()
                .setCheckDate(DateTimeUtil.timeStampFromLocalDate(LocalDate.now(ZoneOffset.UTC)))
                .setEventType(MerchantProfilingV1.ScreeningData.ScreeningEventType.INITIAL)
                .setResult(MerchantProfilingV1.ScreeningData.ScreeningDataResult.HIT)
                .setAlertId("1234567890")
                .addAllHitReasons(createHitReasons())
                .setAlertClosed(true)
                .build();
    }

    private static Iterable<? extends MerchantProfilingV1.ScreeningData.HitReason> createHitReasons() {
        return List.of(MerchantProfilingV1.ScreeningData.HitReason.PEP,
                MerchantProfilingV1.ScreeningData.HitReason.ADVERSE_MEDIA,
                MerchantProfilingV1.ScreeningData.HitReason.SANCTION,
                MerchantProfilingV1.ScreeningData.HitReason.OTHER);
    }

    private static MerchantProfilingV1.Address createAddress() {
        return MerchantProfilingV1.Address.newBuilder()
                .setStreet("Hill Street")
                .setNumber("3")
                .setPostalCode("123456")
                .setCity("Amsterdam")
                .setCountry("NLD")
                .build();
    }

    public static String getProfiledMerchantId() {
        return RandomStringUtils.randomAlphanumeric(24);
    }


}