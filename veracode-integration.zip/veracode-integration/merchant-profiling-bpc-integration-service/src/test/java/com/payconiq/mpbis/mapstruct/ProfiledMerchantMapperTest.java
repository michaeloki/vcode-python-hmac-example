package com.payconiq.mpbis.mapstruct;

import com.google.protobuf.Timestamp;
import com.payconiq.integration.bpc.datasharing.merchant_profiling.v1.model.BusinessScreeningData;
import com.payconiq.integration.bpc.datasharing.merchant_profiling.v1.model.LexisNexisAlert;
import com.payconiq.integration.bpc.datasharing.merchant_profiling.v1.model.PersonScreeningData;
import com.payconiq.integration.bpc.datasharing.merchant_profiling.v1.model.PutProfilingMerchantRequest;
import com.payconiq.merchant.profiling.v1.topic.MerchantProfilingV1;
import com.payconiq.mpbis.util.TestUtil;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Objects;
import java.util.stream.IntStream;

@ActiveProfiles("test")
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class ProfiledMerchantMapperTest {


    @Autowired
    private ProfiledMerchantMapper profiledMerchantMapper;

    private static void assertAlertClosed(Boolean closed, boolean alertClosed) {
        if (Objects.nonNull(closed)) {
            Assertions.assertEquals(closed, alertClosed);
        }
    }

    @Test
    void mapProfiledMerchantProtoToProfiledMerchantPojo() {
        MerchantProfilingV1.ProfiledMerchant profiledMerchantProto = TestUtil.createProfiledMerchantProto(TestUtil.getProfiledMerchantId());
        PutProfilingMerchantRequest profilingRequest = new PutProfilingMerchantRequest();

        profiledMerchantMapper.mapProfiledMerchantProtoToProfiledMerchantPojo(profiledMerchantProto, profilingRequest);

        assertMapping(profilingRequest, profiledMerchantProto);
    }

    private void assertMapping(PutProfilingMerchantRequest profilingRequest, MerchantProfilingV1.ProfiledMerchant profiledMerchantProto) {
        assertDates(profilingRequest.getLastModified(), profiledMerchantProto.getLastModified());
        Assertions.assertEquals(profilingRequest.getActive(), profiledMerchantProto.getActive());
        Assertions.assertEquals(profilingRequest.getCountry().name(), profiledMerchantProto.getCountry());
        Assertions.assertEquals(profilingRequest.getReviewed(), profiledMerchantProto.getReviewed());
        assertDates(profilingRequest.getPeriodicScreeningCheckDate(), profiledMerchantProto.getPeriodicScreeningCheckDate());

        assertBusinessScreeningData(profilingRequest.getBusinessScreeningDataList(), profiledMerchantProto.getBusinessScreeningDataList());
        assertPersonScreeningData(profilingRequest.getPersonScreeningDataList(), profiledMerchantProto.getPersonScreeningDataList());
    }

    private void assertBusinessScreeningData(List<BusinessScreeningData> businessScreeningDataList, List<MerchantProfilingV1.BusinessScreeningData> protoBusinessScreeningDataList) {
        Assertions.assertEquals(businessScreeningDataList.size(), protoBusinessScreeningDataList.size());
        IntStream.range(0, businessScreeningDataList.size()).forEach(i -> {
            BusinessScreeningData bsd = businessScreeningDataList.get(i);
            MerchantProfilingV1.BusinessScreeningData protoBsd = protoBusinessScreeningDataList.get(i);
            Assertions.assertEquals(bsd.getBusinessScreeningFields().getCompanyName(), protoBsd.getCompanyName());
            Assertions.assertEquals(bsd.getBusinessScreeningFields().getChamberOfCommerceId(), protoBsd.getChamberOfCommerceId());
            assertScreeningData(bsd, protoBsd.getScreeningData());
        });
    }

    private void assertScreeningData(BusinessScreeningData bsd, MerchantProfilingV1.ScreeningData protoScreeningData) {
        assertDates(bsd.getCheckDate(), protoScreeningData.getCheckDate());
        Assertions.assertEquals(bsd.getEventType().name(), protoScreeningData.getEventType().name());
        Assertions.assertEquals(bsd.getResult().name(), protoScreeningData.getResult().name());
        assertLexisNexisAlert(bsd.getLexisNexisAlert(), protoScreeningData);
    }

    private void assertHitReasons(List<LexisNexisAlert.LexisNexisHitReasonsEnum> lexisNexisHitReasons, List<MerchantProfilingV1.ScreeningData.HitReason> protoHitReasonsList) {
        Assertions.assertEquals(lexisNexisHitReasons.size(), protoHitReasonsList.size());
        IntStream.range(0, lexisNexisHitReasons.size()).forEach(j -> Assertions.assertEquals(lexisNexisHitReasons.get(j).name(), protoHitReasonsList.get(j).name()));
    }

    private void assertPersonScreeningData(List<PersonScreeningData> personScreeningDataList, List<MerchantProfilingV1.PersonScreeningData> protoPersonScreeningDataList) {
        Assertions.assertEquals(personScreeningDataList.size(), protoPersonScreeningDataList.size());
        IntStream.range(0, personScreeningDataList.size()).forEach(i -> {
            PersonScreeningData personScreeningData = personScreeningDataList.get(i);
            MerchantProfilingV1.PersonScreeningData protoPersonScreeningData = protoPersonScreeningDataList.get(i);
            Assertions.assertEquals(personScreeningData.getPersonScreeningFields().getLastName(), protoPersonScreeningData.getLastName());
            assertDates(personScreeningData.getPersonScreeningFields().getDateOfBirth(), protoPersonScreeningData.getDateOfBirth());
            Assertions.assertEquals(personScreeningData.getPersonScreeningFields().getFirstName(), protoPersonScreeningData.getFirstName());
            Assertions.assertEquals(personScreeningData.getPersonScreeningFields().getNationality().name(), protoPersonScreeningData.getNationality());
            Assertions.assertEquals(personScreeningData.getPersonScreeningFields().getCountryOfResidence().name(), protoPersonScreeningData.getCountryOfResidence());
            assertScreeningData(personScreeningData, protoPersonScreeningData.getScreeningData());
        });
    }

    private void assertScreeningData(PersonScreeningData personScreeningData, MerchantProfilingV1.ScreeningData screeningData) {
        assertDates(personScreeningData.getCheckDate(), screeningData.getCheckDate());
        Assertions.assertEquals(personScreeningData.getEventType().name(), screeningData.getEventType().name());
        Assertions.assertEquals(personScreeningData.getResult().name(), screeningData.getResult().name());
        assertLexisNexisAlert(personScreeningData.getLexisNexisAlert(), screeningData);
    }

    private void assertLexisNexisAlert(LexisNexisAlert lexisNexisAlert, MerchantProfilingV1.ScreeningData screeningData) {
        if (Objects.nonNull(lexisNexisAlert)) {
            Assertions.assertEquals(lexisNexisAlert.getAlertId(), screeningData.getAlertId());
            assertAlertClosed(lexisNexisAlert.getClosed(), screeningData.getAlertClosed());
            assertHitReasons(lexisNexisAlert.getLexisNexisHitReasons(), screeningData.getHitReasonsList());
        }
    }


    private void assertDates(OffsetDateTime requestDate, Timestamp merchantProfileProtoDate) {
        OffsetDateTime protoOffsetDateTime = ProfiledMerchantMapperFunctions.mapTimeStampToOffsetDateTimeUTC(merchantProfileProtoDate);
        Assertions.assertEquals(requestDate, protoOffsetDateTime);
    }

}