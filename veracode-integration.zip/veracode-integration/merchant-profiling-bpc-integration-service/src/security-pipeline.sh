#!/bin/bash

# Define the downstream pipeline ID
DOWNSTREAM_PIPELINE_ID="your_downstream_pipeline_id"

# Set the GitLab API endpoint URL
GITLAB_API_URL="https://aervnajvnf.com"

# Set the API token for authenticating with GitLab
GITLAB_API_TOKEN="your_api_token"

# Use the GitLab API to check the status of the downstream pipeline
curl -X GET \
  $GITLAB_API_URL/pipelines/${DOWNSTREAM_PIPELINE_ID} \
  -H 'Authorization: Bearer '$GITLAB_API_TOKEN

# Check the status of the downstream pipeline
if [ "$(echo "$RESPONSE" | jq -r '.status')" = 'success' ]; then
  echo "Downstream pipeline is successful"
else
  echo "Downstream pipeline is failed"
fi
