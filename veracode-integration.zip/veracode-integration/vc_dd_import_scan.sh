#!/bin/bash
source generic_response.sh

# prerequisites:
# - debian/ubuntu
# - curl, jq
# - java

scanTypeMsg="import:sast_results_to_defectdojo"
function _exit_error() {
  msg=$1
  echo "$msg"
  if [ -f "pipeline_stage_tracker.txt" ]; then
    content=$(cat pipeline_stage_tracker.txt)
    modified_content=$(echo "$content" | jq '.scanType += ['\""$scanTypeMsg"\"']' )
    cd ..
    echo "$modified_content" > pipeline_stage_tracker.txt
    echo "The modified content of the pipeline_stage_tracker.txt file is $modified_content"
    cd artifacts || return
  else
    json_object=$(echo '{}' | jq '. + {"status": "FAIL", "summary":'"$msg"', "appName": "", "scanType": ["'$scanTypeMsg'"],
    "message": "'$scanTypeMsg'   failed"}')
    cd ..
    echo "$json_object" > pipeline_stage_tracker.txt
    echo "$json_object was successfully saved in $(pwd)"
    cd artifacts || return
  fi
  _print "$1"
  touch "$problem_file"
  exit 1
}


# Check integration stuff.
[ "$DD_API_KEY" = "" ] && stop_feedback "No API key defined for defectdojo ($DD_API_KEY)" "$scanTypeMsg"

VC_BUILD_ID=$1
DD_APP_NAME=$2
DD_TAG=$3
key_id=$4
secret=$5
echo "VC_BUILD_ID IS $VC_BUILD_ID DD_APP_NAME is $DD_APP_NAME and DD_TAG is $DD_TAG "
# Default params
DD_API="https://dms.payconiq.io"
DD_ENGAGEMENT_BASENAME="veracode_auto_import_"
DD_DEFAULT_NEW_APP_DESCR="App. Automatically created because of veracode scan"
[ -z "$CVSS_THRESHOLD" ] && CVSS_THRESHOLD=7
curl_opts=( "--silent" "-H"  "Authorization: Token ${DD_API_KEY}" "-H"  "accept: application/json" "-H" "Connection: keep-alive" "--keepalive-time" 2 )

# Defaults
export basepwd=$PWD
pid=$$
rid=$(LC_CTYPE=C tr -dc A-Za-z0-9 < /dev/urandom | fold -w 8 | head -n 1)
my_dir=$(cd "$(dirname "$0")" && pwd)
problem_file="${my_dir}/.vc_dd_import_kaput"

function _print() {
  msg="  > [${pid}] "$1
  echo "$msg"
}


function vc_report_getinfo() {
  "${my_dir}/node_modules/.bin/vc_report_getinfo" "$@"
}

if [ "$VC_BUILD_ID" = "" ] || [ "$DD_APP_NAME" = "" ]; then
  _print "Arguments missing."
  _print "Usage: $0 [veracode build ID] [defectdojo app name]"
  _print "To use a local report, use a filename ending with  '.xml' instead of a build ID."
  stop_feedback _print "$scanTypeMsg"
fi

npm install >/dev/null 2>&1 || _exit_error "Cannot install NPM packages; make sure to fix permissions or package.json".

# Setup veracode API.
source "${my_dir}/_api.sh"


# Fetch app report.
if [[ $VC_BUILD_ID == *\.xml ]]; then
  report_file=$VC_BUILD_ID
  [ ! -f "$report_file" ] && _exit_error "Report [$report_file] does not exist!"
  _print "Importing [${report_file}] into [${DD_APP_NAME}]"
else
  _print "Fetching report from Veracode for build [$VC_BUILD_ID]"
  report_file=$basepwd"/${rid}.tmp"
  report_response=$(api detailedreport -buildid "$VC_BUILD_ID" -outputfilepath "$report_file"  2>&1)
  status=$?
  if [ $status -ne 0 ]; then
    no_report_available=$(echo "$report_response" | grep "No report available")
    [ "$no_report_available" = "" ] &&  _print "Couldn't fetch report" && _exit_error "$report_response"
    _print "No report for this app yet" && exit 0
  fi
fi

# Regular XML import.
tag="veracode_ci"
[ "$DD_TAG" != "" ] && tag="${DD_TAG}"
"${my_dir}/dd_import_report.sh" "$report_file" "$DD_APP_NAME" "Veracode Scan" "veracode_auto_import_${VC_BUILD_ID}" "${tag}"
status=$?
[ $status -ne 0 ] && _exit_error "dd_import_report.sh (XML) failed (${status})"

# License info CSV.
report_output=$(vc_report_getinfo --report="$report_file" --info=license --cvss_threshold="${CVSS_THRESHOLD}")
status=$?
[ $status -eq 1 ] && _exit_error "ERROR extracting license info: ${report_output}"

# Build CSV.
csv_file=$basepwd"/${rid}.csv"
_csv_header="Date,Title,CweId,Url,Severity,Description,Mitigation,Impact,References,Active,Verified,FalsePositive,Duplicate"
echo "$_csv_header" > "$csv_file"
export csv_file

echo "Show the status number for DD CWE fix $status" # remove this after the fix

if [ $status -eq 2 ] || [ $status -eq 3 ]; then
  _date=$(date +%m/%d/%Y)
  _title="Non-allowed licensed dependencies in use"
  _cwe="9999"
  _url=""
  [ $status -eq 2 ] && _severity="Critical" || _severity="Medium"
  _description="$report_output" # Assuming no '"' in output.
  _mitigation="Remove non-allowed dependencies and scan again."
  _impact="Possibly legal obligation to make software open source."
  

  echo "\"${_date}\",\"${_title}\",\"${_cwe}\",\"${_url}\",\"${_severity}\",\"${_description}\",\"${_mitigation}\",\"${_impact}\",\"\",\"true\",\"true\",\"false\",\"false\"" >> "$csv_file"
fi



# Import.
tag="vc_os_license"
"${my_dir}/dd_import_report.sh" "$csv_file" "$DD_APP_NAME" "Generic Findings Import" "veracode_auto_import_${VC_BUILD_ID}" "${tag}"
status=$?
[ $status -ne 0 ] && _exit_error "dd_import_report.sh (CSV) failed (${status})"

#JSON import
"${my_dir}/export_setup.sh" "$key_id" "$secret" "$DD_APP_NAME"

# Import SCA findings using JSON
"${my_dir}/vc_dd_export.sh" "$DD_APP_NAME" "$DD_API_KEY"
status=$?
[ $status -ne 0 ] && _exit_error "vc_dd_export.sh (JSON) failed (${status})"
_print "done"

exit 0
