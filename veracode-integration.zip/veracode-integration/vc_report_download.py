import sys
import requests
from veracode_api_signing.plugin_requests import RequestsAuthPluginVeracodeHMAC
import argparse
import os
import json

headers = {"User-Agent": "Veracode HMAC"}

api_base = "https://api.veracode.com/appsec/"

def get_app_profile(key_id, secret, app_name):
    try:
        if len(str(app_name)) > 1:
            response = (requests.get
                        (api_base + "v1/applications/?name=" + str(app_name),
                         auth=RequestsAuthPluginVeracodeHMAC
                         (api_key_id=key_id,
                          api_key_secret=secret),
                         headers=headers))
            if response.ok:
                data = response.json()
                print("======== Extracting the GUID from the application profile ========")
                findings(data["_embedded"]["applications"][0]["guid"], key_id, secret, app_name)
            else:
                print(response.status_code)
        else:
            print("App name is empty")
    except requests.RequestException as e:
        print("Whoops!")
        print(e)
        sys.exit(1)

def findings(guid: str, key_id: str, secret:str, app_name:str):
    print("Fetching VC findings for GUID " + guid)
    try:
        response = (requests.get
                    (api_base + "v2/applications/" + guid + "/findings?scan_type=SCA&severity_gte=1",
                     auth=RequestsAuthPluginVeracodeHMAC
                     (api_key_id=key_id,
                      api_key_secret=secret),
                     headers=headers))
        # filename = re.sub('[^a-zA-Z0-9_]', '_', app_name)
        # filename = filename+'.json'
        if response.ok:
            data = response.json()
            # print(f"data is ${data}")
            print('The DIR in vc_report is ' + os.getcwd())
            json_payload = json.dumps(data)
            file_path = os.path.join('', 'temp_report.json')
            with open(file_path, 'w') as f:
                f.write(json_payload)
            if os.path.isfile(file_path):
                print("The SCA JSON payload was successfully created")
    except Exception as e:
        print('Current DIR in vc_report '+ os.getcwd())
        print(f"[54@vc_report_download] Exception is ${e}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--arg1", type=str, help="First string argument:key_id")
    parser.add_argument("--arg2", type=str, help="Second string argument:secret")
    parser.add_argument("--arg3", type=str, help="Third string argument:appname")

    args = parser.parse_args()

    print("Python script called...")

    get_app_profile(args.arg1, args.arg2, args.arg3)
