#!/bin/bash
key_id=$1
secret=$2
dd_app_name=$3
if python3 --version &>/dev/null; then
    # Check if pip is installed
    pip3_check=$(whereis pip3)
    if [ -z "$pip3_check" ]; then
      apt-get -y install python3-venv python-pip-whl python3-distutils python3-lib2to3 python3.9-venv > /dev/null 2>&1
    fi
    if python3 -m pip list | grep -i requests; then
      python3 -m venv secenv
      source secenv/bin/activate
      echo "vc_report_download.py will be invoked for $dd_app_name"
      python3 vc_report_download.py --arg1 "$key_id" --arg2 "$secret" --arg3 "$dd_app_name"
    else
      # Install prerequisites for Python 3
      echo "Package 'requests' should be installed for Python 3."
      echo "Installing dependencies..."
      apt-get -y install python3-venv python-pip-whl python3-distutils python3-lib2to3 python3.9-venv > /dev/null 2>&1
      python3 -m venv secenv
      source secenv/bin/activate
      pip3 install -r requirements.txt -q
      if pip3 list | grep -q requests; then
        echo "Package 'requests' is already installed for Python 3."
        echo "vc_report_download.py is being invoked for $dd_app_name"
        python3 vc_report_download.py --arg1 "$key_id" --arg2 "$secret" --arg3 "$dd_app_name"
        deactivate
      fi
    fi
else
    echo "Python 3 is not installed. Please install Python 3 first."
    exit 1
fi
