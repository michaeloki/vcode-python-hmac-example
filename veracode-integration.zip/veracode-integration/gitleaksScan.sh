#!/bin/bash
source generic_response.sh
# prerequisites:
# - debian/ubuntu
# - nodejs, gitleaks

scanTypeMsg="analysis:gitleaks"


# Check integration stuff.
[ -z "$CI_API_V4_URL" ] && stop_feedback "No Gitlab API defined" "$scanTypeMsg"
[ -z "$CALLING_CI_PROJECT_PATH" ] && stop_feedback "No project namespace" "$scanTypeMsg"
[ -z "$GL_SECURITY_PAT" ] && stop_feedback "No GL_SECURITY_PAT . Cannot interact with gitlab API" "$scanTypeMsg"
[ "$DD_API_KEY" = "" ] && stop_feedback "Wrapper: No API key defined for defectdojo (DD_API_KEY)" "$scanTypeMsg"
[ -z "$CALLING_CI_COMMIT_SHA" ] && stop_feedback "No $CALLING_CI_COMMIT_SHA set" "$scanTypeMsg"
[ -z "$CALLING_CI_PROJECT_ID" ] && stop_feedback "No project ID" "$scanTypeMsg"

# Script config.
[ -z "$CVSS_THRESHOLD" ] && CVSS_THRESHOLD=7
[ -z "$SCAN_DEPTH_COMMITS" ] && SCAN_DEPTH_COMMITS=500

# Defaults
GITLAB_HOST="gitlab.payconiq.io"
export basepwd=$PWD
my_dir=$(cd "$(dirname "$0")" && pwd)
[ "$CALLING_SCAN_MASTER_BRANCH" != "" ] && master_branch=$CALLING_SCAN_MASTER_BRANCH || master_branch="master"
# project_name: 'sre/devops/security/sample-nodejs-application' > 'security/sample-nodejs-application'
gitlab_short_name="$(basename "$(dirname "$CALLING_CI_PROJECT_PATH")")/$(basename "$CALLING_CI_PROJECT_PATH")"
project_name="${gitlab_short_name}[gl${CALLING_CI_PROJECT_ID}]"
short_sha=$(git rev-parse --short "${CALLING_CI_COMMIT_SHA}")

# Is this a master-branch commit triggered scan ?
is_master_commit=
if [ ! $is_mergerequest ]; then
  [ "$CALLING_CI_COMMIT_BRANCH" == "$master_branch" ] && is_master_commit=1
fi

# Only perform on master branch changes.
[ ! $is_master_commit ] && echo "No master-ish branch commit. No need for sca scan." && exit 0


# Clone project repo, enter folder
echo "Cloning https://${GITLAB_HOST}/${CALLING_CI_PROJECT_PATH}.git/"
mkdir git_project && cd git_project && \
  git init && \
  git remote add origin "https://gitlab-ci-token:${CI_JOB_TOKEN}@${GITLAB_HOST}/${CALLING_CI_PROJECT_PATH}.git/" && \
  git fetch --depth="${SCAN_DEPTH_COMMITS}" origin "${CALLING_CI_COMMIT_SHA}" && \
  git reset --hard FETCH_HEAD
[ $? -ne 0 ] && stop_feedback "Unable to clone repository"

# Scan.
report_file="gitleaks.json"
SECONDS=0
gitleaks detect --config "${my_dir}/gitleaks_conf.toml" \
  --log-opts "-n ${SCAN_DEPTH_COMMITS}" \
  --report-path "$report_file" \
  --source . \
  --exit-code 0
status=$?
duration=$SECONDS
echo "Scan done, took ${duration} seconds"

# Make empty report to import no findings (close old ones).
if [ $status -eq 0 ] && [ ! -f "$report_file" ]; then
  echo '[]' > "$report_file"
fi

# Import to DD.
[ -f "$report_file" ] && \
  "${my_dir}/dd_import_report.sh" "$report_file" "$project_name" "Gitleaks Scan" "gitleaks_auto_import_${short_sha}" \
    "gitleaks"
echo "==== gitleak status is $status ===="
if [ $status = 1 ]; then
  stop_feedback "Unexpected error" "$scanTypeMsg"
fi
exit $status
