## Enhanced evaluation 
- Check the outcome of the analysis stage and run the script as before - DONE
- If there's an issue in any of the jobs under the analysis stage, write FAIL to the evaluation file - DONE
- Confirm there's nothing wrong with the analysis stage, else fail the pipeline and return a JSON object - DONE
- Use this to address git leaks check and also see the  https://gitlab.payconiq.io/sec/veracode-integration/-/pipelines/434679 
- Evaluation_output.txt is just a one-liner while pipeline_stage_tracker.txt is a stage tracker 
- Use https://gitlab.payconiq.io/sec/veracode-integration/-/jobs/2060734 https://gitlab.payconiq.io/sec/veracode-integration/-/jobs/2060735 and https://gitlab.payconiq.io/sec/veracode-integration/-/jobs/2060736 to fix the empty findings in the py - DONE