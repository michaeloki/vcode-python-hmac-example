#!/bin/bash

# prerequisites:
# - debian/ubuntu
# - curl, jq

# Check integration stuff.
[ "$DD_API_KEY" = "" ] && echo 'No API key defined for defectdojo (DD_API_KEY)' && exit 1
[ "$H1_USER" = "" ] && echo 'No API user defined for HackerOne (H1_USER)' && exit 1
[ "$H1_TOKEN" = "" ] && echo 'No API key defined for HackerOne (H1_TOKEN)' && exit 1

DD_APP_NAME=hackerone_reports
H1_PROGRAM_NAME=payconiq

# Default params
DD_ENGAGEMENT="hackerone_continuous_import"
curl_opts=( "--silent" "-u" "${H1_USER}:${H1_TOKEN}" "-H"  "accept: application/json" "-H" "Connection: keep-alive" "--keepalive-time" 2 )

# Defaults
export basepwd=$PWD
my_dir=$(cd "$(dirname "$0")" && pwd)

function _print() {
  echo -e "$1"
}

function _exit_error() {
  _print "$1"
  exit 1
}

# Fetch app report.
_print "Fetching reports from HackerOne"
next_url=
failure=0
while true; do
  output=
  if [ ! $next_url ]; then
    output=$(curl "https://api.hackerone.com/v1/reports/" \
      "${curl_opts[@]}" \
      --get \
      --data-urlencode "filter[program][]=${H1_PROGRAM_NAME}" \
      --data-urlencode "filter[state][]=triaged" \
      --data-urlencode "filter[state][]=retesting" \
       2>/dev/null)
  else
    output=$(curl "$next_url" \
      "${curl_opts[@]}" \
      --get 2>/dev/null)
  fi

  error=$(echo "${output}" | jq -r ".errors")
  if [ "$error" != "" ] && [ "$error" != "null" ]; then
    _exit_error "H1 API responded with an error: \n${output}"
  fi

  rid=$(LC_CTYPE=C tr -dc A-Za-z0-9 < /dev/urandom | fold -w 8 | head -n 1)
  report_file=".h1_report_${rid}.json"
  echo "$output" > "$report_file"
  echo ""
  echo "Importing paged report"
  "${my_dir}/dd_import_report.sh" "$report_file" "$DD_APP_NAME" "HackerOne Cases" "${DD_ENGAGEMENT}" "hackerone"
  [ $? -ne 0 ] && failure=1 && echo "Importing report failed" && echo "--" && echo "${output}" && echo "--"

  # Continue as long as we got pages.
  next_url=$(echo "${output}" | jq -r ".links.next")
  if [ "$next_url" = "" ] || [ "$next_url" = "null" ]; then
    break;
  fi
done
exit $failure
