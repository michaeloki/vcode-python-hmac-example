#!/bin/bash
source generic_response.sh
# prerequisites:
# - debian/ubuntu
# - jq, curl
# - docker, srcclr
# - working docker registry (to pull from) (already authenticated)
scanTypeMsg="analysis:image-scan"
# Check integration stuff.
[ -z "$CALLING_CI_PROJECT_PATH" ] && stop_feedback "No project namespace" "$scanTypeMsg"
[ -z "$CALLING_CI_PROJECT_ID" ] && stop_feedback "No project ID" "$scanTypeMsg"
[ "$DD_API_KEY" = "" ] && stop_feedback "Wrapper: No API key defined for defectdojo ($DD_API_KEY)" "$scanTypeMsg"
[ -z "$CALLING_CI_COMMIT_SHA" ] && stop_feedback "No CALLING_CI_COMMIT_SHA set" "$scanTypeMsg"
[ -z "$CALLING_SOURCE_IMAGE_NAME" ] && stop_feedback "No CALLING_SOURCE_IMAGE_NAME set" "$scanTypeMsg"
[ -z "$CALLING_SOURCE_IMAGE_VERSION" ] && stop_feedback "No CALLING_SOURCE_IMAGE_VERSION set" "$scanTypeMsg"
[ -z "$DOCKER_REGISTRY_DEFAULT" ] && stop_feedback "DOCKER_REGISTRY_DEFAULT not set (e.g. 'registry.acc.payconiq.io')" "$scanTypeMsg"
[ -z "$DOCKER_LOGIN" ] && stop_feedback "No DOCKER_LOGIN set" "$scanTypeMsg"
[ -z "$DOCKER_PASSWORD" ] && stop_feedback "No DOCKER_PASSWORD set" "$scanTypeMsg"
[ -z "$SRCCLR_API_TOKEN" ] && stop_feedback "No SRCCLR_API_TOKEN . Cannot interact with veracode sourceclear" "$scanTypeMsg"

# Defaults
GITLAB_HOST="gitlab.payconiq.io"
export basepwd=$PWD
my_dir=$(cd "$(dirname "$0")" && pwd)
[ "$CALLING_SCAN_MASTER_BRANCH" != "" ] && master_branch=$CALLING_SCAN_MASTER_BRANCH || master_branch="master"
# gitlab_short_name: 'sre/devops/security/sample-nodejs-application' > 'security/sample-nodejs-application'
gitlab_short_name="$(basename "$(dirname "$CALLING_CI_PROJECT_PATH")")/$(basename "$CALLING_CI_PROJECT_PATH")"
project_name="${gitlab_short_name}[gl${CALLING_CI_PROJECT_ID}]"

short_sha=$(git rev-parse --short "${CALLING_CI_COMMIT_SHA}")

# Is this a master-branch commit triggered scan ?
is_master_commit=
if [ ! $is_mergerequest ]; then
  [ "$CALLING_CI_COMMIT_BRANCH" == "$master_branch" ] && is_master_commit=1
fi

# Only perform on master branch changes.
[ ! $is_master_commit ] && echo "No master-ish branch commit. No need for image scan." && exit 0


# Login docker registry.
docker login -u "$DOCKER_LOGIN" -p "$DOCKER_PASSWORD" "${DOCKER_REGISTRY_DEFAULT}"
[ $? -ne 0 ] && stop_feedback "Unable to authenticate against docker registry (${DOCKER_LOGIN}@${DOCKER_REGISTRY_DEFAULT})" \ "$scanTypeMsg"

# Scan
image="${DOCKER_REGISTRY_DEFAULT}/${CALLING_SOURCE_IMAGE_NAME}:${CALLING_SOURCE_IMAGE_VERSION}"
echo "Scanning image [${image}]"
#scan_output=$(curl -sSL https://sca-downloads.veracode.com/ci.sh | sh -s scan --no-upload --image "$image")
#echo "Inspecting the image {docker inspect --format='{{.Config.Digest}}' $image}"
apt-get -qq update
apt-get -qq install -y apt-transport-https ca-certificates curl software-properties-common
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | apt-key add -
add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable"
apt-get -qq update
apt-get -qq install -y docker-ce
# Start Docker service
systemctl start docker
systemctl enable docker

scan_output=$(srcclr scan --no-upload --image "$image")

status=$?
[ $status -ne 0 ] && echo "Scan failed" && stop_feedback "${scan_output}" "$scanTypeMsg"
echo -e "Scan done. Output:\n====\n${scan_output}\n====\n\n"


num_high=$(echo -en "$scan_output" | egrep 'High Risk Vulnerabilities' | sed -r 's/^.*\b([0-9]+)$.*$/\1/')
num_medium=$(echo -en "$scan_output" | egrep 'Medium Risk Vulnerabilities' | sed -r 's/^.*\b([0-9]+)$.*$/\1/')
num_low=$(echo -en "$scan_output" | egrep 'Low Risk Vulnerabilities' | sed -r 's/^.*\b([0-9]+)$.*$/\1/')

# Check parsing.
! [[ $num_high =~ ^[0-9]+$ ]] && echo "Parsing report failed. Expected 'High Risk Vulnerabilities  [number]'." \
  && stop_feedback "${scan_output}" "$scanTypeMsg"

# Set severity.
severity=
if [ "$num_high" != "0" ]; then
  severity=High
elif [ "$num_medium" != "0" ]; then
  severity=Medium
elif [ "$num_low" != "0" ]; then
  severity=Low
fi

# Build CSV.
csv='"Date","Title","CweId","Url","Severity","Description","Mitigation","Impact","References","Active","Verified"'"\n"
if [ "$severity" = "" ]; then
  echo "No issues found"
else
  _date=$(date +%m/%d/%Y)
  _title="Image has ${severity}-severity vulnerabilities"
  _cwe=937
  _url=
  _severity=$severity
  _description="Image \`${image}\` has packages with known vulnerabilities.\nSee 'Impact' for detailed report."
  _mitigation="Rebuild the image with latest versions / upstream image"
  _impact=$scan_output
  _references=
  _active="True"
  _verified="True"
  csv=$csv"\"${_date}\",\"${_title}\",${_cwe},\"${_url}\",\"${_severity}\",\"${_description}\",\"${_mitigation}\",\"${_impact}\",\"${_references}\",\"${_active}\",\"${_verified}\""
fi
echo -e "$csv" > report.csv

# Import to DD.
echo "Reporting to defectdojo, project [${project_name}]"
"${my_dir}/dd_import_report.sh" report.csv "$project_name" "Generic Findings Import" "imagescan_${short_sha}" \
    "srcclr_imagescan"
exit $?
