#!/bin/bash

echo "{'status':'FAIL', 'summary':'The build stage failed'}" > artifact.txt

exit 1
