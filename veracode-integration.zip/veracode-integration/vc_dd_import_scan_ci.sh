#!/bin/bash
source generic_response.sh

# Defaults
my_dir=$(cd "$(dirname "$0")" && pwd)
scanTypeMsg="import:sast_results_to_defectdojo"

SOURCE_COMMIT_BRANCH=$1
VERACODE_API_KEY_ID=$2
VERACODE_API_KEY_SECRET=$3
if [ "$SOURCE_COMMIT_BRANCH" != "master" ] && [ -z "$SOURCE_COMMIT_BRANCH" ]; then
    exit 0
fi


DD_APP=
VC_BUILD=
MASTER_EVENT=
MR_EVENT=
# Check dynamic_file.txt if .dd_app is missing and populate DD_APP to avoid warnings in the pipeline
[ -f .dd_app ] && DD_APP=$(cat .dd_app) || DD_APP=$(cat dynamic_file.txt)
[ -f .vc_build ] && VC_BUILD=$(cat .vc_build)
echo "VC_BUILD in vc_dd_import_scan_ci is $VC_BUILD"
[ "$DD_APP" = "" ] && stop_feedback "Can't import, app-name not set earlier" "$scanTypeMsg"
[ "$VC_BUILD" = "" ] && stop_feedback "Can't import, app-build-nr not set earlier" "$scanTypeMsg"
[ -f .ci_master_event ] && MASTER_EVENT=1
[ -f .ci_mr_event ] && MR_EVENT=1

echo "Application: ${DD_APP}"
echo "Build ID: ${VC_BUILD}"

if [ $MASTER_EVENT ]; then
  # Turned off since Vc report does not contain component info (software_composition_analysis) the first ~30 min.
#  exit 0

  # Tagging defectdojo test with 'ci', in order to be able to report on scan coverage.
  "${my_dir}/vc_dd_import_scan.sh" "$VC_BUILD" "$DD_APP" "veracode_ci" "$VERACODE_API_KEY_ID" "$VERACODE_API_KEY_SECRET"
  status=$?
  [ $status -ne 0 ] && echo "vc_dd_import_scan.sh failed (${status})" && exit $status
elif [ $MR_EVENT ]; then
  "${my_dir}/dd_import_report.sh" "-" "$DD_APP" "Veracode Scan" "veracode_mr_${VC_BUILD}" "veracode_ci_mr"
else
  echo "Nothing to do. Not a MR or master-branch change."
  exit 0
fi

exit 0
