#!/bin/bash

# prerequisites:
# - debian/ubuntu
# - curl, xmllint
# - java

scanTypeMsg="analysis"
function fatal_error() {
  msg=$1
  if [ -f "pipeline_stage_tracker.txt" ]; then
    content=$(cat pipeline_stage_tracker.txt)
    # modified_content=$(echo "$content" | jq '.summary |= . + '."$msg".' ')
    modified_content=$(echo "$content" | jq '.scanType += ['\""$scanTypeMsg"\"']' )
    cd ..
    echo "$modified_content" > pipeline_stage_tracker.txt
    echo "The new content of pipeline_stage_tracker.txt is $modified_content"
    cd artifacts || return
  else
    echo "===== Creating JSON payload ===== "
    json_object=$(echo '{}' | jq '. + {"status": "FAIL", "summary":"'"$msg"'", "appName": "", "scanType": ["'$scanTypeMsg'"], "message": "The '$scanTypeMsg' stage failed"}')
    cd ..
    echo "$json_object" > pipeline_stage_tracker.txt
    echo "$json_object was successfully saved in $(pwd) [ca1]"
    cd artifacts || return
  fi
  exit 1
}

# Check integration stuff.
[ -z "$CI_API_V4_URL" ] && fatal_error "No Gitlab API defined"
[ -z "$CALLING_CI_PROJECT_PATH" ] && fatal_error "No project namespace"
[ -z "$CALLING_CI_PROJECT_ID" ] && fatal_error "No project ID"
[ -z "$GL_SECURITY_PAT" ] && fatal_error "No GL_SECURITY_PAT . Cannot interact with gitlab API"
# [ -z $CALLING_CI_JOB_TOKEN ] && echo "No CI_JOB_TOKEN passed. Cannot download artifacts from pipeline job." && exit 1

# Veracode config.
[ -z "$VERACODE_GUIDING_DOC_URL" ] && VERACODE_GUIDING_DOC_URL="https://payconiq.atlassian.net/wiki/spaces/IT/pages/1127579640/Veracode+SAST+SCA"
[ -z "$CVSS_THRESHOLD" ] && CVSS_THRESHOLD=7
[ -z "$WAIT_TIMEOUT_SEC" ] && WAIT_TIMEOUT_SEC=3200
[ -z "$VERACODE_DEFAULT_TEAM" ] && VERACODE_DEFAULT_TEAM="IT_Dept"

# Defaults
export basepwd=$PWD
message_title="## Security analysis"
message_guidance=
sandbox_name=
sandbox_list_xml=
duration=
remove_old_sandboxes_threshold=19
my_dir=$(cd "$(dirname "$0")" && pwd)
uploaded_artifact_dump=${my_dir}/uploaded_file
uploaded_artifact_name_dump=${my_dir}/uploaded_filename.txt
[ "$CALLING_SCAN_MASTER_BRANCH" != "" ] && master_branch=$CALLING_SCAN_MASTER_BRANCH || master_branch="master"
# project_name: 'sre/devops/security/sample-nodejs-application' > 'security/sample-nodejs-application'
gitlab_short_name="$(basename "$(dirname "$CALLING_CI_PROJECT_PATH")")/$(basename "$CALLING_CI_PROJECT_PATH")"

# Is this a MR triggered scan ?
is_mergerequest=
[ "$CALLING_CI_MERGE_REQUEST_IID" != "" ] && is_mergerequest=1

# Is this a master-branch commit triggered scan ?
is_master_commit=
if [ ! $is_mergerequest ]; then
  [ "$CALLING_CI_COMMIT_BRANCH" == "$master_branch" ] && is_master_commit=1
fi

# Only scan if this is a sandbox (MR) policy scan,
# or when we need a normal policy scan (commits to master-ish branch).
[ ! $is_mergerequest ] && [ ! $is_master_commit ] && echo "No MR or master-ish branch commit. No need for policy scan." && exit 0

function find_app_in_applist_xml() {
  "${my_dir}/node_modules/.bin/vc_find_app_in_applist_xml" "$@"
}
function vc_report_getinfo() {
  "${my_dir}/node_modules/.bin/vc_report_getinfo" "$@"
}

# MR feedback wrapper.
discussion_id=
note_id=
function mr_message() {
  msg_markdown=$1
  resolve_thread=$2

  if [ "$GL_SECURITY_PAT" != "" ]; then
    if [ $is_mergerequest ] && [ "$CALLING_CI_PROJECT_ID" != "" ]; then

      # Add help section.
      message_guidance_generate
      msg_markdown=$msg_markdown"
<details> \n
<summary>Click to see job details and guidance</summary> \n
${message_guidance}
</details> \n"

      # Fix newlines (\n to nl)
      msg_markdown=$(echo -e "$msg_markdown")

      # Find existing MR messages if they exist.
      findOldMrMessage

      # Make new note, and update later on.
      if [ -z "$note_id" ]; then
        discussion_output=$(curl --silent -X POST -g \
          --header "PRIVATE-TOKEN: $GL_SECURITY_PAT" \
          --data-urlencode "body=${msg_markdown}" \
          "${CI_API_V4_URL}/projects/${CALLING_CI_PROJECT_ID}/merge_requests/${CALLING_CI_MERGE_REQUEST_IID}/discussions")
        discussion_id=$(echo "$discussion_output" | jq .id)
        note_id=$(echo "$discussion_output" | jq .notes[0].id)
      else
        curl --silent -X PUT -g \
          --header "PRIVATE-TOKEN: $GL_SECURITY_PAT" \
          --data-urlencode "body=${msg_markdown}" \
          "${CI_API_V4_URL}/projects/${CALLING_CI_PROJECT_ID}/merge_requests/${CALLING_CI_MERGE_REQUEST_IID}/discussions/${discussion_id}/notes/${note_id}"
      fi

      # Resolve or unresolve thread.
      [ -n "$resolve_thread" ] && resolve_param=true || resolve_param=false
      curl --silent -X PUT -g \
        --header "PRIVATE-TOKEN: $GL_SECURITY_PAT" \
        "${CI_API_V4_URL}/projects/${CALLING_CI_PROJECT_ID}/merge_requests/${CALLING_CI_MERGE_REQUEST_IID}/discussions/${discussion_id}?resolved=${resolve_param}"
    fi
  else
    echo "My PAT is empty. Cannot add MR message with feedback."
  fi
}

function findOldMrMessage() {
  if [ -z "$discussion_id" ] || [ -z "$note_id" ]; then

    _page=1
    while true; do
      # Fetch paged data.
      _discussions_json=$(curl --silent -X GET -g \
          --header "PRIVATE-TOKEN: $GL_SECURITY_PAT" \
          "${CI_API_V4_URL}/projects/${CALLING_CI_PROJECT_ID}/merge_requests/${CALLING_CI_MERGE_REQUEST_IID}/discussions?page=${_page}&page_size=50")
      [ $? -ne 0 ] && echo "Problem with API:" && echo -e "$_discussions_json" && break
      [ "$_discussions_json" = "" ] && echo "Empty JSON received" && break;
      [ "$(echo "$_discussions_json" | jq -r length)" = "0" ] && break # No results on this 'page'.

      # Parse the right message.
      _discussion=$(echo "$_discussions_json" | jq -c 'last(.[] | select(.individual_note == false) | select(.notes[0].body | test("^(## Security analysis|# SAST)")))')
      if [ $? ] && [ "$_discussion" != "" ] && [ "$_discussion" != "null" ]; then
        discussion_id=$(echo "$_discussion" | jq -r .id)
        note_id=$(echo "$_discussion" | jq -r .notes[0].id)
        if [ $? -ne 0 ]; then
          # Something odd. Reset empty.
          discussion_id=
          note_id=
        else
          break # Discussion found.
        fi
      fi

      ((_page++))
    done
  fi
}

function stop_feedback() {
  msg=$1
  echo "$msg"
  if [[ $msg =~ .*results\ processing\ has\ failed.* ]]; then
    exit 0
  fi
  mr_message "${message_title}  \nScan stopped:  \n>>>\n${msg}\n>>>"
  if [ -f "pipeline_stage_tracker.txt" ]; then
    content=$(cat pipeline_stage_tracker.txt)
    modified_content=$(echo "$content" | jq '.scanType += ['\""$scanTypeMsg"\"']' )
    cd ..
    echo "$modified_content" > pipeline_stage_tracker.txt
    echo "The new content === $modified_content"
    cd artifacts || return
  else
    json_object=$(echo '{}' | jq '. + {"status": "FAIL", "summary":"'"$msg"'", "appName": "", "scanType": ["'$scanTypeMsg'"],
"message": "The analysis stage failed"}')
    cd ..
    echo "$json_object" > pipeline_stage_tracker.txt
    echo "$json_object was successfully saved in $(pwd) [ca]"
    cd artifacts || return
  fi
  exit 1
}

message_guidance=
# Guidance text generator. Provide some argument to have it update text.
function message_guidance_generate() {
  if [ "$message_guidance" = "" ] || [ "$1" != "" ]; then
    message_guidance=
    message_guidance=$message_guidance"\n [Visit my job](${CI_JOB_URL})  "
    message_guidance=$message_guidance"\n Find more info on Veracode and how to get scanresults in your IDE on [this confluence page](${VERACODE_GUIDING_DOC_URL}).  "
    message_guidance=$message_guidance"\n Project name: \`${project_name}\`  "

    if [ -n "$sandbox_name" ]; then
      message_guidance=$message_guidance"\n Sandbox name: \`${sandbox_name}\`  "
    fi
    if [ -n "$duration" ]; then
      message_guidance=$message_guidance"\n Scan took ${duration} seconds  "
    fi
  fi
}

function delete_sandbox_by_name() {
  _app_id=$1
  _sandbox_name=$2
  if [ "$sandbox_list_xml" = "" ]; then
    sandbox_list_xml=$(api getsandboxlist -appid "${_app_id}")
  fi
  sandbox_id=
  sandbox_id=$(echo "${sandbox_list_xml}" | xmllint --xpath "string(//*[local-name()='sandbox'][@sandbox_name='${_sandbox_name}']/@sandbox_id)" -)
  if [ $sandbox_id ]; then
    api deletesandbox "-sandboxid" "${sandbox_id}" > /dev/null 2>&1
  fi
}

# Remove all sandboxes for app, except 20 most recent ones.
# VC sandboxes are capped at max 25, so avoiding getting stuck with this.
function cleanup_old_sandboxes() {
  _app_id=$1
  if [ "$sandbox_list_xml" = "" ]; then
    sandbox_list_xml=$(api getsandboxlist -appid "${_app_id}")
  fi
  sandbox_nr=0
  sandbox_nr=$(echo "$sandbox_list_xml" | xmllint --xpath "count(//*[local-name()='sandbox'])" -)
  echo "Project has ${sandbox_nr} sandboxes"

  # Get all sandbox ID's from list.
  # Assuming numerical ID's, the higher the newer.
  sandbox_id_list=( )
  for ((i=0;i<$sandbox_nr;i++)); do
      sandbox_id=$(echo "${sandbox_list_xml}" | xmllint --xpath "string(//*[local-name()='sandbox'][${i}]/@sandbox_id)" -)
      sandbox_id_list+=( "$sandbox_id" )
  done

  # Sort, newest first.
  oldIFS=$IFS
  IFS=$'\n' sandbox_id_list=($(sort -rg <<<"${sandbox_id_list[*]}"))
  IFS=$oldIFS

  # Remove every sandbox, except most recent 20 ones.
  for _id in "${sandbox_id_list[@]:$remove_old_sandboxes_threshold}"; do
    _name=$(echo "${sandbox_list_xml}" | xmllint --xpath "string(//*[local-name()='sandbox'][@sandbox_id='${_id}']/@sandbox_name)" -)
    echo "Removing sandbox [${_name}]"
    api deletesandbox "-sandboxid" "$_id" > /dev/null 2>&1
  done
}

# Update app name (if it exists) in veracode based on gitlab id and gitlab appname.
# This echo's the correct app-name to use (regardless if it exists or not).
app_name_combined=
function checkAndCorrectAppName() {
  echo "Checking VC appname."
  _gitlab_id=$1
  _app_name=$2
  _app_name_combined="${_app_name}[${_gitlab_id}]"

  _parsed_output=$(api getapplist | find_app_in_applist_xml --external_app_id "$_gitlab_id" --app_name "$_app_name" 2>&1)
  _status=$?
  if [ $_status -eq 0 ]; then
    _parsed_output=(${_parsed_output[@]})
    _app_id_vc=${_parsed_output[0]}
    _app_name_vc=${_parsed_output[1]}
    export vc_app_name=$_app_name_vc
    echo "Found app in veracode: ${_parsed_output} and the app name is $vc_app_name"
    cd ..
    echo "$vc_app_name" > dynamic_file.txt
    value=$(cat dynamic_file.txt)
    echo "The saved app name is $value and the directory is $(pwd)"
    cd artifacts || return


    # Update name in Veracode.
    if [ "$_app_id_vc" != "" ] && [ "$_app_name_vc" != "" ]; then
      if [ "$_app_name_vc" != "$_app_name_combined" ]; then
        echo "Need to rename VC app [${_app_name_vc}] to [${_app_name_combined}]"
        _output=$(api updateapp -appid "$_app_id_vc" -appname "$_app_name_combined" 2>&1)
        if [ $? -ne 0 ]; then
          echo "Failed updating app:"
          echo "=="
          echo -e "$_output"
          echo "=="
        fi
      fi
    fi
  elif [ $_status -eq 2 ]; then
    echo "App not present yet"
  else
    echo "Failed fetching applist:"
    echo "=="
    echo -e "$_parsed_output"
    echo "=="
  fi

  app_name_combined=$_app_name_combined
}

function downloadVcReport() {
  build_id=$1
  report_file=$2
  timeout=$3
  [ -z "$timeout" ] && timeout=0

  echo -n "Waiting max $timeout seconds for report "
  while true; do
    report_response=$(api detailedreport -buildid "$build_id" -outputfilepath "$report_file"  2>&1)
    status=$?

    [ $status -eq 0 ] && break # success
    [ $status -ne 2 ] && echo -e "\nUnexpected API response" && echo -e "$report_response" && stop_feedback "API Error: $report_response"
    if [[ "$report_response" == *"returned HTTP"* ]]; then
      echo "==== The full API response is ==== $report_response"
      # "Write the report to a json file and import it into json  "
      echo "The current dir is $(pwd)"
      echo -e "\nNo build in veracode ($build_id), something wrong"
      exit 0
      stop_feedback "Something wrong, build wasn't created in VC"
    fi

    [ $SECONDS -gt $timeout ] && echo -e "\nTimeout: giving up on report..." && stop_feedback "Timeout, I stopped waiting for the report"
    echo -n "."
    sleep 20
  done
}

if [ ! -d "$my_dir"/node_modules ]; then
  oldpwd=$PWD
  cd "$my_dir"
  _npm_out=$(npm install 2>&1)
  [ $? -ne 0 ] && stop_feedback "Cannot install NPM packages; make sure to fix permissions or package.json:\n${_npm_out}".
  cd "$oldpwd"
fi

# Setup veracode API.
source "${my_dir}/_api.sh"

mr_message "${message_title}  \n Security (SAST) scan commencing..."

# Download artifacts from projects pipeline.
artifact_download_timeout=300
SECONDS=0
artifacts_url="${CI_API_V4_URL}/projects/${CALLING_CI_PROJECT_ID}/jobs/${CALLING_CI_JOB_ID}/artifacts"
# Original header structure: --header "JOB-TOKEN: $CALLING_CI_JOB_TOKEN".
while true; do
  curl --silent --location --fail \
    --output artifacts.zip \
    --header "PRIVATE-TOKEN: $GL_SECURITY_PAT" \
    "$artifacts_url"
  status=$?
  [ $status -eq 0 ] && break
  [ $SECONDS -gt $artifact_download_timeout ] && stop_feedback "Failure downloading artifacts from pipeline (${artifacts_url})"
  sleep 5
done
[ ! -f artifacts.zip ] && stop_feedback "No artifacts available (${artifacts_url})"

unzip artifacts.zip -d ./artifacts
cd ./artifacts
# check if you have the files being used below:
# Remove kubernetes-platform residue, is present.
[ -d kubernetes-platform ] && rm -rf kubernetes-platform

# Check right project name, fix if needed.
app_name_combined=
checkAndCorrectAppName "gl${CALLING_CI_PROJECT_ID}" "$gitlab_short_name"
project_name=$app_name_combined

# Create metadata and contextual scan options.
short_sha=$(git rev-parse --short "${CALLING_CI_COMMIT_SHA}")
scan_version="$(basename "$project_name")-${short_sha}"
scan_version_long="${scan_version}-${CALLING_CI_PIPELINE_ID}"
archive=
scan_opts=

# Java of NodeJS project ?
is_java_project=
is_nodejs_project=
is_ios_project=
is_android_project=
if [ "$CALLING_SCAN_IOS_BCA" != "" ]; then
  # Normalize and verify it's in the working folder (no backtracking allowed).
  realpath=$(readlink -e "$CALLING_SCAN_IOS_BCA")
  [ $? -ne 0 ] && stop_feedback "File doesn't exist: ${CALLING_SCAN_IOS_BCA}"
  [[ "$realpath" != "$PWD"* ]] && stop_feedback "Forbidden: file must be in my working folder (${CALLING_SCAN_IOS_BCA})"
  [[ ! "$realpath" =~ \.(zip|bca)$ ]] && stop_feedback "Not a .bca/.zip file: ${CALLING_SCAN_IOS_BCA}"
  is_ios_project=1
  ios_bca_file=$realpath
fi
if [ "$CALLING_SCAN_ANDR_APK" != "" ]; then
  # Normalize and verify it's in the working folder (no backtracking allowed).
  realpath=$(readlink -e "$CALLING_SCAN_ANDR_APK")
  [ $? -ne 0 ] && stop_feedback "File doesn't exist: ${CALLING_SCAN_ANDR_APK}"
  [[ "$realpath" != "$PWD"* ]] && stop_feedback "Forbidden: file must be in my working folder (${CALLING_SCAN_ANDR_APK})"
  [[ "$realpath" != *.apk ]] && stop_feedback "Not a .apk file: ${CALLING_SCAN_ANDR_APK}"
  is_android_project=1
  android_apk_file=$realpath
fi
find . -maxdepth 3 -type f -wholename "*/target/*.jar" -o -wholename "*/target/*.war" | grep -q "." && is_java_project=1
[ -f ./package.json ] && is_nodejs_project=1

# Cook tar with artifacts, set specific scan options.
if [ $is_ios_project ]; then
  echo "IOS project. Selecting ${ios_bca_file}"
  archive=$ios_bca_file
  # Specifically scan PQ modules.
  scan_opts+=( "-toplevel" "true" "-include" "Payconiq*,payconiq*,PQ*" )
elif [ $is_android_project ]; then
  echo "Android project. Selecting ${android_apk_file}"
  archive=$android_apk_file
elif [ $is_java_project ]; then
  echo "Seems to be a Java project (found .jar files)"
  archive="upload_java.tgz"
  find . -maxdepth 3 -type f -wholename "*/target/*.jar" -o -wholename "*/target/*.war" |  tar -zcvf "${archive}" -T -
  scan_opts+=( "-exclude" "*-test*" )
elif [ $is_nodejs_project ]; then
  echo "Seems to be a NodeJS project (found package.json)"
  archive="upload_nodejs.tgz"
  find -- * -type f -regex ".*\.\(js\|cjs\|mjs\|iced\|liticed\|iced.md\|coffee\|litcoffee\|coffee.md\|ts\|tsx\|cs\|ls\|es6\|es\|jsx\|sjs\|co\|eg\)\$" \
    -o -name "package.json" -o -name "package-lock.json" \
    | tar -zcf "${archive}" -X "${basepwd}"/nodejs_excludes.txt -T -
  scan_opts+=( "-include" "JS files within*" )
# else
  # stop_feedback "SCRIPTERROR: Unable to determine project type. No target/*.jar or package.json found, or CALLING_SCAN_IOS_BCA/CALLING_SCAN_ANDR_APK defined"
fi

# Dump for gitlab CI exposure
cp "$archive" "$uploaded_artifact_dump"
echo "$archive" > "$uploaded_artifact_name_dump"

# Check if archive exists. Should be.
[ ! -f "$archive" ] && stop_feedback "SCRIPTERROR: archive not found [$archive]. Is your build job running ?"

# Sandbox options.
sandbox_opts=
if [ $is_mergerequest ]; then
  sandbox_name="MR-${CALLING_CI_MERGE_REQUEST_IID}"

  # Clean up old sandbox if any.
  # If we don't do this, scans in the same sandbox (MR) will yield incremental results,
  # making it harder to read the security state for a merge request.
  app_id=
  app_id=$(api getapplist | xmllint --xpath "string(//*[local-name()='app'][@app_name='${project_name}']/@app_id)" -)
  if [ "$app_id" ]; then
    cleanup_old_sandboxes "$app_id"
    delete_sandbox_by_name "$app_id" "$sandbox_name"
  fi

  sandbox_opts=( "-sandboxname" "${sandbox_name}" "-createsandbox" "true" )
  message_guidance_generate 1
fi

mr_message "${message_title}  \nGot the right files. Sending data to Veracode now.  \nResults pending..."

# Push tar to Veracode, trigger scan.
echo "Upload to scan"
scan_output=$(api uploadandscan \
  -appname "$project_name" \
  -filepath "$archive" \
  -version "$scan_version_long" \
  -createprofile true \
  -teams "$VERACODE_DEFAULT_TEAM" \
  -deleteincompletescan 2 \
  -scanallnonfataltoplevelmodules true \
  "${sandbox_opts[@]}" \
  "${scan_opts[@]}" \
  2>&1)
status=$?

echo "== API output:"
echo -e "$scan_output"
echo "=="

if [[ "$scan_output" == *"A scan is in progress"* ]]; then
  msg="Veracode doesn't accept a new scan. Another scan is on hold. Manually check Veracode please.  "
  msg=$msg"\n You probably need to remove an incomplete scan request."
  stop_feedback "$msg"
fi
if [[ "$scan_output" == *"UploadAndScan"*  && $status -ne 0 ]]; then
  echo "Known Veracode bug at  https://community.veracode.com/s/question/0D5Uf00000K92sFKAR/hi-teamgetting-the-access-d[…]-i-am-seeing-this-errorcould-you-please-assist-us-on-this "
  exit 1
fi
# [ $status -ne 0 ] && stop_feedback 'Veracode API giving unexpected response; exit\n```'"${scan_output}"'\n```\n'

# Get build ID, used for report fetching.
build_id=$(echo -en "$scan_output" | grep 'The analysis id of the new analysis is' | sed -r 's/^.*"([0-9]+)".*$/\1/')

# Wait for SAST scan to finish, get report.
SECONDS=0
report_file="summary_report.xml"
downloadVcReport "$build_id" "$report_file" "$WAIT_TIMEOUT_SEC"

duration=$SECONDS
echo -e "\nScan took $duration seconds"
message_guidance_generate 1
[ ! -f "$report_file" ] && stop_feedback "No report, not expected"

# Persist appname / build ID for import-to-DD job.
echo "$project_name" > "${my_dir}/.dd_app"
echo "$build_id" > "${my_dir}/.vc_build"
[ $is_master_commit ] && touch "${my_dir}/.ci_master_event"
[ $is_mergerequest ] && touch "${my_dir}/.ci_mr_event"

# Feedback
msg=${message_title}
[ $is_mergerequest ] && msg=$msg' (sandboxed)'

report_output=$(vc_report_getinfo --report="$report_file" --info=all --cvss_threshold="${CVSS_THRESHOLD}" --format=gitlab 2>&1)
status=$?
[ $status -eq 1 ] && stop_feedback "${report_output}"
msg=$msg"\n${report_output}"

echo ""
echo -e "$msg"
msg_markdown=$(echo -e "$msg")

# Feedback into Gitlab merge request
echo ">> $CALLING_CI_MERGE_REQUEST_IID / $CALLING_CI_PROJECT_ID"
[ $status -eq 0 ] && resolve_thread=1 || resolve_thread=
mr_message "${msg_markdown}" "$resolve_thread"
