#!/usr/bin/env node

import dep from './dep_analysis.js';
import minimist from 'minimist';

let instruction = parseCliOpts();

let blocklist = dep.readDepBlocklist(instruction.blocklist_path);
let pm = dep.guessPackageManager(dep.getFiles(instruction.project_path, 2));

if (!pm || !pm.type) {
    console.error(`No package manager stuff found...`);
    process.exit(3);
}

/** @type Promise */
let promise = null;
if (pm.type === 'pom') {
    promise = dep.getMavenDependencies(pm);
}
else if (pm.type === 'npm') {
    promise = dep.getNpmDependencies(pm);
}

if (promise) {
    promise.then(deps => {
        let bad_deps = dep.findBlockedDeps(blocklist, deps, pm.type);
        if (bad_deps.length) {
            if (instruction.format === 'csv') {
                dep.renderBadDependencies(bad_deps, 'csv').then(csv => {
                    process.stdout.write(csv);
                    process.exit(2);
                }, error => {console.log(error); process.exit(1);});
            } else {
                dep.renderBadDependencies(bad_deps, 'text').then(text => {
                    console.error(`Found bad dependencies in project!\n${text}`);
                    process.exit(2);
                }, error => {console.log(error); process.exit(1);});
            }
        } else {
            if (instruction.format === 'text') {
                console.log(`No bad stuff found in ${deps.size} dependencies`);
            }
            process.exit(0);
        }
    }, error => {
        console.error(error);
        process.exit(1);
    })
}

function parseCliOpts() {
    let argv = minimist(process.argv.slice(2));

    // Project path to scan.
    let path = process.cwd();
    if (argv.path) {
        path = argv.path;
    }

    // Output format.
    let format = 'text';
    if (argv.format) {
        if (!['text', 'csv'].includes(argv.format)) {
            showHelpExit();
        } else {
            format = argv.format;
        }
    }

    if (!argv.blocklist) {
        showHelpExit();
    }
    let blocklist = argv.blocklist;

    return {
        /** @type String */
        project_path: path,

        /** @type String */
        blocklist_path: blocklist,

        /** @type String */
        format: format,
    }
}

function showHelpExit(issue = null) {
    let template = `This script will find package managers (npm, maven) and compare the dependency tree ` +
        `against a blocklist.\n` +
        `The response will be either\n` +
        `  - A list of violating dependencies, using exit code 2\n` +
        `  - system/script failure, using exit code 1\n` +
        `  - nothing found, exit code 0\n\n` +
        `Provide the following parameters:\n` +
        `  --path:       path to the project folder to scan.\n` +
        `  --blocklist:  path to the blocklist yaml file.\n` +
        `  --format:     (optional) output format, either 'text' (default) or 'csv'.\n\n` +
        `Blocklist yaml format:\n` +
        '```yaml\n' +
        `blocklist:\n` +
        `  - group: com.payconiq.shared\n` +
        `    artifact: ideal-acc-test-commons\n` +
        `    semantic_version: <=0.0.4\n` +
        `    types: [pom,npm]\n` +
        '```'
    ;

    if (issue) console.log(`Error: ${issue}\n\n`);
    console.log(template);
    process.exit(1);
}
