import tempfile from 'tempfile';
import fs from 'fs';
import { exec } from 'child_process';
import dotparser from 'dotparser';
import yaml from 'js-yaml';
import semver from 'semver';
import csv_stringify from 'csv-stringify';
import moment from 'moment';

export default {
    /**
     *
     * @param {Object} pm_info
     * @return {Promise<Map<Dependency>>}
     */
    getMavenDependencies: function(pm_info) {
        let self = this;
        return new Promise((resolve, reject) => {
            // Check maven.
            exec("which mvn", (error, stdout, stderr) => {
                if (error) {
                    reject(`Maven not found`)
                    return;
                }

                // Get dependency data.
                let temp = tempfile();
                console.error(`Fetching Maven dependency tree...`);
                let command = `mvn dependency:tree -DoutputFile="${temp}" -DappendOutput=true -DoutputType=dot`;
                console.error(`Executing [${command}]`);
                exec(command, {cwd: pm_info.pm_path, maxBuffer: 1024 * 1024 * 10}, (error, stdout, stderr) => {
                    if (error) {
                        reject(`Problem getting maven dependency tree: \n${error.message}\n--\nstderr:\n${stderr}`);
                        return;
                    }

                    /** @type Map<Dependency> */
                    let dependencies = new Map();

                    let dependencies_dot = fs.readFileSync(temp, 'utf8');
                    let dot_deps = dotparser(dependencies_dot);

                    /**
                     *
                     * @param {Array<Object>} dot_deps_l
                     * @param {Map<Dependency>} dependencies
                     */
                    function crawlDotDeps(dot_deps_l, dependencies) {
                        if (dot_deps_l) {
                            dot_deps_l.forEach(dot_dep => {
                                if (dot_dep.type === 'digraph' && dot_dep.children) {
                                    crawlDotDeps(dot_dep.children, dependencies);
                                } else if (dot_dep.type === 'edge_stmt' && dot_dep.edge_list) {
                                    crawlDotDeps(dot_dep.edge_list, dependencies);
                                } else if (dot_dep.type === 'node_id') {

                                    if (!dependencies.has(dot_dep.id)) {

                                        // Format: nl.ideal.accesspoint:acceptance-tests:jar:0.0.1-SNAPSHOT:test .
                                        let parts = dot_dep.id.split(':');
                                        let groupId = parts[0];
                                        let artifactId = parts[1];
                                        let include_type = parts[parts.length - 1];
                                        let version = parts[parts.length - 2];
                                        if (include_type === 'compile') {
                                            dependencies.set(dot_dep.id, new self.Dependency(
                                                groupId, artifactId, version
                                            ));
                                        }
                                    }
                                }
                            })
                        }
                    }
                    crawlDotDeps(dot_deps, dependencies);
                    resolve(dependencies);
                    return;
                });
            });
        })

    },

    /**
     *
     * @param {Object} pm_info
     * @return {Promise<Map<Dependency>>}
     */
    getNpmDependencies: function(pm_info) {
        let self = this;
        return new Promise((resolve, reject) => {
            // Check maven.
            exec("which npm", (error, stdout, stderr) => {
                if (error) {
                    reject(`Npm not found`)
                    return;
                }

                // Get dependency data.
                let command = `npm install --production`
                console.error(`Executing [${command}]`);
                exec(command, {cwd: pm_info.pm_path,  maxBuffer: 1024 * 1024 * 10}, (error, stdout, stderr) => {
                    if (error) {
                        console.error(`Problem building project: \n${error.message}\n--\n${stderr}\n--\nWill proceed anyway...`);
                    }

                    let temp = tempfile();
                    console.error(`Fetching NPM dependency tree...`);
                    command = `npm list --production --json > "${temp}"`
                    console.error(`Executing [${command}]`);
                    exec(command, {cwd: pm_info.pm_path, maxBuffer: 1024 * 1024 * 10}, (error, stdout, stderr) => {
                        if (error) {
                            if (fs.statSync(temp).size < 3) {
                                reject(`Problem getting npm dependency tree: ${error.message}`);
                                return;
                            } else {
                                console.error(`Problem getting npm dependency tree, but still has output: ${error.message}`);
                            }
                        }

                        /** @type Map<Dependency> */
                        let dependencies = new Map();
                        let dependencies_json = fs.readFileSync(temp, 'utf8');
                        let npm_dependencies = JSON.parse(dependencies_json);

                        /**
                         *
                         * @param {Array<Object>} dep
                         * @param {Map<Dependency>} dependencies
                         */
                        function crawlNpmDeps(deps, dependencies) {
                            if (deps) {
                                Object.keys(deps).forEach(key => {
                                    let npm_dep = deps[key];
                                    if (npm_dep
                                        && npm_dep.hasOwnProperty('version')
                                        && npm_dep.hasOwnProperty('from')) {

                                        // Group.
                                        let group = null;
                                        let parts = key.split('/');
                                        if (parts.length) {
                                            group = parts.slice(0, parts.length - 1).join('/');
                                        }
                                        let artifact = parts.slice(-1).join();

                                        dependencies.set(npm_dep.from, new self.Dependency(
                                            group, artifact, npm_dep.version
                                        ));

                                        // Recurse.
                                        if (npm_dep.hasOwnProperty('dependencies')) {
                                            crawlNpmDeps(npm_dep.dependencies, dependencies);
                                        }
                                    }
                                })
                            }
                        }

                        crawlNpmDeps(npm_dependencies.dependencies, dependencies);
                        resolve(dependencies);
                        return;
                    });

                });
            });
        })

    },

    /**
     *
     * @param {Array<Object>} files
     * @return Object|null
     */
    guessPackageManager: function(files) {
        let type = null;
        let pm_path = null;
        let pm_path_depth = 100000;
        files.forEach(file => {
            if (file.filename === 'pom.xml' && file.depth < pm_path_depth) {
                pm_path = file.dir;
                pm_path_depth = file.depth;
                type = 'pom';
            } else if (file.filename === 'package-lock.json' && file.depth < pm_path_depth) {
                pm_path = file.dir;
                pm_path_depth = file.depth;
                type = 'npm';
            }
        })

        if (type) {
            return {
                type: type,
                pm_path: pm_path
            }
        } else {
            return null;
        }
    },

    /**
     * Find all files in dir.
     *
     * @param {string} dirPath
     * @param {number} maxDepth
     * @param {number} currentLevel
     * @param {Array<Object>} files
     * @return {Array<Object>}
     */
    getFiles: function(dirPath, maxDepth = 1, currentLevel = 0, files = []){
        let self = this;
        if (currentLevel >= maxDepth){
            return;
        }
        else{
            fs.readdirSync(dirPath).forEach(function(filename) {
                if (!filename.startsWith('.')) {
                    let newPath = `${dirPath}/${filename}`;
                    let stat = fs.statSync(newPath);
                    if (stat.isDirectory()) {
                        self.getFiles(newPath, maxDepth, currentLevel+1, files);
                    } else if (stat.isFile()) {
                        let file = {
                            dir: dirPath,
                            filename: filename,
                            depth: currentLevel
                        }
                        files.push(file);
                    }
                }
            });
            return files;
        }
    },

    readDepBlocklist: function(filepath) {
        try {
            let fileContents = fs.readFileSync(filepath, 'utf8');
            return yaml.safeLoad(fileContents);
        } catch (e) {
            console.log(`Failed reading yaml from [${filepath}]`);
            console.log(e);
            process.exit(1);
        }
    },

    /**
     *
     * @param {Array<Object>} blocklist
     * @param {Map<Dependency>} dependencies
     * @param {String} type
     * Either pom or npm.
     * @return Array<Dependency>
     */
    findBlockedDeps: function(blocklist, dependencies, type) {
        let bad_dependencies = [];

        dependencies.forEach(dep => {

            blocklist.blocklist.forEach(block => {
                let group_ptrn = new RegExp(block.group);
                let artifact_ptrn = new RegExp(block.artifact);

                if (!block.types || block.types.includes(type)) {
                    if (dep.group.match(group_ptrn) && dep.name.match(artifact_ptrn)) {
                        if (dep.version == null || semver.satisfies(dep.version, block.semantic_version)) {
                            dep.blocked_dependency = block;
                            bad_dependencies.push(dep);
                        }
                    }
                }
            })
        })

        return bad_dependencies;
    },

    /**
     * @param {Array<Dependency>} dependencies
     * @param {String<text|csv>} format
     * @return Promise<String>
     */
    renderBadDependencies: function(dependencies, format = 'text') {
        let self = this;
        return new Promise(function (resolve, reject) {
            if (format === 'csv') {
                self.badDepsToFindingsToCsv(dependencies).then(resolve, reject);
            }
            else {
                let prefix = ' - ';
                if (dependencies.length) {
                    let rendered_items = [];
                    dependencies.forEach(dep => {
                        rendered_items.push(`${dep.group}:${dep.name}:${dep.version}`);
                    })
                    resolve(prefix + rendered_items.join('\n' + prefix));
                } else {resolve('')}
            }
        })
    },

    /**
     * Render bad dependencies in a defectdojo formatted CSV.
     * @param {Array<Dependency>} dependencies
     * @return Promise<String>
     */
    badDepsToFindingsToCsv: function(dependencies) {
        return new Promise(function (resolve, reject) {
            if (dependencies.length) {
                let findings = [];
                dependencies.forEach(dep => {
                    let title = `Project using bad dependency (${dep.group}:${dep.name}:${dep.version})`;
                    let description = `Project is using an (internal) dependency marked as blocked.\n\n` +
                        `  Group:   \`${dep.group}\`\n` +
                        `  Name:    \`${dep.name}\`\n` +
                        `  Version: \`${dep.version}\``;

                    let references = `Blocked dependency information:\n\n` +
                        `  Group:   \`${dep.blocked_dependency.group}\`\n` +
                        `  Name:    \`${dep.blocked_dependency.artifact}\`\n` +
                        `  Versions blocked: \`${dep.blocked_dependency.semantic_version}\``;

                    let flat_finding = {
                        Date: moment().format('MM/DD/YYYY'),
                        Title: title,
                        CweId: 937,
                        Url: null,
                        Severity: 'High',
                        Description: description,
                        Mitigation: `Contact the dependency supporting team for more information, and upgrade/remove.`,
                        Impact: 'Unknown',
                        References: references,
                        Active: "TRUE",
                        Verified: "TRUE",
                    }
                    findings.push(flat_finding);
                })

                let options = {
                    header: true
                }
                csv_stringify(findings, options, function(err, output){
                    if (err) {reject(err)}
                    else {
                        resolve(output);
                    }
                });
            } else {resolve('');}
        })
    },

    Dependency: class {
        /** @type {String}*/
        group = null;

        /** @type {String} */
        name = null;

        /** @type {String} */
        version = null;

        /** @type {Dependency} */
        blocked_dependency = null;

        /**
         * @param {String} group
         * @param {String} name
         * @param {String} version
         */
        constructor(group, name, version) {
            this.group = group;
            this.name = name;
            this.version = version;
        }
    },
}
