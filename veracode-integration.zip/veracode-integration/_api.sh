#!/bin/bash

# Source this file to setup the `api` function, to interact with veracode.
# Required:
#  - VERACODE_API_KEY_ID
#  - VERACODE_API_KEY_SECRET

[ -z $VERACODE_API_KEY_ID ] && echo "No VERACODE_API_KEY_ID" && exit 1
[ -z $VERACODE_API_KEY_SECRET ] && echo "No VERACODE_API_KEY_SECRET" && exit 1

# Unset potential java opts; results in JVM prefixing command (e.g. XML) output with bogus stuff, breaking parser.
unset _JAVA_OPTIONS

_type=$(type -t veracode)
if [ "$_type" != "function" ] && [ "$_type" != "file" ]; then
  # Fallback in case veracode missing in image/environment.
  # Makes for unstable versions.
  echo "DOWNLOADING VERACODE WRAPPER JAR. PREVENT THIS BY HAVING 'veracode' AVAILABLE IN THIS ENVIRONMENT/IMAGE"
  export basepwd=$PWD
  VERACODE_WRAPPER_VERSION=$(curl -sS "https://repo1.maven.org/maven2/com/veracode/vosp/api/wrappers/vosp-api-wrappers-java/maven-metadata.xml" | xmllint --xpath "/metadata/versioning/release/text()" -)
  curl -sS -o "${basepwd}/veracode-wrapper.jar" "https://repo1.maven.org/maven2/com/veracode/vosp/api/wrappers/vosp-api-wrappers-java/${VERACODE_WRAPPER_VERSION}/vosp-api-wrappers-java-${VERACODE_WRAPPER_VERSION}.jar"

  function veracode() {
    java -jar "${basepwd}/veracode-wrapper.jar" "$@"
  }
  veracode -wrapperversion
fi

function api() {
  veracode -vid "$VERACODE_API_KEY_ID" -vkey "$VERACODE_API_KEY_SECRET" -action "$@"
}
