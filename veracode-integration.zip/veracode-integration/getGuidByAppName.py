import sys
import requests
import argparse
import os
import re
import json
from veracode_api_signing.plugin_requests import RequestsAuthPluginVeracodeHMAC

headers = {"User-Agent": "Python HMAC Example"}

api_base = "https://api.veracode.com/appsec/"


def create_result_file(status_text: str, summary_text: str, app_name: str, filename: str):
    payload = {
        "status": status_text,
        "summary": summary_text,
        "appName": app_name,
        "scanType": ["SAST"],
        "message": "Your pipeline will fail if there are vulnerabilities in your source code."
    }
    json_payload = json.dumps(payload)
    file_path = os.path.join('', filename)
    with open(file_path, 'w') as f:
        f.write(json_payload)
    if os.path.isfile(file_path):
        print("The JSON payload was successfully created")


def findings(guid: str, app_name: str, key_id: str, secret: str):
    print("Fetching findings for GUID " + guid + " with app name " + app_name)
    try:
        response = (requests.get
                    (api_base + "v2/applications/" + guid + "/findings?scan_type=STATIC",
                     auth=RequestsAuthPluginVeracodeHMAC
                     (api_key_id=key_id,
                      api_key_secret=secret),
                     headers=headers))
    except requests.RequestException as e:
        print("Static scan failed with " + str(e))
        sys.exit(1)

    if response.ok:
        data = response.json()
        try:
            detailed_comment = "There are no OPEN findings to report"
            all_findings = data["_embedded"]["findings"]
            num_of_findings = len(all_findings)
            print("Checking " + str(num_of_findings) + " findings(s)")
            severity_score = 0
            for index in range(len(all_findings)):
                severity = data["_embedded"]["findings"][index]["finding_details"]["severity"]
                status = data["_embedded"]["findings"][index]["finding_status"]["status"]
                if status.upper() == "OPEN":
                    if severity_score < severity:
                        severity_score = severity
                        resolution_status = data["_embedded"]["findings"][index]["finding_status"]["resolution"]
                        first_found = data["_embedded"]["findings"][index]["finding_status"]["first_found_date"]
                        last_seen = data["_embedded"]["findings"][index]["finding_status"]["last_seen_date"]
                        cwe_id = data["_embedded"]["findings"][index]["finding_details"]["cwe"]["id"]
                        cwe = data["_embedded"]["findings"][index]["finding_details"]["cwe"]["name"]
                        severity = data["_embedded"]["findings"][index]["finding_details"]["severity"]
                        detailed_comment = (
                                "The resolution status of the finding is " + resolution_status + " and the status is " + status +
                                ". This issue was first found on " + first_found + " and last seen on " + last_seen +
                                ". The severity is " + str(severity) + " and the CWE is " + "'" + str(cwe) + "'" +
                                ", the CWE_ID is " + str(cwe_id))
            print("The highest severity score is " + str(severity_score))
            if severity_score >= 4:
                result = "FAIL"
            else:
                result = "PASS"
            print("result is " + result)
            match = re.search(r'\[(.*?)\]', app_name)
            if match is not None:
                content = match.group(1)
                # Set the full path where you want to create the file
                print("The content file is named " + content + ".txt")
                file_path = os.path.join('', content + '.txt')
                create_result_file(result, detailed_comment, app_name, file_path)
            else:
                create_result_file("PASS", "There's no evaluation result file for " + app_name, app_name,
                                   "pipeline_generic_message.txt")
        except Exception as e:
            create_result_file("PASS", str(e) + ":::: There are no findings for GUID " + str(guid), app_name,
                               "pipeline_generic_message.txt")
    else:
        print(response.status_code)
        create_result_file("FAIL", str(response.status_code), app_name,
                           "pipeline_generic_message.txt")


def evaluate_app_profile(app_name: str, key_id: str, secret: str):
    try:
        if len(str(app_name)) > 1:
            response = (requests.get
                        (api_base + "v1/applications/?name=" + str(app_name),
                         auth=RequestsAuthPluginVeracodeHMAC
                         (api_key_id=key_id,
                          api_key_secret=secret),
                         headers=headers))
            if response.ok:
                data = response.json()
                print("======== Extracting the GUID from the application profile ========")
                findings(data["_embedded"]["applications"][0]["guid"], app_name, key_id, secret)
            else:
                print(response.status_code)
        else:
            print("App name is empty")
    except requests.RequestException as e:
        print("Whoops!")
        print(e)
        sys.exit(1)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--arg1", type=str, help="First string argument:app_name")
    parser.add_argument("--arg2", type=str, help="Second string argument:key_id")
    parser.add_argument("--arg3", type=str, help="Third string argument:secret")

    args = parser.parse_args()

    evaluate_app_profile(args.arg1, args.arg2, args.arg3)
