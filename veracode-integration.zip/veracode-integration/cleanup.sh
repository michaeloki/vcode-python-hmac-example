#!/bin/bash

if [ -f "evaluation_output.txt" ]; then
  rm evaluation_output.txt
fi
if [ -f "pipeline_stage_tracker.txt" ]; then
  rm pipeline_stage_tracker.txt
fi
if [ -f "pipeline_generic_message.txt" ]; then
  rm pipeline_generic_message.txt
fi
if [ -f "dynamic_file.txt" ]; then
  rm dynamic_file.txt
fi
if [ -f "verdict.txt" ]; then
  rm verdict.txt
fi
if [ -f "build.txt" ]; then
  rm build.txt
fi
if [ -f "params.txt" ]; then
  rm params.txt
fi
if [ -f "temp_report.json" ]; then
  rm temp_report.json
fi
