import argparse
import os
import json


def generate_file(status_text: str, summary_text: str, app_name: str, filename: str):
    payload = {
        "status": status_text,
        "summary": summary_text,
        "appName": app_name,
        "scanType": [],
        "message": "Your pipeline will fail if there are vulnerabilities in your source code."
    }
    json_payload = json.dumps(payload)
    file_path = os.path.join('', filename)
    with open(file_path, 'w') as f:
        f.write(json_payload)
    if os.path.isfile(file_path):
        print("The JSON payload was successfully created")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--arg1", type=str, help="First string argument:status_text")
    parser.add_argument("--arg2", type=str, help="Second string argument:summary_text")
    parser.add_argument("--arg3", type=str, help="Third string argument:appname")
    parser.add_argument("--arg4", type=str, help="Fourth string argument:filename")

    args = parser.parse_args()

    generate_file(args.arg1, args.arg2, args.arg3, args.arg4)
