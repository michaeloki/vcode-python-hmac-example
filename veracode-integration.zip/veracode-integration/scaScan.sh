#!/bin/bash
source generic_response.sh

# prerequisites:
# - debian/ubuntu
# - java
scanTypeMsg="analysis:sca"


# Check integration stuff.
[ -z "$CI_API_V4_URL" ] && stop_feedback "No Gitlab API defined" "$scanTypeMsg"
[ -z "$CALLING_CI_PROJECT_PATH" ] && stop_feedback "No project namespace" "$scanTypeMsg"
[ -z "$CALLING_CI_PROJECT_ID" ] && stop_feedback "No project ID" "$scanTypeMsg"
[ -z "$GL_SECURITY_PAT" ] && stop_feedback "No GL_SECURITY_PAT . Cannot interact with gitlab API" "$scanTypeMsg"
[ -z "$SRCCLR_API_TOKEN" ] && stop_feedback "No SRCCLR_API_TOKEN . Cannot interact with veracode sourceclear" "$scanTypeMsg"
# [ -z "$CALLING_CI_JOB_TOKEN" ] && echo "No CI_JOB_TOKEN passed. Cannot download artifacts from pipeline job." && exit 1

# Veracode config.
[ -z "$VERACODE_GUIDING_DOC_URL" ] && VERACODE_GUIDING_DOC_URL="https://payconiq.io/confluence/pages/viewpage.action?pageId=61374510"
[ -z "$CVSS_THRESHOLD" ] && CVSS_THRESHOLD=7

# Defaults
GITLAB_HOST="gitlab.payconiq.io"
my_dir=$(cd "$(dirname "$0")" && pwd)
[ "$CALLING_SCAN_MASTER_BRANCH" != "" ] && master_branch=$CALLING_SCAN_MASTER_BRANCH || master_branch="master"
# gitlab_short_name: 'sre/devops/security/sample-nodejs-application' > 'security/sample-nodejs-application'
gitlab_short_name="$(basename "$(dirname "$CALLING_CI_PROJECT_PATH")")/$(basename "$CALLING_CI_PROJECT_PATH")"
project_name="${gitlab_short_name}"

# Is this a master-branch commit triggered scan ?
is_master_commit=
if [ ! $is_mergerequest ]; then
  [ "$CALLING_CI_COMMIT_BRANCH" == "$master_branch" ] && is_master_commit=1
fi

# Only perform on master branch changes.
[ ! $is_master_commit ] && echo "No master-ish branch commit. No need for sca scan." && exit 0


# Clone project repo, enter folder
echo "Cloning https://${GITLAB_HOST}/${CALLING_CI_PROJECT_PATH}.git/"
git clone "https://gitlab-ci-token:${CI_JOB_TOKEN}@${GITLAB_HOST}/${CALLING_CI_PROJECT_PATH}.git/" git_project
[ $? -ne 0 ] && stop_feedback "Unable to clone repository" "$scanTypeMsg"
cd git_project
git checkout "${CALLING_CI_COMMIT_BRANCH}"
git reset --hard "${CALLING_CI_COMMIT_SHA}"

# Prepare maven.
if [ ! -f ~/.m2/settings.xml ]; then
  [ ! -d ~/.m2 ] && mkdir ~/.m2
  cp "${my_dir}/m2/conf/settings.xml" ~/.m2/settings.xml
else
  echo "~/.m2/settings.xml already exists; using that (remove it and rerun me to use the shipped CI version"
fi

echo "Executing SCA scan. This may involve compiling and letting the package manager build the project..."
# Sourceclear uses git's origin URL to derive the project name.
# Since the API wrapper doesn't facilitate a way to specify the project-name,
# we define it here, so that it's using the same convention as the SAST projects.
git remote set-url origin "ssh://foo.bar/${project_name}.git"
echo "Executing scan: srcclr scan . --loud"
srcclr scan . --loud
status=$?
echo "Done"
exit $status
