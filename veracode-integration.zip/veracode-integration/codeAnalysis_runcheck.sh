#!/bin/bash
# If this is a master-change triggered scan,
# this script determines if the SAST scan needs to run.
# This is because there are multiple CI ways of triggering this,
# and we don't want to have duplicate scans of the same.
#
# TL;DR: This script uses gitlab cache to track if a certain master-branch triggered a scan (based on commit hash).
# If there was already a scan, it'll prevent 'this' run to proceed.

# Defaults
TRACKING_FILE=.tracking
PREVENT_SCAN_FILE=.prevent_sast
my_dir=$(cd "$(dirname "$0")" && pwd)
[ "$CALLING_SCAN_MASTER_BRANCH" != "" ] && master_branch=$CALLING_SCAN_MASTER_BRANCH || master_branch="master"

if [ -z "$CALLING_CI_PROJECT_PATH" ]; then
  json_object=$(echo '{}' | jq '. + {"status": "FAIL", "summary":"No project namespace", "appName": "", "scanType": ["scan_gate"],
"message": "The scan gate stage failed because '"$CALLING_CI_PROJECT_PATH"' is missing"}')
  cd ..
  echo "$json_object" > pipeline_stage_tracker.txt
  echo "No project namespace, a $json_object was successfully saved in $(pwd)"
  cd artifacts || return
  exit 1
fi



# Is this a master-branch commit or MR triggered scan ? Otherwise do nothing.
# Only done to avoid having a very lengthy tracker list (for each branch). It's possible to do this,
# because the scan scripts will do the same (so no other cases to cover).
if [ "$CALLING_CI_COMMIT_BRANCH" != "$master_branch" ] && [ "$CALLING_CI_MERGE_REQUEST_IID" = "" ]; then
  echo "Not a master-branch or MR scan, just moving on" && exit 0
fi

# Check if project is on the blacklist.
# Avoid scanning if so.
if echo "${CALLING_CI_PROJECT_PATH}" | grep -Eqxf scan_projects_blacklist; then
  if echo "${CALLING_CI_PROJECT_PATH}" | grep -Evqxf scan_projects_whitelist; then
    echo "Project [${CALLING_CI_PROJECT_PATH}] is on the blacklist, not scanning" && touch "$PREVENT_SCAN_FILE" && exit 0
  fi
fi
echo "Project [${CALLING_CI_PROJECT_PATH}] not on the blacklist. Proceeding..."
echo "${CALLING_CI_PROJECT_PATH}" > verdict.txt
# The (timed) marker will be
# CI=[project-ID]=[commit-hash]=s[timestamp], or
# MR=[project-ID]=[commit-hash]=s[timestamp].
if [ "$CALLING_CI_MERGE_REQUEST_IID" != "" ]; then
  prefix="CI="
else
  prefix="MR="
fi
now=`date +%s`
scan_marker="${prefix}${CALLING_CI_PROJECT_ID}=${CALLING_CI_COMMIT_SHA}"
found_marker=$(cat "$TRACKING_FILE" | grep "${scan_marker}")
timestamp=$(echo "$found_marker" | sed -nE 's/^.*=s([0-9]{10,11})$/\1/p')
if [ "$timestamp" != "" ] && [ $((now-timestamp)) -lt 600 ]; then
  echo "Scan already happened" && touch "$PREVENT_SCAN_FILE" && exit 0
fi

# Set marker in tracking file.
echo "Scan can proceed, saving marker"
scan_marker_timed="${scan_marker}=s${now}"
rest_of_the_file=$(cat "$TRACKING_FILE" | grep -v "${prefix}${CALLING_CI_PROJECT_ID}=")
echo "$rest_of_the_file" > "$TRACKING_FILE"
echo "$scan_marker_timed" >> "$TRACKING_FILE"
