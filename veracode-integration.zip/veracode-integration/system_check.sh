#!/bin/bash
# Source the api.sh if the GITLAB VARIABLES are missing.
source generic_response.sh
appname=$1
key_id=$2
secret=$3
commit_sha=$4
scanTypeMsg="evaluation"


function stage_check {
  echo "==== Checking previous stages in $(pwd)===="
  cat pipeline_stage_tracker.txt
  if [ -f pipeline_stage_tracker.txt ] &&  grep -q "FAIL" "pipeline_stage_tracker.txt"; then
    cat pipeline_stage_tracker.txt
  # if [ "$(ls -la | grep "pipeline_stage_tracker.txt")" ] && grep -q "FAIL" "pipeline_stage_tracker.txt"; then
    chmod +x ./cleanup.sh
    ./cleanup.sh
    exit 0
  else
    echo "SC-FNF"
  fi
}

function finalise_evaluation {
  stage_check
  if [[ -z $key_id ]]; then
    stop_feedback "KEY_ID is missing" "$scanTypeMsg"
  else
    commit_file=$commit_sha".txt"
    if [ -f "$commit_file" ]; then
      rm -f "$commit_file"
    fi
    python3 getGuidByAppName.py --arg1 "$appname" --arg2 "$key_id" --arg3 "$secret"
    value=$(echo "$appname" | grep -Eo "\[([^][]*)]")
    string_length=${#value}
    last_index=$((string_length - 2))
    content=${value:1:last_index}
    file_check=$content".txt"
    if [ -f "$file_check" ]; then
      file_content=$(cat "$file_check")
      echo "The file content in system_check is ${file_content}"
      status=$(jq '.status' "$file_check")
      status_text=${status:1:${#status}-2}
      echo "$status_text" > evaluation_output.txt
      if [ "$status_text" = "FAIL" ]; then
        echo "Severe vulnerabilities were found and we'll block this pipeline"
        echo "$file_content" > verdict.txt
      fi
      if [ "$status_text" = "PASS" ]; then
        echo "No HIGH or CRITICAL source code vulnerabilities were found!"
        echo "$file_content" > verdict.txt
      fi
      else
        echo "There is no result file to evaluate for $appname"
        generic_feedback "There is no result file to evaluate for " "$appname"
    fi
  fi
}



if python3 --version &>/dev/null; then
    # Check if pip is installed
    pip3_check=$(whereis pip3)
    if [ -z "$pip3_check" ]; then
      apt-get -y install python3-venv python-pip-whl python3-distutils python3-lib2to3 python3.9-venv > /dev/null 2>&1
    fi
    if python3 -m pip list | grep -i requests; then
      echo "Calling the python script with app name $appname"
      python3 -m venv secenv
      source secenv/bin/activate
      finalise_evaluation
      deactivate
    else
      # Install prerequisites for Python 3
      echo "Package 'requests' should be installed for Python 3."
      echo "Installing dependencies..."
      apt-get -y install python3-venv python-pip-whl python3-distutils python3-lib2to3 python3.9-venv > /dev/null 2>&1
      python3 -m venv secenv
      source secenv/bin/activate
      pip3 install -r requirements.txt -q
      if pip3 list | grep -q requests; then
        echo "Package 'requests' is already installed for Python 3."
        echo "Calling the python script with app name $appname"
        finalise_evaluation
        deactivate
      fi
    fi
else
    echo "Python 3 is not installed. Please install Python 3 first."
    exit 1
fi
