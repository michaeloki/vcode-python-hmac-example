#!/bin/bash

JSON_FILE="test.json"

if [ -f "$JSON_FILE" ]; then
  jq '.name += ["Pea"] | .sch += ["UCI"] | .city += ["Sant"]' "$JSON_FILE" > temp.json
  mv temp.json "$JSON_FILE"
else
  echo "File not found, creating new JSON object."
  echo '{"name":["M"],"sch":["HVU"],"city": ["London"]}' > "$JSON_FILE"
fi