#!/bin/bash
echo "Just a script"
##python3 hello.py
##echo "Python3 script was successfully called"
#source generate_error_response.sh
#
#if [ -f "pipel.txt" ] &&  grep -qx "FAIL" "pipel.txt"  && [ ! -f "dynamic_file.txt" ]; t
#hen SEC_EVA_RESULT="$(cat pipel.txt)" && echo $SEC_EVA_RESULT && exit 0; fi
#stop_feedback "Veracode SCA container scanning engine ready\nrunning container analyzer 'Npm' on container '669e06727b4306825cde5c354f16e353ec0c653d9019d0beda4b1a7152d2f00c' ( with image 'registry.acc.payconiq.io/merchant-portal:0bdffd41450f26da58da8816932781137119b109.437141' )\nrunning container analyzer 'Apk' on container '669e06727b4306825cde5c354f16e353ec0c653d9019d0beda4b1a7152d2f00c' ( with image 'registry.acc.payconiq.io/merchant-portal:0bdffd41450f26da58da8816932781137119b109.437141' )\n2024-06-26/10:35:39.041 com.sourceclear.agent.commands.ScanCommand\tERROR\tUnable to scan and generate report: begin 0, end -1, length 1" "test_phase"
#stop_feedback "SCRIPTERROR: Unable to determine project type. No target/*.jar or package.json found, or CALLING_SCAN_
# IOS_BCA/CALLING_SCAN_ANDR_APK defined" "tester"

#
#IN_WATCH_DIR="~/Downloads/"
#
#inotifywait -m "$IN_WATCH_DIR" --format '%w%f' -e create | while read pathname
#do
#    echo "New file detected: $pathname"
#    touch fileos.txt
#    # Add your actions here when a new file is created
#done



   day=$(date "+%d")
   month=$(date "+%m")
   year=$(date "+%Y")
   start_timestamp=$(date -j -f "%m/%d/%Y" "$month"/"$day"/"$year" +%s)
   end_timestamp=$(date -j -f "%m/%d/%Y" 09/30/2024 +%s)

   echo "$start_timestamp and $end_timestamp"



echo "Today's date is $(date)"
echo $(date) >> log.txt



echo "This is a power user script...."

read -p "Do you want to restart the deployment file monitoring service 'yes'? [y/n] " response
if [[ $response =~ ^[Yy]$ ]]
then
    echo "Correct"
    #sudo systemctl stop pipeline-monitor.service && sudo systemctl daemon-reload && sudo systemctl start pipeline-monitor.service
else
    echo "Goodbye..."
fi
SOURCE_COMMIT_SHA="hello"
#echo "Source commit SHA is $SOURCE_COMMIT_SHA and the file name will be ${SOURCE_COMMIT_SHA}.txt"
#
#if [ -f "${SOURCE_COMMIT_SHA}.txt" ]; then
#  file_content=$(cat "${SOURCE_COMMIT_SHA}.txt")
#  if [ "$file_content" = "SKIP SCAN" ]; then
#    echo "SKIPPED"
#    exit 0
#  fi
#fi

#echo "Received arg is $SOURCE_COMMIT_SHA"
#all_files=$(pwd && ls -l)
#echo "$all_files"

SOURCE_COMMIT_BRANCH=""
echo "Received arg is $SOURCE_COMMIT_BRANCH"
if [ "$SOURCE_COMMIT_BRANCH" != "master" ] && [ -z "$SOURCE_COMMIT_BRANCH" ]; then
    echo "val is empty"
    exit 0
fi