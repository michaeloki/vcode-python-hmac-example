#!/bin/bash
# Source the codeAnalysis.sh file to get the app name variable being sent to the python script
# if python --version &>/dev/null; then
# appname="integration/payment-bpc-integration-service[gl1489]"
# Read the argument value
appname=$1
k2=$2
k3=$3



#if [ -f "pipeline_stage_tracker.txt" ]; then
#  evaluation_file=$(cat "pipeline_stage_tracker.txt")
#  status=$(jq '.status' "$evaluation_file")
#  if [ "$status" = "FAIL" ]; then
#    exit 1
#  fi
#fi


function finalise_evaluation {
      python3 getGuidByAppName.py --arg1 "$appname" --arg2 "$k2" --arg3 "$k3"
      value=$(echo "$appname" | grep -Eo "\[([^][]*)]")
      string_length=${#value}
      last_index=$((string_length - 2))
      content=${value:1:last_index}
      file_check=$content".txt"
      if [ -f "$file_check" ]; then
            file_content=$(cat "$file_check")
            echo "The JSON object is $file_content"
            echo " file name is $file_check"
            status=$(jq '.status' "$file_check")
            echo "status is $status"
            status_text=${status:1:${#status}-2}
            echo $status_text
            echo "$status_text" > evaluation_output.txt
            #statusii=$(trim  ["$status"])
            #echo $statusii > evaluation_output.txt
            #if [ -f "evaluation_output.txt" ] && grep -qx "PASS" "evaluation_output.txt"; then echo "PASS"; echo "aha"; fi

          if [ "$status_text" = "FAIL" ]; then # read the json content in the txt and extract the value of the status key
            echo "Severe vulnerabilities were found and we'll block this pipeline in Q3"
            echo "JSON file content is $file_content "
            echo "$file_content" > verdict.txt # write the JSON payload to this file
            # Uncomment the following line on Sept 30,2024.
            # exit 1
            rm -f "$file_check"
          fi
          if [ "$status_text" = "PASS" ]; then
            echo "No severe source code vulnerabilities were found!"
            echo "$file_content" > verdict.txt # write the JSON payload to this file
          fi
      else
#      echo "File name is $content"
#      file_check=$content".txt"
#      echo "The files and dirs here are $(ls), I'm looking for $file_check"
#      if [ -f "$file_check" ]; then
#        if [ "$(cat "$file_check")" = "FAIL" ]; then
#          echo "Severe vulnerabilities were found will block this pipeline in Q3"
#          echo "FAIL" > verdict.txt
##          data=$(echo '{}' | jq '.field1="value1" | .field2="value2"')
##          echo $data
#          rm -f "$file_check"
#        else
#          echo "No severe vulnerabilities were found"
#          echo "PASS" > verdict.txt
#        fi
#      else
        echo "There is no result file to evaluate for $appname in $(pwd)"
      fi
}
# Display the argument value
# echo "The argument value is: $appname"
# appname="consumer/vas-account-bpc-integration-service[gl1776]"
# merchant/merchant-payments-search-service[gl235]
#if python --version >/dev/null 2>/dev/null; then
#    echo "Python 2 is installed."
#else
#    echo "Python 2 is not installed."
#fi
# Check if Python 3 is installed
if python3 --version &>/dev/null; then
    echo "Python 3 is installed."
    if pip3 list | grep -q requests; then
      echo "Calling the python script with app name $appname"
      finalise_evaluation
    else
      # Install 'prerequisites' for Python 3
      echo "Package 'requests' should be installed for Python 3."
      echo "Installing dependencies..."
      pip3 install -r requirements.txt
      if pip3 list | grep -q requests; then
      echo "Package 'requests' is already installed for Python 3."
      #echo "Calling the python script with app name '$appname' "
      finalise_evaluation
      fi
    fi
else
    echo "Python 3 is not installed. Please install Python 3 first."
    exit 1
fi





#
## Check if 'requests' is installed in Python 3
#if pip3 list | grep -q requests; then
#    echo "Package 'requests' is already installed for Python 3."
#else
#    # Install 'prerequisites' for Python 3
#    pip3 install -r requirements.txt
#    echo "Package 'requests' should be installed for Python 3."
#fi
