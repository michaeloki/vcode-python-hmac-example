#!/bin/bash
if python --version >/dev/null 2>/dev/null; then
    echo "Python 2 is installed."
else
    if python3 --version &>/dev/null; then
       echo "Python 3 is installed."
       echo "Calling the python script with app name $appname"
       python3 getGuidByAppName.py --arg1 "$appname"
    else
       echo "Python 3 is not installed. Please install Python 3 first."
       exit 1
    fi
fi
#    appname="wero-app"
#    export vc_app_name=$appname
#    echo "Found  app name is $vc_app_name"
#    echo "$vc_app_name" > dynamic_file.txt
#    value=$(cat dynamic_file.txt)
#    echo "Dynamic says $value"
#    if [ -f "dynamic_file.txt" ]; then echo "app name is $(cat dynamic_file.txt)"; else echo "app name not found"; fi
#    echo "current dir is $(pwd)"
#    if [ -d artifacts ]; then cd artifacts || return; else echo "Artifacts directory doesn't exist"; fi
#    #if [ -f "dynamic_file.txt" ]; then echo "app name is $(cat dynamic_file.txt)"; fi
#
#    if python3 --version &>/dev/null; then
#       echo "Python 3 is installed."
#       echo "Calling the python script with app name $appname"
#    else
#       echo "Python 3 is not installed."
#       if python --version >/dev/null 2>/dev/null; then
#         echo "Python 2 is installed"
#       exit 1
#       fi
#    fi