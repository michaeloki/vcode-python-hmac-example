#!/bin/bash

# Download the RSS feed
#output=$(curl -s https://www.bleepingcomputer.com/feed/ > bleepingcomputer.rss)
#echo "$output"
# Search for the words "Microsoft" or "Mac"
# grep -i -o "Microsoft\|Mac" bleepingcomputer.rss

# curl -s https://www.bleepingcomputer.com/feed/ | grep -oP '(?<=<title>).*?(?=</title>)' | sed 's/<[^>]*>//g'

echo "Install xmlstarlet"
#brew install xmlstarlet
#curl -s https://www.bleepingcomputer.com/feed/ | grep -o '<title>.*</title>' | sed 's/<title>//;s/<\/title>//'

#GOOOODDD
#curl -s https://www.bleepingcomputer.com/feed/ | xmlstarlet sel -t -v "//item/title" | \
#grep -i -E 'microsoft|apple|macos|macbook|windows' | xmlstarlet sel -t -v "//item/link"

curl -s https://www.bleepingcomputer.com/feed/ | grep -o '<title>.*</title>' | \
sed 's/<title>//;s/<\/title>//' | grep -i -E 'microsoft|apple|macos|macbook|windows|android|ios|aws|azure|intune|gitlab|exploit'

