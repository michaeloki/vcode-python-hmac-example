#!/bin/bash
sed 's/<username>.*<\/username>/<username>samsung<\/username>/g; s/<password>.*<\/password>/<password>tv<\/password>/g' settings.xml > s_settings.xml

# xmlstarlet ed -u "//username" -v "samsung" -u "//password" -v "tv" settings.xml > /dev/null 2>&1
# sed 's/<username>${security.getCurrentUsername()}/<username>samsung/g' settings.xml
#xmlstarlet ed -u "//username" -v "samsung" -u "//password" -v "tv" settings.xml > settings_2.xml

#xmlstarlet ed -u "//username" -v "samsung" -u "//password" -v "tv" --in-place settings.xml
# xmlstarlet ed -u "//username" -v "samsung" -u "//password" -v "tv" -L settings.xml

#sed 's/<password>${security.getEscapedEncryptedPassword()}/<password>tv/g' settings.xml > settings.xml
#sed 's/<password>${security.getEscapedEncryptedPassword()!"*** Insert encrypted password here ***"}/<password>tv/g' settings.xml
 #> /dev/null 2>&1

#!/bin/bash

# Usage: ./update-xml.sh file.xml
# This will replace the <username> and <password> values

FILE="settings.xml"

if [[ -z "$FILE" ]]; then
  echo "Usage: $0 file.xml"
  exit 1
fi

if [[ ! -f "$FILE" ]]; then
  echo "Error: File '$FILE' not found!"
  exit 1
fi

# Use xmlstarlet if available (preferred)
#if command -v xmlstarlet >/dev/null 2>&1; then
#  xmlstarlet ed -L \
#    -u "//username" -v "samsung" \
#    -u "//password" -v "tv" \
#    "$FILE"
#    echo "uname111 is $(uname)"
#else
#  echo "uname000 is $(uname)"
  user="sharp"
  pass="move"
  # Fallback to sed (works for simple XML without namespaces/attributes)
  if [[ "$(uname)" == "Darwin" ]]; then
  # macOS BSD sed
  echo "macOS"
  sed -i '' 's|\(<username>\)[^<]*\(<\/username>\)|\1'$user'\2|' "$FILE"
  sed -i '' 's|\(<password>\)[^<]*\(<\/password>\)|\1'$pass'\2|' "$FILE"
  else
  # Linux GNU sed
  sed -i 's|\(<username>\)[^<]*\(<\/username>\)|\1'$user'\2|' "$FILE"
  sed -i 's|\(<password>\)[^<]*\(<\/password>\)|\1'$pass'\2|' "$FILE"
  fi
#fi

echo "Updated <username> and <password> in $FILE"