# default_similarity_ratio = string_similarity(component, comp_name)
# print("The default_similarity_ratio ratio is: ", default_similarity_ratio)

# Split with : delimeter , check the length, if it is higher than 2, use -1 to get the last index and
# [0] to get the get the first index, compare [0] of x to [0] of y
# else use [1]

# version_number = component[22:].split(":")
# print(f"ver_num is {version_number[0]}")
# print(f"component[22:] is {component[22:]}")

########
# version_number = component[22:].split(':')[1]
# print(f"ver_num is {version_number}")
#
# libstr = comp_name.split("-")
# print(f" lib num is {libstr[-1]}")
#
# similarity_ratio = string_similarity(component, comp_name)
# print("The similarity ratio is: ", similarity_ratio)
#####

# if default_similarity_ratio > 0.49:
# # if similarity_ratio > 0.6 and default_similarity_ratio > 0.3:
#     print("update the document")
#     if status.upper() == "OPEN" and current_status.upper() == "OPEN":
#         print("Update the Excel file")
#         update_excel(sheet, resolution.upper())
# else:
#     print(f"No similarity {resolution.upper()}")
#     update_excel(sheet, resolution.upper())

# update_excel(sheet, status.upper())
# if status.upper() == "OPEN" and current_status.upper() == "OPEN":
#     print("Update the Excel file")
#     update_excel(sheet, resolution.upper())
# else:
#     update_excel(sheet, status.upper())
#     print(f" Update the column with the API status {status.upper()}")

# version_number = component[22:].split(":")
# print(f"token length is {len(version_number)}")
# if len(version_number) > 1:
#     print(f"Version number (a) {version_number[1]}")
# if len(version_number) == 1:
#     print(f"Version number (b) {version_number[0]}")
# try:
#     ver_num = version_number[1]
#     print(f"version_number is {ver_num}")
# except Exception as ex:
#     print(f"{ex}")

# api_lib_name = comp_name.split("-")
# print(f"Full component_name is {api_lib_name}")
# try:
#     comp_name_ver = api_lib_name[-1]
#     # local_ver = version_number[1]
#     print(f"local_ver is {version_number[1]} and API ver is {comp_name_ver} ")
#     # # print(f"API Lib names are {api_lib_name[0]} and {api_lib_name[1]}")
# except Exception as ex:
#     print("ex")

# if (api_lib_name[0] in comp_name or api_lib_name[1] in comp_name) and local_ver in comp_name_ver:
#     print(f"Update the Excel file with {resolution.upper()} the status is {status.upper()}")
#     update_excel(sheet, resolution.upper())
#
#     if status.upper() == "OPEN" and current_status.upper() == "OPEN":
#         print("Update the Excel file")
#         # update_excel(sheet, resolution.upper())
#     else:
#         # update_excel("Monet", status.upper())
#         print(f" Update the column with the API status {status.upper()}")
