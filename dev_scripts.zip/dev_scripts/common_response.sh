#!/bin/bash
input_filei="pipeline_stage_trackerss.txt"

function stop_feedbfack() {
  msg=$1
  scanTypeMsg=$2
  if [ -f "$input_file" ]; then
    content=$(cat input_file)
    #modified_content=$(echo "$content" | jq '.summary |= . + "'."$msg".'" ')
    modified_content=$(echo "$content" | jq '.scanType += ['\""$scanTypeMsg"\"']' )
    echo "$modified_content" > $input_file
    echo "The modified content of the $input_file file is $modified_content"
  else
    json_object=$(echo '{}' | jq '. + {"status": "FAIL", "summary":"'"$msg"'", "appName": "", "scanType": ["'"$scanTypeMsg"'"],
    "message": "'"$scanTypeMsg"'   failed"}')
    echo "$json_object" > $input_file
    echo "$json_object was successfully saved in $(pwd)"
  fi
  exit 1
}

stop_feedback_working_version() {
  msg=$1
  scanTypeMsg=$2
  echo "msg is $msg and scanTypeMsg is $scanTypeMsg"
  if [ -f "stage_output.txt" ]; then
  content=$(cat stage_output.txt)
  #modified_content=$(echo "$content" | jq '.summary |= . + '."$msg1".' ')
  # Get the scan type key value and append the new string to the old one
  #scanType=$(jq '.scanType' "stage_output.txt")
  # echo "=== scantype is $scanType"
  # Use jq to update the JSON
  #json=$(echo $json | jq '.summary = "'$new_summary'"')
  #json=$(echo $json | jq '.scanType += ['\"$new_scan_type\"']')
  #modified_content=$(echo "$content" | jq '.summary += . + ".'"$msg1"'."' )
  modified_content=$(echo "$content" | jq '.scanType += ['\""$scanTypeMsg"\"']' )
  #modified_content=$(echo "$content" | jq '.summary |= . + ".'"$msg1"'." | .scanType |= . + ".'"$scanType"'."' )
  #echo $modified_content
  echo "$modified_content" > stage_output.txt
  echo "The modified content of the stage_output.txt file is $modified_content"
else
  json_object=$(echo '{}' | jq '. + {"status": "FAIL", "summary":"'"$msg"'", "appName": "", "scanType": ["internal_dep_scan"],
"message": "The internal dependency stage failed"}')
  echo "$json_object" > stage_output.txt
  echo "No project namespace, a $json_object was successfully saved in $(pwd)"
fi
}

input_file="pipeline_stage_tracker.txt"

function stop_feedback() {
  msg=$1
  scanTypeMsg=$2
  echo "$msg"
  if [ -f $input_file ]; then
    content=$(cat $input_file)
    modified_content=$(echo "$content" | jq '.scanType += ['\""$scanTypeMsg"\"']' )
    echo "$modified_content" > $input_file
    echo "The modified content of the $input_file file is $modified_content"
  else
    json_object=$(echo '{}' | jq '. + {"status": "FAIL", "summary":"'"$msg"'", "appName": "", "scanType": ["internal_dep_scan"], "message": "The internal dependency stage failed"}')
    echo "$json_object" > $input_file
    echo "$json_object was successfully saved in $(pwd)"
  fi
  exit 1
}
