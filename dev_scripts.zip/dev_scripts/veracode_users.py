import sys
import requests
import header
import pandas as pd

from veracode_api_signing.plugin_requests import RequestsAuthPluginVeracodeHMAC


api_base = "https://api.veracode.com"

headers = {"User-Agent": "SecPipeline"}
excel_file_path = 'test_list.xlsx'
tag = "Manufacturing"
email= ""

def get_all_users():
    try:
        response = (requests.get
                    (api_base + "/api/authn/v2/users",
                     auth=RequestsAuthPluginVeracodeHMAC
                     (api_key_id=header.KEY_ID,
                      api_key_secret=header.SECRET),
                     headers=headers))
        if response.ok:
            data = response.json()
            print(f"raw data is ${data}")
            all_users = data["_embedded"]["users"]
            num_of_users = len(all_users)
            print("Checking " + str(num_of_users))
    except requests.RequestException as re:
        print("Users fetched are... " + str(re))
        sys.exit(1)

# get_all_users()

def get_user_by_email(user: str):
    try:
        response = (requests.get
                    (api_base + "/api/authn/v2/users?user_name="+user,
                     auth=RequestsAuthPluginVeracodeHMAC
                     (api_key_id=header.KEY_ID,
                      api_key_secret=header.SECRET),
                     headers=headers)
                    )
        if response.ok:
            data = response.json()
            print(f"data is {data}")
            if "_embedded" in data:
                print("The key '_embedded' exists.")
    except requests.RequestException as re:
        print("getUsers API... " + str(re))
        sys.exit(1)



def delete_user_by_email(user: str):
    try:
        response = (requests.get
                    (api_base + "/api/authn/v2/users?user_name="+user,
                     auth=RequestsAuthPluginVeracodeHMAC
                     (api_key_id=header.KEY_ID,
                      api_key_secret=header.SECRET),
                     headers=headers)
                    )
        if response.ok:
            data = response.json()
            print(f"data is {data}")
            if "_embedded" in data:
                print("The key '_embedded' exists.")
                if data is not None:
                    print(f"raw data is ${data}")
                    user_data = data["_embedded"]["users"]
                    if len(user_data) == 1:
                        user_name = user_data[0]["user_name"]
                        user_id = user_data[0]["user_id"]
                        print(f"user_id is {user_id}")
                        if user_name == user:
                            print("Delete this user")
                            try:
                                delete_response = (requests.delete
                                    (api_base + "/api/authn/v2/users/"+user_id,
                                     auth=RequestsAuthPluginVeracodeHMAC
                                     (api_key_id=header.KEY_ID,
                                      api_key_secret=header.SECRET),
                                     headers=headers))
                                if delete_response.ok:
                                    print(f"delete response code is {delete_response.status_code} ")
                            except requests.RequestException as re:
                                print("Delete failed.. " + str(re))

            else:
                print("The key '_embedded' does not exist.")

    except requests.RequestException as re:
        print("Users fetched are... " + str(re))
        sys.exit(1)



# Read the Excel sheet
def read_excel_sheet(excel_file_path):
    try:
        df = pd.read_excel(excel_file_path)
        return df
    except Exception as e:
        print(f"Error reading Excel sheet: {e}")
        return None

# Get the values in column 2, line by line, until an empty row is encountered
def get_column_values(df):
    if df is not None:
        try:
            column_values = []
            for index, row in df.iterrows():
                if pd.isnull(row[1]):
                    break
                column_values.append(row[1])
            return column_values
        except IndexError as e:
            print(f"Error accessing column 2: {e}")
            return None
    return None


def delete_users():
    df = read_excel_sheet(excel_file_path)
    column_values = get_column_values(df)
    if column_values is not None:
        print("Values in column 2:")
        for value in column_values:
            print(value)
            delete_user_by_email(value)
    else:
        print("Failed to read Excel sheet or access column 2.")
        sys.exit(1)

# delete_users()

get_user_by_email(email)






