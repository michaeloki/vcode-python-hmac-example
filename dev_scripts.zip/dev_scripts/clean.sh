#!/bin/bash

echo "===== CLEANUP FILE ====="