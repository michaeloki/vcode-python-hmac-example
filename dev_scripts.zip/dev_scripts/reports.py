import header

#

import sys
import requests
from veracode_api_signing.plugin_requests import RequestsAuthPluginVeracodeHMAC

import header

api_base = "https://analysiscenter.veracode.com/"

headers = {"User-Agent": "Python HMAC Example"}

GUID = "c4d7d364-fbac-4d51-a1a7-52799d817c8a"
PROJECT_ID = "151"
if __name__ == "__main__":

    try:
        response = (requests.get
                    (api_base + "api/v3/projects/"+PROJECT_ID+"/reports",
                     auth=RequestsAuthPluginVeracodeHMAC
                     (api_key_id=header.KEY_ID,
                      api_key_secret=header.SECRET),
                     headers=headers))
    except requests.RequestException as e:
        print("Whoops!")
        print(e)
        sys.exit(1)

    if response.ok:
        data = response.json()
        print(data)
        # for app in data["_embedded"]["applications"]:
        #     print(app["profile"]["name"])
        #for app in data['_embedded']['findings']:
        #   print(app['finding_details']['severity'])
        #[0]['finding_details']['severity']
        # severity = data['_embedded']['findings'][0]['finding_details']['severity']
        # print("severity is " + str(severity))
    else:
        print(response.status_code)
