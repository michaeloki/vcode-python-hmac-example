import os
import shutil

from difflib import SequenceMatcher
from datetime import datetime


def string_similarity(a, b):
    return SequenceMatcher(None, a, b).ratio()


# Usage
# string1 = "Jose4j:0.9.3" #"This is a test string"
# string2 = "nimbus-jose-jwt-9.31.jar" #"This_is_a_test_string"
# similarity_ratio = string_similarity(string1, string2)
# print("The similarity ratio is: ", similarity_ratio)

#  SpringWeb:5.3.31,(2) to API compName spring-webmvc-6.1.12.jar
# Jose4j:0.9.3 to API compName nimbus-jose-jwt-9.31.jar
# Jose4j:0.9.3 to API compName nimbus-jose-jwt-9.31.jar
# protobuf-java-3.10.0.jar
#
# component = "ProtocolBuffers[Core]:3.10.0"
# libnn = "protobuf-java-3.10.0.jar"
# component = component.replace(' ', '')
#
# similarity_ratio = string_similarity(libnn, component)


# version_number = component[22:].split(":")
# print(f"ver_num is {version_number[0]}")
#
# libnn = "protobuf-java-3.10.0.jar"
# libComp = libnn.split("-")
# print(f" lib num is {libComp[-1]}")
#
# similarity_ratio = string_similarity(version_number[0], libComp[-1])
# # similarity_ratio = string_similarity(version_number[0], libComp[-1])
#print("The similarity ratio is: ", similarity_ratio)


# SnakeYAML:1.30 to API compName snakeyaml-1.30.jar

# given_string = "BouncyCastleProvider:1.73"
#version_number2 = given_string2.split('-')[-1]
#print(f" {version_number} and {version_number2}")


#######

# given_string2 = "snakeyaml-1.30.65.jar"
# given_string = "SnakeYAML:1.30"
#
# version_number = given_string.split(':')[-1]
# version_numb = given_string2.split('-')[-1]
#
# print(f" {version_numb.lower()} and {version_number.lower()}")


# similarity_ratio = string_similarity(version_numb, version_number)
# print("The similarity ratio is: ", similarity_ratio)


# Specify the file path
#file_path = '1.30'  # no .jar extension

# Check if the file has a .jar extension


# if version_numb.lower() == version_number.lower():
#     print("yes")
# else:
#     if version_numb.lower().__contains__("jar"):
#         print(f"hello jar {version_numb.lower()[0:-4]}")
#
#
#     else:
#         print("no jar")

# x = "LogbackCoreModule:1.2.11"
# new_comp_name = x.split(':')[0]
# print(f"new_comp_name is {new_comp_name.lower()}")
# api = "Logback-Core-Module"
# fott = ''.join(char for char in api if char.isalnum())
# if new_comp_name.lower().__contains__(fott.lower()):
#     print("aha")
# else:
#     print("nee")

x_str = "protobufjava"
#y_str="protocolbufjavakkk"
y_str = "protocolbufferscore"
similarity_ratio = string_similarity(x_str, y_str)
print("The similarity ratio is: ", similarity_ratio)

# if x_str.lower() in y_str.lower():
#     print("yes")
# else:
#     print("no")
# print(check_substring("protocolbufferscore", "protobufjava"))
# if os.path.splitext(version_numb.lower())[1] == '.jar':
#     new_file_name = os.path.splitext(version_numb.lower())[0] + '.jar'
#     shutil.move(version_numb.lower(), new_file_name)
#     if version_numb.lower() == version_number.lower():
#         print("yes")
#     else:
#         print("different version numbers")

#
current_datetime = datetime.now()
#
# print(current_datetime)

formatted_datetime = current_datetime.strftime('%d_%m_%Y_%H_%M_%S')
print(formatted_datetime[:-1])
