import os
import re

print("HELLO WORLD")
destination = "yess"
result = "PASS"

# app1 = "merchant/merchant-payments-search-service[gl235]"
# match = re.search(r'\[(.*?)]', app1)
#
# if match is not None:
#     # Extract the content
#     content = match.group(1)
#     # Set the full path where you want to create the file
#     file_path = os.path.join('', content + '.txt')
#     with open(file_path, 'w') as f:
#         f.write(result)
#     print("io is complete")

# file_name = destination.__addj__(".csv")
#
# pjrint(file_name)


my_set = {"advertsearch", "appsearch", "ddw"}
for item in my_set:
    print(item)
