#!/bin/bash
#cd /Users/michaeloki/wildfly-20.0.1.Final/bin || exit
#./jboss-cli.sh --connect command:shutdown

sudo pkill -f wildfly