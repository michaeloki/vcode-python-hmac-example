import logging
import argparse

logging.basicConfig(level=logging.INFO)
from slack_sdk import WebClient

def upload_file_to_slack(channel_id: str, filename: str, slack_bot_token: str, title: str):
    print(f"Universal file upload")
    client = WebClient(slack_bot_token)
    client.files_upload_v2(
        channel=channel_id,
        title=title,
        file=filename,
        initial_comment="File created",
    )

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--arg1", type=str, help="First argument:channelID")
    parser.add_argument("--arg2", type=str, help="Second argument:filename")
    parser.add_argument("--arg3", type=str, help="Third argument:slack_bot_token")
    parser.add_argument("--arg4", type=str, help="Fourth argument:title")

    args = parser.parse_args()
    upload_file_to_slack(args.arg1, args.arg2, args.arg3, args.arg4)
