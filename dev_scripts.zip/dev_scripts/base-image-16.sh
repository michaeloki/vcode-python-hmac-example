#!/bin/bash

TRACK_FILE=tracking_vars.node16-debian.env
if [ -f "$TRACK_FILE" ];
then echo "ALL GOOD"
while read line;
do echo "$line";
# do export "$line";
done < "$TRACK_FILE";
else echo "ERROR";
fi


if [ -f "$RACK_FILE" ];
then
while read line;
do export "$line";
done < "$RACK_FILE";
else echo "ERROR";
fi
