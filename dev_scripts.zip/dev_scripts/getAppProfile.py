# http --auth-type=veracode_hmac GET "https://api.veracode.com/appsec/v1/applications/?name={name}"
import sys
import requests
from veracode_api_signing.plugin_requests import RequestsAuthPluginVeracodeHMAC

import header
api_base = "https://api.veracode.com/appsec/v1"

# fe6b265f-d9a2-4894-b681-f3ebffaf99f1
#
APP_NAME = "payment/payment-service[gl108]"
# APP_NAME = "merchant/merchant-payments-search-service[gl235]"
if __name__ == "__main__":

    try:
        response = (requests.get
                    (api_base + "/applications/?name=" + APP_NAME,
                     auth=RequestsAuthPluginVeracodeHMAC
                     (api_key_id=header.KEY_ID,
                      api_key_secret=header.SECRET),
                     headers=header.headers))
    except requests.RequestException as e:
        print("Whoops!")
        print(e)
        sys.exit(1)

    if response.ok:
        data = response.json()
        print("Showing application profile")
        print(data)
        # for app in data["_embedded"]["applications"]:
        #     print(app["profile"]["name"])
        #for app in data['_embedded']['findings']:
        #   print(app['finding_details']['severity'])
        #[0]['finding_details']['severity']
        # severity = data['_embedded']['findings'][0]['finding_details']['severity']
        # print("severity is " + str(severity))
    else:
        print(response.status_code)
