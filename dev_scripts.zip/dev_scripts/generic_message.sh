function stop_feedback() {
  msg=$1
  scanTypeMsg=$2
  if [ -f "pipeline_stage_tracker.txt" ]; then
    content=$(cat pipeline_stage_tracker.txt)
#    modified_content=$(echo "$content" | jq '.summary |= . + " '"$msg"' " ')
#    modified_content=$(echo "$content" | jq '.scanType = ['\""$scanTypeMsg"\"']' )
    modified_content=$(echo "$content" | jq '.summary |= . + " '"$msg"' " ' | "$content" | jq '.scanType = ['\""$scanTypeMsg"\"']' |  "$content" | jq '.message |= . +  "The  '"$scanTypeMsg"'  failed " ')
    echo "$modified_content" > pipeline_stage_tracker.txt
    echo "The modified content of the pipeline_stage_tracker.txt file is $modified_content"
  else
    json_object=$(echo '{}' | jq '. + {"status": "FAIL", "summary":"'"$msg"'", "appName": "", "scanType": ["'"$scanTypeMsg"'"],"message": "The '"$scanTypeMsg"' failed. "}')
    echo "$json_object" > pipeline_stage_tracker.txt
    echo "$json_object was successfully saved in $(pwd)"
  fi
  exit 1
}