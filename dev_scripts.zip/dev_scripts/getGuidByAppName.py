# http --auth-type=veracode_hmac GET "https://api.veracode.com/appsec/v2/applications/{application_guid}/findings?severity_gte=3"
# http --auth-type=veracode_hmac GET "https://api.veracode.com/appsec/v1/applications/?name={name}"
import sys
import requests
from veracode_api_signing.plugin_requests import RequestsAuthPluginVeracodeHMAC

import header  # DELETE THIS LINE BEFORE YOU COMMIT AND USE GITLAB VARIABLES
import argparse
import os
import re
import json

api_base = "https://api.veracode.com/appsec/"


# app_name = "merchant/merchant-payments-search-service[gl235]"
# processing/issuer-notification-service[gl916]
# integration/consumer-bpc-integration-service[gl1570]

def create_result_file(status_text: str, summary_text: str, app_name: str, filename: str):
    print("...Creating a new file...")

    if filename.strip().endswith("txt"):
        payload = {
            "status": status_text,
            "summary": summary_text,
            "appName": app_name,
            "scanType": ["SAST"],
            "message": "We will start hard-blocking the pipeline when we notice a high or severe vulnerability as "
                       "from September 9, 2024"
        }

        json_payload = json.dumps(payload)

        file_path = os.path.join('', filename)
        file_path = file_path[:-4]

        result_string = re.sub(r'\W', '', file_path)

        with open(result_string, 'w') as f:
            f.write(json_payload)
        if os.path.isfile(result_string + ".txt"):
            print("The JSON payload was successfully created")


def findings(guid, app_name):
    print("Fetching findings for GUID " + guid + " with app name " + app_name)

    try:
        response = (requests.get
                    (api_base + "v2/applications/" + guid + "/findings?scan_type=STATIC&status=OPEN",
                     auth=RequestsAuthPluginVeracodeHMAC
                     (api_key_id=header.KEY_ID,
                      api_key_secret=header.SECRET),
                     headers=header.headers))
    except requests.RequestException as e:
        print("Whoops!")
        print(e)
        sys.exit(1)

    if response.ok:
        data = response.json()
        try:
            detailed_comment = "There are no OPEN findings to report"
            all_findings = data["_embedded"]["findings"]
            num_of_findings = len(all_findings)
            print("Checking " + str(num_of_findings) + " SAST findings(s)")
            print(all_findings)
            severity_score = 0

            for index in range(len(all_findings)):
                print("index is ==== " + str(index))
                # last_index = len(all_findings) - 1
                # resolution_status = data["_embedded"]["findings"][index]["finding_status"]["resolution"]
                # status = data["_embedded"]["findings"][index]["finding_status"]["status"]
                # first_found = data["_embedded"]["findings"][index]["finding_status"]["first_found_date"]
                # last_seen = data["_embedded"]["findings"][index]["finding_status"]["last_seen_date"]
                # Is it a closed finding, skip else push it into the array
                severity = data["_embedded"]["findings"][index]["finding_details"]["severity"]
                status = data["_embedded"]["findings"][index]["finding_status"]["status"]
                if status.upper() == "OPEN":
                    print("severity is ==== " + str(severity))
                    if severity_score < severity:
                        severity_score = severity
                        resolution_status = data["_embedded"]["findings"][index]["finding_status"]["resolution"]
                        first_found = data["_embedded"]["findings"][index]["finding_status"]["first_found_date"]
                        last_seen = data["_embedded"]["findings"][index]["finding_status"]["last_seen_date"]
                        cwe_id = data["_embedded"]["findings"][index]["finding_details"]["cwe"]["id"]
                        cwe = data["_embedded"]["findings"][index]["finding_details"]["cwe"]["name"]
                        severity = data["_embedded"]["findings"][index]["finding_details"]["severity"]
                        detailed_comment = (
                                "The resolution status of the finding is " + resolution_status + " and the status is " + status +
                                ". This issue was first found on " + first_found + " and last seen on " + last_seen +
                                ". The severity is " + str(severity) + " and the CWE is " + "'" + str(cwe) + "'" +
                                ", the CWE_ID is " + str(cwe_id))
                        # priority_index = index
                # cwe_id = data["_embedded"]["findings"][index]["finding_details"]["cwe"]["id"]
                # cwe = data["_embedded"]["findings"][index]["finding_details"]["cwe"]["name"]
                # print("\nFinding status' resolution is " + resolution_status + " and the status is " + status)
                # print("This issue was first found on " + first_found + " and last seen on " + last_seen)
                # print("The severity is " + str(severity) + " and the CWE is " + "'" + str(
                #     cwe) + "'" + ", the CWE_ID is " + str(cwe_id))
                # print(f'Index: {index}, Value: {all_findings[index]}')

                # last_index = len(all_findings) - 1
                # print("Clicking here for index " + str(index))
                #status = data["_embedded"]["findings"][index]["finding_status"]["status"]

                #print("status is " + status)

            # detailed_comment = ("\nFinding status' resolution is " + resolution_status + " and the status is " + status +
            #                     ". This issue was first found on " + first_found + " and last seen on " + last_seen +
            #                     ". The severity is " + str(severity) + " and the CWE is " + "'" + str(cwe) + "'" +
            #                     ", the CWE_ID is " + str(cwe_id))
            # write this to a json file
            print("The highest severity score is " + str(severity_score))
            if severity_score >= 4:
                result = "FAIL"
            else:
                result = "PASS"
            print("result is " + result)
            # payload = {
            #      "status": result,
            #      "comment": detailed_comment,
            #      "appName": app_name,
            #      "scanType": "SAST"
            # }
            # json_payload = json.dumps(payload)
            # print(json_payload)
            # Find the value inside the square brackets
            match = re.search(r'\[(.*?)\]', app_name)
            if match is not None:
                # Extract the content
                content = match.group(1)
                # Set the full path where you want to create the file
                # print("content to be written is " + json_payload)
                print("The content file is named " + content + ".txt")
                file_path = os.path.join('', content + '.txt')
                create_result_file(result, detailed_comment, app_name, file_path)
                # with open(file_path, 'w') as f:
                #     f.write(json_payload)
                # if os.path.isfile(file_path):
                #     print(os.path.abspath(file_path))
                #     print("current PWD " + os.getcwd())
            else:
                print("The appID is missing " + app_name)
                create_result_file("PASS", "There's no evaluation result file for " + app_name, app_name,
                                   "pipeline_generic_message.txt")
        except Exception as e:
            print(str(e) + ":::: There are no findings for GUID " + str(guid))
            create_result_file("PASS", str(e) + ":::: There are no findings for GUID " + str(guid), app_name,
                               "pipeline_message.txt")
    else:
        print(response.status_code)


def sca_findings(guid, app_name):
    print("Fetching SCA findings for GUID " + guid + " with app name " + app_name)

    try:
        response = (requests.get
                    (api_base + "v2/applications/" + guid + "/findings?scan_type=SCA&new=true",
                     auth=RequestsAuthPluginVeracodeHMAC
                     (api_key_id=header.KEY_ID,
                      api_key_secret=header.SECRET),
                     headers=header.headers))
    except requests.RequestException as e:
        print("Whoops!")
        print(e)
        sys.exit(1)

    if response.ok:
        data = response.json()
        try:
            detailed_comment = "There are no OPEN findings to report"
            all_findings = data["_embedded"]["findings"]
            num_of_findings = len(all_findings)
            print("Checking " + str(num_of_findings) + " SAST findings(s)")
            print(all_findings)
            severity_score = 0

            for index in range(len(all_findings)):
                print("index is ==== " + str(index))
                severity = data["_embedded"]["findings"][index]["finding_details"]["severity"]
                status = data["_embedded"]["findings"][index]["finding_status"]["status"]
                if status.upper() == "OPEN":
                    print("severity is ==== " + str(severity))
                    if severity_score < severity:
                        severity_score = severity
                        resolution_status = data["_embedded"]["findings"][index]["finding_status"]["resolution"]
                        first_found = data["_embedded"]["findings"][index]["finding_status"]["first_found_date"]
                        last_seen = data["_embedded"]["findings"][index]["finding_status"]["last_seen_date"]
                        cwe_id = data["_embedded"]["findings"][index]["finding_details"]["cwe"]["id"]
                        cwe = data["_embedded"]["findings"][index]["finding_details"]["cwe"]["name"]
                        severity = data["_embedded"]["findings"][index]["finding_details"]["severity"]
                        detailed_comment = (
                                "The resolution status of the finding is " + resolution_status + " and the status is " + status +
                                ". This issue was first found on " + first_found + " and last seen on " + last_seen +
                                ". The severity is " + str(severity) + " and the CWE is " + "'" + str(cwe) + "'" +
                                ", the CWE_ID is " + str(cwe_id))
            print("The highest severity score is " + str(severity_score))
            if severity_score >= 4:
                result = "FAIL"
            else:
                result = "PASS"
            print("result is " + result)
            match = re.search(r'\[(.*?)\]', app_name)
            if match is not None:
                # Extract the content
                content = match.group(1)
                # Set the full path where you want to create the file
                # print("content to be written is " + json_payload)
                print("The content file is named " + content + ".txt")
                file_path = os.path.join('', content + '.txt')
                create_result_file(result, detailed_comment, app_name, file_path)
            else:
                print("The appID is missing " + app_name)
                create_result_file("PASS", "There's no evaluation result file for " + app_name, app_name,
                                   "pipeline_generic_message.txt")
        except Exception as e:
            print(str(e) + ":::: There are no findings for GUID " + str(guid))
            create_result_file("PASS", str(e) + ":::: There are no findings for GUID " + str(guid), app_name,
                               "pipeline_message.txt")
    else:
        print(response.status_code)


# def get_file_directory(file_path):
#     if os.path.isfile(file_path):
#         return os.path.abspath(file_path)
#     else:
#         return "File not found."

def evaluate_app_profile(app_name):
    print("appname" + app_name)
    try:
        if len(str(app_name)) > 1:
            response = (requests.get
                        (api_base + "v1/applications/?name=" + str(app_name),
                         auth=RequestsAuthPluginVeracodeHMAC
                         (api_key_id=header.KEY_ID,
                          api_key_secret=header.SECRET),
                         headers=header.headers))
            if response.ok:
                data = response.json()
                print("======== Extracting the GUID from the application profile ========")
                # print(f"show the raw data {data['_embedded']['applications'][0]['guid']}")
                sca_findings(data["_embedded"]["applications"][0]["guid"], app_name)
                # findings(data["_embedded"]["applications"][0]["guid"], app_name)
            else:
                print(response.status_code)
        else:
            print("App name is empty")
    except requests.RequestException as e:
        print("Whoops!")
        print(e)
        sys.exit(1)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--arg1", type=str, help="First  argument")
    parser.add_argument("--arg2", type=str, help="sec  argument")
    parser.add_argument("--arg3", type=str, help="third  argument")

    args = parser.parse_args()

    print(f'Argument 1: {args.arg1}')
    print(f'Argument 2: {args.arg2}')
    print(f'Argument 3: {args.arg3}')

    # processing/ideal-address-service[gl1763] be84d469-28f7-4320-b42e-2d4b4c76adca

    #payment/payment-service[gl108] consumer/consumer-identification-service[gl467]  integration/invoice-service[gl349]
    # fe6b265f-d9a2-4894-b681-f3ebffaf99f1 with app name Currence/ideal-acquirer-gateway[gl859]
    # 10bc7872-1780-421b-a82c-de87c73bffc3 with app name Currence/ideal-issuer-gateway[gl869]
    evaluate_app_profile(args.arg1)
# a5930b52-6b47-44b1-9007-7b0813687ee8 and app name processing/ideal-payment-page-bff-service[gl884]
# consumer/consumer-profiling-service[gl434]
