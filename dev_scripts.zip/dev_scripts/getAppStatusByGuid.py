import sys
import requests
from veracode_api_signing.plugin_requests import RequestsAuthPluginVeracodeHMAC

import header

# below is for Veracode US Commercial region. For logins in other region uncomment one of the other lines
api_base = "https://api.veracode.com/appsec/v2"
#api_base = "https://api.veracode.eu/appsec/v1" # for logins in the Veracode European Region
#api_base = "https://api.veracode.us/appsec/v1" # for logins in the Veracode US Federal Region

headers = {"User-Agent": "Python HMAC Example"}

#requests. get(api_url,
# auth=RequestsAuthPluginVeracodeHMAC
# ( api_key_id=<YOUR_API_KEY>, api_key_secret=<YOUR_API_SECRET_KEY>))
# api/v3/projects/722/reports
# http --auth-type=veracode_hmac
# GET "https://api.veracode.com/appsec/v2/applications/{application_guid}/findings?scan_type=STATIC"
# GUID = "c4d7d364-fbac-4d51-a1a7-52799d817c8a"
GUID = "f7a86833-4d6a-4a46-b161-22f0d98e97ad"
if __name__ == "__main__":

    try:
        response = (requests.get
                    (api_base + "/applications/" + GUID + "/findings?scan_type=STATIC&new=true",
                     auth=RequestsAuthPluginVeracodeHMAC
                     (api_key_id=header.KEY_ID,
                      api_key_secret=header.SECRET),
                     headers=headers))
    except requests.RequestException as e:
        print("Whoops!")
        print(e)
        sys.exit(1)

    if response.ok:
        data = response.json()
        print(data)
        # for app in data["_embedded"]["applications"]:
        #     print(app["profile"]["name"])
        #for app in data['_embedded']['findings']:
        #   print(app['finding_details']['severity'])
        #[0]['finding_details']['severity']
        # severity = data['_embedded']['findings'][0]['finding_details']['severity']
        # print("severity is " + str(severity))
    else:
        print(response.status_code)
