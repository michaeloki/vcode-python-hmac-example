import csv

# Name of the CSV file
filename = "issues_new_SCA.csv"

# Column headers
headers = ["severity", "name", "cwe", "cve", "date", "status", "product"]

# Writing to the CSV file
with open(filename, 'w', newline='') as csvfile:
    # Creating a writer object
    writer = csv.writer(csvfile)

    # Writing the headers to the CSV
    writer.writerow(headers)