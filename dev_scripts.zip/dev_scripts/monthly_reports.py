import csv
import sys
import requests
import argparse
import os
import re
import json

from veracode_api_signing.plugin_requests import RequestsAuthPluginVeracodeHMAC

from datetime import datetime

api_base = "https://api.veracode.com"

headers = {"User-Agent": "SecPipeline"}

tag = "Manufacturing"

generic_page_number = 0

sbom_filename = "sbom_result_28_oct_2024"  #get the current date/time and append the page number [sbom_date_time_pagenumber]

formatted_datetime = ""

import header

sca_filename = ""

# Get a list of application profiles on vc and loop through to get the GUID and

def get_sbom_report2(guid: str, profile: str, key_id: str, secret: str, tstamp: str):
    # http --auth-type=veracode_hmac "https://api.veracode.com/srcclr/sbom/v1/targets/{applicationGuid}/cyclonedx?type=application"
    try:
        response = (requests.get
                    (api_base + "/srcclr/sbom/v1/targets/" + guid + "/cyclonedx?type=application",
                     auth=RequestsAuthPluginVeracodeHMAC
                     (api_key_id=key_id,
                      api_key_secret=secret),
                     headers=headers))
    except requests.RequestException as re:
        print("Static scan failed with " + str(re))
        sys.exit(1)

    if response.ok:
        data = response.json()
        print(f"raw data is ${data}")
        print(f"DEP {data['vulnerabilities']}")

        try:
            for index, app in enumerate(data['vulnerabilities']):
                ratings = app['ratings']
                desc = app['description']
                component = app['affects'][0]['ref'][:-1]
                rating = str(ratings[0]['severity']).upper()
                src_url = str(app['source']['url'])

                with open('sbom_report_' + formatted_datetime + str(generic_page_number) + '.csv', 'a', newline='') as static_file:
                    static_writer = csv.writer(static_file)
                    static_writer.writerow([profile, desc, component, rating, src_url])
                # for idx, comp in enumerate(app['affects']):
                #     print(f" affList {comp['ref']}")
                # print(f"DEP111 {comp[idx]}")
                # for idx, component in enumerate(app['affects']):
                # print(f"DEP {component[idx]}")
                # print(f"DEP {component['vulnerabilities'][index]['affects'][idx]['ref']}")
        except requests.RequestException as re:
            print("SBOM exception " + str(re))


def create_result_file(app_name: str, guid: str, issues: object):
    # HEADER -- Severity | Scan Type | Name | CWE | Date | Age | Product
    # def create_result_file(status_text: str, summary_text: str, app_name: str, filename: str):
    # [{"appName": "abc", "guid": "2424-2429hhfh-2424", "findings": [{"iss":"yes"}]}]
    # payload = {
    #     "status": status_text,
    #     "summary": summary_text,
    #     "appName": app_name,
    #     "scanType": ["SAST"],
    #     "message": "We will start hard-blocking the pipeline when we notice a high or critical vulnerability as "
    #                "from September 9th, 2024"
    # }
    # json_payload = json.dumps(payload)
    # file_path = os.path.join('', filename)
    # with open(file_path, 'w') as f:
    #     f.write(json_payload)
    # if os.path.isfile(file_path):
    #     print("The JSON payload was successfully created")

    # with open('issues_new_SCA.csv', 'w', newline='') as file:
    #     writer = csv.writer(file)
    #     writer.writerow(["SERIAL NO", "APP_NAME", "SCAN_TYPE", "STATUS", "FINDINGS"])
    #
    # import json

    # Create a dictionary to write in the JSON file
    data = {
        "app_name": app_name,
        "guid": guid,
        "findings": issues
    }

    # Write the dictionary to a JSON file
    with open('veracode_findings.json', 'w') as f:
        json.dump(data, f)

    # # Append a new line to the JSON file
    # with open('veracode_findings.json', 'a') as f:
    #     f.write('\n')

    # Append a new JSON object to the list in the JSON file
    with open('veracode_findings.json', 'r+') as f:
        data = json.load(f)
        data.append({"new_key": "new_value"})
        f.seek(0)  # Reset file position to the beginning
        json.dump(data, f)


def get_sbom_report(guid: str, profile: str, key_id: str, secret: str, tstamp: str):
    # http --auth-type=veracode_hmac "https://api.veracode.com/srcclr/sbom/v1/targets/{applicationGuid}/cyclonedx?type=application"
    try:
        response = (requests.get
                    (api_base + "/srcclr/sbom/v1/targets/" + guid + "/cyclonedx?type=application",
                     auth=RequestsAuthPluginVeracodeHMAC
                     (api_key_id=key_id,
                      api_key_secret=secret),
                     headers=headers))
    except requests.RequestException as re:
        print("Static scan failed with " + str(re))
        sys.exit(1)

    if response.ok:
        data = response.json()
        # print(f"raw data is ${data}")
        print(f"DEP {data['vulnerabilities']}")

        try:
            for index, app in enumerate(data['vulnerabilities']):
                ratings = app['ratings']
                created_date = app['created']
                desc = app['description']
                component = app['affects'][0]['ref'][:-1]
                rating = str(ratings[0]['severity']).upper()
                src_url = str(app['source']['url'])

                with open('sbom_report_' + formatted_datetime + str(generic_page_number) + '.csv', 'a', newline='') as static_file:
                    static_writer = csv.writer(static_file)
                    static_writer.writerow([profile, desc, component, rating, src_url])
                # for idx, comp in enumerate(app['affects']):
                #     print(f" affList {comp['ref']}")
                # print(f"DEP111 {comp[idx]}")
                # for idx, component in enumerate(app['affects']):
                # print(f"DEP {component[idx]}")
                # print(f"DEP {component['vulnerabilities'][index]['affects'][idx]['ref']}")
        except requests.RequestException as re:
            print("SBOM exception " + str(re))


def get_static_findings(guid: str, app_name: str, key_id: str, secret: str):
    print(f"====::::STATIC FINDINGS::::==== with GUID {guid} and app name {app_name}")
    try:
        # response = (requests.get
        #             (api_base + "v2/applications/" + guid + "/findings?scan_type=STATIC",
        #              auth=RequestsAuthPluginVeracodeHMAC
        #              (api_key_id=key_id,
        #               api_key_secret=secret),
        #              headers=headers)) api_base + "v2/applications/" + guid + "/findings?scan_type=STATIC&status=OPEN"
        response = (requests.get
                    (api_base + "/appsec/v2/applications/" + guid + "/findings?scan_type=STATIC&status=UNRESOLVED"
                                                                    "&severity_gte=4",
                     auth=RequestsAuthPluginVeracodeHMAC
                     (api_key_id=key_id,
                      api_key_secret=secret),
                     headers=headers))
    except requests.RequestException as re:
        print("Static scan failed with " + str(re))
        sys.exit(1)

    if response.ok:
        data = response.json()
        # print("aha===")
        # print("use the month of the last seen date to classify the issue under a certain month")
        # print(data)
        try:
            all_findings = data["_embedded"]["findings"]
            num_of_findings = len(all_findings)
            print("Checking " + str(num_of_findings) + " SAST findings(s)")
            # writer.writerow(["Severity", "Scan Type", "Name", "CWE", "Date", "Product"])
            # print(data)
            # (["Severity", "Scan Type", "Name", "CWE", "Date", "Product"])
            # severity, "SAST" ,app_name, cwe, first_found, app_name
            for index in range(len(all_findings)):
                severity = data["_embedded"]["findings"][index]["finding_details"]["severity"]
                status = data["_embedded"]["findings"][index]["finding_status"]["status"]
                if status.upper() == "OPEN" or status.upper() == "UNRESOLVED":
                    # severity_score = severity
                    resolution_status = data["_embedded"]["findings"][index]["finding_status"]["resolution"]
                    first_found = data["_embedded"]["findings"][index]["finding_status"]["first_found_date"]
                    last_seen = data["_embedded"]["findings"][index]["finding_status"]["last_seen_date"]
                    cwe_id = data["_embedded"]["findings"][index]["finding_details"]["cwe"]["id"]
                    cwe = data["_embedded"]["findings"][index]["finding_details"]["cwe"]["name"]
                    severity = data["_embedded"]["findings"][index]["finding_details"]["severity"]
                    if severity == 3:
                        severity_desc = "Medium"
                    elif severity == 4:
                        severity_desc = "High"
                    else:
                        severity_desc = "Critical"

                    with open('sast.csv', 'a', newline='') as static_file:
                        static_writer = csv.writer(static_file)
                        static_writer.writerow([severity_desc, "SAST", cwe, cwe_id, first_found, app_name])
            # severity_score = 0
            # for index in range(len(all_findings)):
            #     severity = data["_embedded"]["findings"][index]["finding_details"]["severity"]
            #     status = data["_embedded"]["findings"][index]["finding_status"]["status"]
            #     while status.upper() == "OPEN":
            #         # severity_score = severity
            #         resolution_status = data["_embedded"]["findings"][index]["finding_status"]["resolution"]
            #         first_found = data["_embedded"]["findings"][index]["finding_status"]["first_found_date"]
            #         last_seen = data["_embedded"]["findings"][index]["finding_status"]["last_seen_date"]
            #         cwe_id = data["_embedded"]["findings"][index]["finding_details"]["cwe"]["id"]
            #         cwe = data["_embedded"]["findings"][index]["finding_details"]["cwe"]["name"]
            #         severity = data["_embedded"]["findings"][index]["finding_details"]["severity"]
            #         findings = (
            #                 "The resolution status of the finding is " + resolution_status +
            #                 ". First found on " + first_found + " and last seen on " + last_seen +
            #                 ". The severity is " + str(severity) + " and the CWE is " + "'" + str(cwe) + "'" +
            #                 ", the CWE_ID is " + str(cwe_id))
            #         print(f"findings is {findings}")
            #         # create_result_file(app_name, guid, findings)
            #         # with open('issues_new_SCA.csv', 'a', newline='') as static_file:
            #         #     static_writer = csv.writer(static_file)
            #         #     static_writer.writerow([app_name, "SAST", "OPEN", findings])
        except Exception as e:
            print("EXCEPTION experienced " + str(e))
            # create_report_file("PASS", str(e) + ":::: There are no findings for GUID " + str(guid), app_name,
            #                    "pipeline_generic_message.txt")
    else:
        print(f"get_findings:::: {response.status_code}")

        print(f"content is {response.content}")


# http --auth-type=veracode_hmac "https://api.veracode.com/appsec/v2/applications/{application_guid}/summary_report"
def get_sca_findings(guid: str, app_name: str, key_id: str, secret: str):
    try:
        response = (requests.get
                    (api_base + "/appsec/v2/applications/" + guid + "/findings?scan_type=SCA&severity_gte=3"
                     + "&mitigated_after=2024-09-30",
                     auth=RequestsAuthPluginVeracodeHMAC
                     (api_key_id=key_id,
                      api_key_secret=secret),
                     headers=headers))
    except requests.RequestException as re:
        print("Static scan failed with " + str(re))
        sys.exit(1)

    if response.ok:
        data = response.json()
        # print(f"raw data is ${data}")
        try:
            all_findings = data["_embedded"]["findings"]
            num_of_findings = len(all_findings)
            print("Checking " + str(num_of_findings) + " SCA findings(s)")

            num_of_findings = len(all_findings)
            print(f"len is {num_of_findings}")
            # print(f"all SCA FINDINGS to be extracted ===== :::: {all_findings}")
            severity_desc = ""
            for index, app in enumerate(all_findings):
                scan_type = app['scan_type']
                res_status = app['finding_status']['resolution']
                # print(f"resolution is {res_status} and the scan_type is {scan_type}")
                # print(f" finding details is {app['finding_details']['severity']}")
                if scan_type == "SCA" and res_status != "RESOLVED":
                    severity = app['finding_details']['severity']
                    cwe_id = app['finding_details']['cwe']['id']
                    cwe_name = app['finding_details']['cwe']['name']
                    lib_name = data['_embedded']['findings'][index]["finding_details"]["component_filename"]
                    lib_ver = data['_embedded']['findings'][index]["finding_details"]["version"]
                    first_found = data["_embedded"]["findings"][index]["finding_status"]["first_found_date"]
                    last_seen = data["_embedded"]["findings"][index]["finding_status"]["last_seen_date"]
                    # print(f"scan type: {scan_type} 'severity: {severity}'  'cwe: {cwe_id}'  'desc: {description}' "
                    #       f"'lib_name: {lib_name}'  'version :{lib_ver}'  ")
                    if severity == 3:
                        severity_desc = "Medium"
                    elif severity == 4:
                        severity_desc = "High"
                    elif severity == 5:
                        severity_desc = "Critical"
                    with open("sca_" + formatted_datetime + "_" + str(generic_page_number) + '.csv', 'a', newline='') as static_file:
                        static_writer = csv.writer(static_file)
                        static_writer.writerow(
                            [severity_desc, "SCA", cwe_name, cwe_id, first_found, last_seen, app_name, lib_name,
                             lib_ver])

            ### beginning of real code
            # for index in range(len(all_findings)):
            #     severity = data["_embedded"]["findings"][index]["finding_details"]["severity"]
            #     status = data["_embedded"]["findings"][index]["finding_status"]["status"]
            #     print(f"status is====::::: {status}")
            #
            #     if status.upper() == "OPEN":
            #         resolution_status = data["_embedded"]["findings"][index]["finding_status"]["resolution"]
            #         print(f"The resolution status is {resolution_status}")
            #         first_found = data["_embedded"]["findings"][index]["finding_status"]["first_found_date"]
            #         last_seen = data["_embedded"]["findings"][index]["finding_status"]["last_seen_date"]
            #         cwe_id = data["_embedded"]["findings"][index]["finding_details"]["cwe"]["id"]
            #         cwe = data["_embedded"]["findings"][index]["finding_details"]["cwe"]["name"]
            #         print(f" CWE is..... {cwe}")
            #         severity = data["_embedded"]["findings"][index]["finding_details"]["severity"]
            #         lib_name = data['_embedded']['findings'][index]["finding_details"]["component_filename"]
            #         lib_ver = data['_embedded']['findings'][index]["finding_details"]["version"]
            #         file_path = data['finding_details']['file_path']
            #         print(f"file_path is {file_path}")
            #         if severity == 3:
            #             severity_desc = "Medium"
            #         elif severity == 4:
            #             severity_desc = "High"
            #         elif severity == 5:
            #             severity_desc = "Critical"
            #         # with open('sca_results.csv', 'a', newline='') as static_file:
            #         #     static_writer = csv.writer(static_file)
            #         #     static_writer.writerow(
            #         #         [severity_desc, "SCA", cwe, cwe_id, first_found, app_name, lib_name, lib_ver])
            ### end of real code




        except Exception as e:
            print("EXCEPTION experienced " + str(e))
            # create_report_file("PASS", str(e) + ":::: There are no findings for GUID " + str(guid), app_name,
            #                  "pipeline_generic_message.txt")
    else:
        print(f"SCA HTTP Error:::: {response.status_code}")


def get_summary_report(guid: str, app_name: str, key_id: str, secret: str):
    try:  # https://api.veracode.com/appsec/v2/applications/
        response = (requests.get
                    (api_base + "/appsec/v2/applications/" + guid + "/summary_report",
                     auth=RequestsAuthPluginVeracodeHMAC
                     (api_key_id=key_id,
                      api_key_secret=secret),
                     headers=headers))
    except requests.RequestException as re:
        print("Static scan failed with " + str(re))
        sys.exit(1)

    if response.ok:
        data = response.json()
        print(data)
        # try:
        #     all_findings = data["_embedded"]["findings"]
        #     num_of_findings = len(all_findings)
        #     print("Checking " + str(num_of_findings) + " findings(s)")
        #     severity_score = 0
        #     for index in range(len(all_findings)):
        #         severity = data["_embedded"]["findings"][index]["finding_details"]["severity"]
        #         status = data["_embedded"]["findings"][index]["finding_status"]["status"]
        #         if status.upper() == "OPEN":
        #             severity_score = severity
        #             resolution_status = data["_embedded"]["findings"][index]["finding_status"]["resolution"]
        #             first_found = data["_embedded"]["findings"][index]["finding_status"]["first_found_date"]
        #             last_seen = data["_embedded"]["findings"][index]["finding_status"]["last_seen_date"]
        #             cwe_id = data["_embedded"]["findings"][index]["finding_details"]["cwe"]["id"]
        #             cwe = data["_embedded"]["findings"][index]["finding_details"]["cwe"]["name"]
        #             severity = data["_embedded"]["findings"][index]["finding_details"]["severity"]
        #             findings = (
        #                     "The resolution status of the finding is " + resolution_status +
        #                     ". First found on " + first_found + " and last seen on " + last_seen +
        #                     ". The severity is " + str(severity) + " and the CWE is " + "'" + str(cwe) + "'" +
        #                     ", the CWE_ID is " + str(cwe_id))
        #             with open('summary_reports_oct.csv', 'a', newline='') as static_file:
        #                 static_writer = csv.writer(static_file)
        #                 static_writer.writerow([app_name, "SAST", "OPEN", findings])
        # except Exception as e:
        #     print("EXCEPTION experienced " + str(e))

        # create_report_file("PASS", str(e) + ":::: There are no findings for GUID " + str(guid), app_name,
        #                    "pipeline_generic_message.txt")
    else:
        print(f"Summary Report:::: {response.status_code}")


# GET THE SANDBOX GUID-- https://api.veracode.com/appsec/v1/applications/{applicationGuid}/sandboxes
def get_sandbox_guid(guid: str, key_id: str, secret: str, app_name: str):
    try:
        tag_response = (requests.get
                        (api_base + "/appsec/v1/applications/" + guid + "/sandboxes",
                         auth=RequestsAuthPluginVeracodeHMAC
                         (api_key_id=key_id,
                          api_key_secret=secret),
                         headers=headers))
        if tag_response.ok:
            data = tag_response.json()
            print("The sandbox GUID is " + str(data["_embedded"]["sandboxes"][0]["guid"]))
            get_sandbox_report(guid, key_id, secret, data["_embedded"]["sandboxes"][0]["guid"], app_name)

        else:
            print(f" Exception is {tag_response}")
    except Exception as ex:
        print(f"Exception is {ex}")


# http --auth-type=veracode_hmac GET "https://api.veracode.com/appsec/v2/applications/{application_guid}/findings?context={sandbox_guid}"
def get_sandbox_report(guid: str, key_id: str, secret: str, sandbox_guid: str, app_name: str):
    print(f"Sandbox report...for sandbox GUID {sandbox_guid}")  #6813238d-7a95-44c3-b47b-035f8a677ea5
    #   ?page=" + str(page_number) + "&size=200",
    try:
        tag_response = (requests.get
                        (api_base + "/appsec/v2/applications/" + guid + "/findings?context=" + sandbox_guid,
                         auth=RequestsAuthPluginVeracodeHMAC
                         (api_key_id=key_id,
                          api_key_secret=secret),
                         headers=headers))
        if tag_response.ok:
            data = tag_response.json()
            all_findings = data["_embedded"]["findings"]
            print(f"sandbox findings {all_findings}")
            num_of_findings = len(all_findings)
            print(f"len is {num_of_findings}")
            severity_desc = ""
            for index, app in enumerate(all_findings):
                scan_type = app['scan_type']
                res_status = app['finding_status']['resolution']
                print(f"resolution is {res_status} and the scan_type is {scan_type}")
                if scan_type == "STATIC" and res_status == "UNRESOLVED":
                    severity = app['finding_details']['severity']
                    cwe_id = app['finding_details']['cwe']['id']
                    cwe_name = app['finding_details']['cwe']['name']
                    file_path = app['finding_details']['file_path']
                    first_found = app["finding_status"]["first_found_date"]
                    last_seen = app["finding_status"]["last_seen_date"]
                    file_line_number = app['finding_details']['file_line_number']
                    print(f"scan type: {scan_type} 'severity: {severity}'  'cwe: {cwe_id}'  'desc: {cwe_name}' "
                          f" 'path: {file_path}' 'last_seen: {last_seen}' ")
                    if severity == 3:
                        severity_desc = "Medium"
                    elif severity == 4:
                        severity_desc = "High"
                    elif severity == 5:
                        severity_desc = "Critical"
                    with open('updated_sast_findings_25_10.csv', 'a', newline='') as static_file:
                        static_writer = csv.writer(static_file)
                        static_writer.writerow(
                            [severity_desc, scan_type, cwe_name, cwe_id, first_found, last_seen, app_name, file_path,
                             file_line_number])

                    # writer.writerow([severity, scan_type, cwe, description, "Date", "Product", file_path])

                # get_static_findings(app["guid"], app["profile"]["name"], header.KEY_ID, header.SECRET)
            #     get_sca_findings(app["guid"], app["profile"]["name"], header.KEY_ID, header.SECRET)
            #
            # get_summary_report(app["guid"], app["profile"]["name"], header.KEY_ID, header.SECRET)
            # get the findings for each app f7a86833-4d6a-4a46-b161-22f0d98e97ad
            # if num_of_findings >= 50 and page_number < 3:
            #     # page_number
            #     page_number += 1
            #     print(f"Page number is {page_number} and num_of_findings is {num_of_findings}")
            #     get_app_by_tag(header.KEY_ID, header.SECRET, page_number)
        else:
            print(tag_response.status_code)
    except Exception as ex:
        print(f"Sandbox Exception is {ex}")


def get_app_details(guid: str, key_id: str, secret: str):
    # http --auth-type=veracode_hmac GET "https://api.veracode.com/appsec/v1/applications?legacy_id={applicationGuid}"
    try:
        tag_response = (requests.get
                        (api_base + "/appsec/v1/applications?legacy=" + str(guid),
                         auth=RequestsAuthPluginVeracodeHMAC
                         (api_key_id=key_id,
                          api_key_secret=secret),
                         headers=headers))
        if tag_response.ok:
            data = tag_response.json()
            print(data)
    except:
        print("get it now")


def get_app_by_tag(key_id: str, secret: str, page_number: int, current_date: str):
    print("Get app by tag")
    # page_number = 1
    # global page_number

    # http --auth-type=veracode_hmac GET "https://api.veracode.com/appsec/v1/applications/?page=0&size=50"
    try:
        tag_response = (requests.get
                        (api_base + "/appsec/v1/applications?page=" + str(page_number) + "&size=100",
                         # (api_base + "v1/applications?tag=" + tag,
                         auth=RequestsAuthPluginVeracodeHMAC
                         (api_key_id=key_id,
                          api_key_secret=secret),
                         headers=headers))
        if tag_response.ok:
            data = tag_response.json()
            # print(data)
            all_findings = data["_embedded"]["applications"]
            # print(f"findings are :::::: {all_findings} ")
            num_of_findings = len(all_findings)
            print(f"len is {num_of_findings}")

            for index, appx in enumerate(data["_embedded"]["applications"]):
                print("The profile name is " + appx["profile"]["name"] + " with GUID: " + appx["guid"])

                # get_app_details(appx["guid"], header.KEY_ID, header.SECRET)
                # get_static_findings(app["guid"], app["profile"]["name"], header.KEY_ID, header.SECRET)
                # get_sca_findings(appx["guid"], appx["profile"]["name"], header.KEY_ID, header.SECRET)

                get_sbom_report(appx["guid"], appx["profile"]["name"], header.KEY_ID, header.SECRET,current_date)
                # get_sandbox_guid(appx["guid"], header.KEY_ID, header.SECRET, appx["profile"]["name"],)
                # get_summary_report(appx["guid"], appx["profile"]["name"], header.KEY_ID, header.SECRET)
            # get the findings for each app f7a86833-4d6a-4a46-b161-22f0d98e97ad
        #     if num_of_findings >= 50 and page_number < 3:
        #         # page_number
        #         page_number += 1
        #         print(f"Page number is {page_number} and num_of_findings is {num_of_findings}")
        #         get_app_by_tag(header.KEY_ID, header.SECRET, page_number)
        # else:
        #     print(tag_response.status_code)
    except requests.RequestException as re:
        print("Static scan failed with " + str(re))
        sys.exit(1)

if __name__ == "__main__":
    try:
        current_datetime = datetime.now()
        formatted_datetime = current_datetime.strftime('%d_%m_%Y_%H_%M_%S')
        #with open('sbom_report_' + formatted_datetime + '_' + str(generic_page_number) + '.csv', 'a', newline='') as file:
        #     writer = csv.writer(file)
        #     writer.writerow(["Profile", "Description", "Component", "Severity"])
        get_sbom_report(header.KEY_ID, header.SECRET, generic_page_number, formatted_datetime)
        # get_sbom_report2("f7a86833-4d6a-4a46-b161-22f0d98e97ad", "helloApp", header.KEY_ID, header.SECRET, formatted_datetime)
        # 6813238d-7a95-44c3-b47b-035f8a677ea5
        # get_sandbox_report("5c732cd9-b46c-4966-a41a-2f164b6a9c45", header.KEY_ID, header.SECRET,
        #        "6813238d-7a95-44c3-b47b-035f8a677ea5")
        #get_app_details("18050b64-fe19-4e75-8509-860d49dca9c4", header.KEY_ID, header.SECRET)

        # http --auth-type=veracode_hmac GET "https://api.veracode.com/appsec/v1/applications?tag={tag}" response =
        # requests.get(api_base + "/applications/{applicationGuid}/sandboxes", response = requests.get(api_base +
        # "/applications?tag=" + tag, # response = requests.get(api_base +
        # "/applications?policy_compliance_checked_after=2024-08-11T08:23:59.000Z",
        # auth=RequestsAuthPluginVeracodeHMAC(api_key_id=header.KEY_ID, api_key_secret=header.SECRET), headers=headers)
        # with open('findings_results.csv', 'w', newline='') as file:
        #     writer = csv.writer(file)
        #     writer.writerow(["Severity", "Scan Type", "Name", "CWE", "Date", "Product", "Component", "Version"])
        #

        #
        # with open('updated_sast_results.csv', 'w', newline='') as sast_file:
        #     writer = csv.writer(sast_file)
        #     writer.writerow(["Severity", "Scan Type", "Name", "CWE", "First Date", "Last Date", "Product", "File Name"])
    except requests.RequestException as e:
        print("Whoops!")
        print(e)
        sys.exit(1)

# if response.ok:
#     data = response.json()
#     # print(data)
#     all_findings = data["_embedded"]["applications"]
#     num_of_findings = len(all_findings)
#     print(f"len is {num_of_findings}")
#     for app in data["_embedded"]["applications"]:
#         print(app["profile"]["name"])
#         # print(app["guid"])
#         # Fetch findings for GUID
#         # print(f"Fetching findings for GUID "+app["guid"] + " & appName "+app["profile"]["name"])
#         # get_static_findings(app["guid"], app["profile"]["name"], header.KEY_ID, header.SECRET)
#         get_sca_findings(app["guid"], header.KEY_ID, header.SECRET)
#         # get the findings for each app f7a86833-4d6a-4a46-b161-22f0d98e97ad
# else:
#     print(response.status_code)
        # print(f"====::::STATIC FINDINGS::::==== with GUID {guid} and app name {app_name}")
        # / appsec / v2 / applications / {app_guid} / findings / {issue_id} / static_flaw_info