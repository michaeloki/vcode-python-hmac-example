#!/bin/bash
#json='{"name":["M"],"sch":["HVU"],"city": ["London"]}'
summary=" All good "
scanType="scan1"
mesg="The internal dependency stage failed"
if [ -f "cities3.json" ]; then
  content=$(cat cities3.json)
  #content=$(cat cities3.json)
  json=$(echo $content | jq '.summary += ["Not done"]')
  json=$(echo $content | jq '.scanType += ["testing"]')
  json=$(echo $content | jq '.message += ["Dep tested"]')
  echo "$json" > cities3.json
  cat cities3.json
else
  json_object=$(echo '{}' | jq '. + {"status": "FAIL", "summary":["'"$summary"'"], "appName": "", "scanType": ["'"$scanType"'"],"message": ["'"$mesg"'"] }')
  echo "$json_object" > cities3.json
fi
#json=$(echo "$content" | jq '.summary += . + ".'"$msg1"'."' )

#json=$(echo $content | jq '.name += ["Pap"]')
#json=$(echo $content | jq '.sch += ["LCU"]')
#json=$(echo $content | jq '.city += ["London"]')
#
#echo "$json" > cities2.json
#
#cat cities2.json