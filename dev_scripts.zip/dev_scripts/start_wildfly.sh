#!/bin/bash
# enter your wildfly bin directory
cd /Users/michaeloki/wildfly-20.0.1.Final/bin || exit
./standalone.sh
./jboss-cli.sh --connect
