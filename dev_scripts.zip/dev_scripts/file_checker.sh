#!/bin/bash
echo "File checker...."
# && grep -qx "FAIL" "pipeline_stage_tracker.txt"
#    if [[ $msg == *"Unable to determine project type"* ]]; then
#      msg="Unable to determine project type"
#    fi

#
#if grep -Fxq "$FILENAME" my_list.txt
#then
#    # code if found
#else
#    # code if not found
#fi

#if [ -f "pipeline_stage_tracker.txt" ] && grep -q "FAIL" "pipeline_stage_tracker.txt"; then
#  echo "The file contains the specified string.17"
#else
#  echo "The file does not contain the specified string.19"
#fi

#if [ -f "pipeline_stage_tracker.txt" ] && grep -q "FAIL" "pipeline_stage_tracker.txt"; then SEC_EVALUATION_RESULT="$(cat pipeline_stage_tracker.txt)"; echo "$SEC_EVALUATION_RESULT"; exit 0; fi

# if [ -f "evaluation_output.txt" ] && grep -q "FAIL" "evaluation_output.txt"; then SEC_EVALUATION_RESULT="$(cat verdict.txt)" && echo $SEC_EVALUATION_RESULT; fi
#if [ -f "pipeline_stage_tracker.txt" ] &&  grep -Fxq "FAIL" "pipeline_stage_tracker.txt"; then
#  echo ".... YES ...."
#  SEC_EVALUATION_RESULT="$(cat pipeline_stage_tracker.txt)"
#  echo "$SEC_EVALUATION_RESULT"
#  exit 0
#fi
#filename=$(ls -la | grep -i "mic")
#filename=$(ls -la | grep "mic.txt")
#if [ "$(ls -la | grep "pipeline_stage_tracker.txt")" ] && grep -q "FAIL" "pipeline_stage_tracker.txt"; then echo "$(cat pipeline_stage_tracker.txt)" && ./cleanup.sh && exit 0; fi
#if [ "$(ls -la | grep "pipeline_stage_tracker.txt")" ]; then echo "good"; fi
#filename=$(ls -la | grep "pipeline_stage_tracker.txt")
#
#echo "file is $filename"
yes=$(jq '.[] | select(.name == "ios/hahahapp[gl23]") | .id' input.json)
echo "$yes"
