#!/bin/bash
# --source header_test.sh
#
#generic_feedback "This app is " "bank-contact"
#


#unzip deployments/pipeline_socket_integration.zip
#
#sh local_socket_dockerise.sh
#sh local_api_dockerise.sh

echo "hey"

#if [  -f "dynamic_file.txt" ] && [  -f "pipeline_stage_tracker.txt" ] ; then echo "app name not found"  && SEC_EVALUATION_RESULT="$(cat evaluation_output.txt)"; echo "$SEC_EVALUATION_RESULT"  > artifact2.txt; echo "$SEC_EVALUATION_RESULT"; fi
#if [ -f "verdict.txt" ]; then SEC_EVALUATION_RESULT="$(cat verdict.txt)"; echo "$SEC_EVALUATION_RESULT" > artifact.txt; echo "$SEC_EVALUATION_RESULT"; fi
# if [ -f "evaluation_output.txt" ] && grep -q "FAIL" "evaluation_output.txt"; then SEC_EVALUATION_RESULT="$(cat verdict.txt)"; echo "$SEC_EVALUATION_RESULT" > artifact.txt; echo "$SEC_EVALUATION_RESULT"; fi


#BUILD_STATUS="failed"
#
#if [ ${BUILD_STATUS} == "failed" ] ; then echo "{'status':'FAIL', 'summary':'Unsuccessful build'}" > artifact2024.txt; exit 1; fi

#cat artifact2024.txt
#echo "build content is $(cat artifact2024.txt)"
#result=$(echo '{"status":"FAIL", "summary":"Unsuccessful build"}')
#if [ -f "aaa.txt" ] && $(cat aaa.txt) != "Build completed" ; then echo "$result" > bbb.txt; exit 1; fi

# result=$(jq -n '{status: "FAIL", summary: "The build stage failed in the SEC pipeline"}')
# if [ -f "aaa.txt" ] && [ "$(cat aaa.txt)" != "Build completed" ]; then echo "hi2" > bbb.txt; exit 1; fi


# echo "{'status':'FAIL', 'summary':'The build stage failed'}" > artifact202611.txt

# exit 1
#key_id="hello"
#secret=""
#
#function report_runner {
#  if [[ -z $key_id || -z $secret ]]; then
#    echo "Required parameters are missing"
#  else
#    echo "Run py"
#    # python3 monthly_report.py --arg1 "$key_id" --arg2 "$secret"
#  fi
#}
#
#report_runner


if [ ! -f "michael.docx" ]; then chmod +x ./image_scan.sh && ./image_scan.sh; fi
# Get Python details python3 -c "import sys; print(sys.path)"
#
#if [ "$(cat artifact2024.txt)" = "Build completed" ] ; then echo "{'status':'FAIL', 'summary':'Unsuccessful build'}" > aaa.txt; exit 1; fi