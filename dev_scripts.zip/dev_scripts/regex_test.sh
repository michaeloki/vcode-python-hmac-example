#!/bin/bash

#appnsfame="consumer/vas-account-bpc-integration-service[gl1776]"

#appname="consumer/vas-account-bpc-integration-service[gl1776]"
#value=$(echo $appname | grep -Eo "\[([^][]*)]")
#
#echo "$value"


#
## Get the timestamp of June 1, 2024
#june_1_2024_timestamp=$(date -j -f "%Y %m %d" "2024 06 01" "+%s")
#
## Print the timestamp
#echo "$june_1_2024_timestamp"
#
## Get the timestamp of June 7, 2024
#june_7_2024_timestamp=$(date -j -f "%Y %m %d" "2024 06 07" "+%s")
#
## Print the timestamp
#echo "$june_7_2024_timestamp"
#
#
#echo $(( ( $(date -d @$june_7_2024_timestamp) - $(date -d @$june_1_2024_timestamp) ) / 86400 ))
#
#echo "days difference from June 1 $june_7_2024_timestamp-$june_1_2024_timestamp"

#echo "MVN status is $(hash mvn 2>/dev/null)"
if hash mvn 2>/dev/null; then
  echo "Maven is installed"
else
  echo "Maven is not installed"
fi

if java -version &> /dev/null; then
  echo "JDK is installed"
else
  echo "JDK is not installed"
fi
CALLING_CI_COMMIT_SHA="1371371737skdbwvubf4ew722aass"
echo "file name is $CALLING_CI_COMMIT_SHA".txt
fnnn=$CALLING_CI_COMMIT_SHA+".txt"
if [ -z $fnnn ]; then ./vc_dd_import_scan_ci.sh; fi
#
        if [ -f "evaluation_output.txt" ] && grep -qx "PASS" "evaluation_output.txt"; then
          rm -f "evaluation_output.txt";
        fi


echo "PWD is $(pwd)";
#if [ -f "verdict.txt" ]; then
#  echo "file exists"
#  app_name=$(< verdict.txt)
#  echo "app name is $app_name"
#fi
#EVALUATION_REPORT="boy"
#if [ -f "verdict.txt" ]; then
#  echo "$(cat verdict.txt)" && echo "$(cat verdict.txt)" >> $EVALUATION_REPORT &&
#  echo " SEE EVALUATION_REPORT is $EVALUATION_REPORT"
#  echo "$(cat verdict.txt)"
#fi

#python3 -m pip list | grep -i requests

#scan_output=" Action "UploadAndScan"  "
#if [[ "$scan_output" == *"UploadAndScan"* ]]; then
#  echo "The result will be evaluated in stage 5"
#  exit 0
#fi

#if [ -f "verdict.txt" ]; then
#  echo "verdict file was found...."
#  SEC_EVALUATION_RESULT="$(cat verdict.txt)"
#  echo "SEC_EVALUATION_RESULT is $SEC_EVALUATION_RESULT"
#  rm "verdict.txt";
#fi
#
#if [ -f "evaluation_output.txt" ] && grep -qx "FAIL" "evaluation_output.txt"; then
#  echo "FAIL";
#rm "evaluation_output.txt";
#fi
source generic_message.sh

# stop_feedback "Failed to read" "phase22 stage"


msg1="Failed in stage A"
msg2="Failed in stage B"

if [ -f "evaluation.txt" ]; then
  content=$(cat evaluation.txt)
  #modified_content=$(echo "$content" | jq '.summary |= . + '."$msg1".' ')
  # Get the scan type key value and append the new string to the old one
  scanType=$(jq '.scanType' "evaluation.txt")
  echo "=== scantype is $scanType"

  #json='{"key": [1, 2, 3, 4, 5]}'
#  array=($(echo ${scanType} | jq -r '.scanType[]'))
#  echo "${array[@]}"



# New summary value and new scanType


# Use jq to update the JSON
#json=$(echo $json | jq '.summary = "'$new_summary'"')
#json=$(echo $json | jq '.scanType += ['\"$new_scan_type\"']')
#
## Print the updated JSON
#echo $json

#json='{"key": ["a", "b", "c", "d", "e"]}'
#array=($(echo ${json} | jq -r '.key[]'))
#echo ${array[@]}

modified_content=$(echo "$content" | jq '.summary += . + ".'"$msg1"'."' )
modified_content=$(echo "$content" | jq '.scanType += ['\""$msg2"\"']' )
#modified_content=$(echo "$content" | jq '.summary |= . + ".'"$msg1"'." | .scanType |= . + ".'"$scanType"'."' )
#echo $modified_content
echo "$modified_content" > evaluation.txt
echo "The modified content of the evaluation.txt file is $modified_content"
else
  json_object=$(echo '{}' | jq '. + {"status": "FAIL", "summary":"'"$msg1"'", "appName": "", "scanType": ["internal_dep_scan"],
"message": "The internal dependency stage failed"}')
  echo "$json_object" > evaluation.txt
  echo "No project namespace, a $json_object was successfully saved in $(pwd)"
fi




#file_to_delete="/path/to/your/file"
#if [ -f "$file_to_delete" ]; then
#    rm "$file_to_delete"
#    echo "File $file_to_delete deleted."
#else
#    echo "File $file_to_delete not found."
#fi


   day=$(date "+%d")
   month=$(date "+%m")
   year=$(date "+%Y")
   start_timestamp=$(date -j -f "%m/%d/%Y" "$month"/"$day"/"$year" +%s)
   end_timestamp=$(date -j -f "%m/%d/%Y" 09/30/2024 +%s)
   diff_seconds=$((end_timestamp - start_timestamp))
   diff_days=$((diff_seconds / 60 / 60 / 24))

#   if [ $diff_days -gt 0 ]; then
#     echo "Before 30th Sept 30 2024"
#   else
#       echo "After 29th Sept 2024"
#   fi

   echo "checking diff_days is $diff_days"
   if [ $diff_days -lt 1 ]; then
     echo "After 29th Sept 2024"
   else
      echo "Before 30th Sept 30 2024"
   fi
#
##!/bin/bash

## Get the current date
#date=$(date "+%Y-%m-%d")
#
## Calculate the difference between the current date and September 30, 2024
#diff=$(date -d "$date" --date="2024-09-30" +%d)
#
## Print "hello" if the current date is before September 30, 2024
#if [ $diff -lt 1 ]; then
#  echo "hello"
#else
#  echo "hi"
#fi


# Calculate the number of days between the two dates
#string_length=${#value}
#last_index=$((string_length - 2))
#strrr=${value:1:last_index}
#
#echo "content is $strrr"
#    pip3_check=$(which pip3)
#    echo "pip3 is at $pip3_check"
#    if [ -z "$pip3_check" ]; then sudo apt install python3-pip; else echo "pip3 already exists"; fi
#if [ -f "$value.txt" ]; then
#        if [ "$(cat dynamic_file.txt)" = "FAIL" ]; then
#          echo "Severe vulnerabilities were found will block this pipeline in Q3"
#        fi
#        else
#          echo "No severe vulnerabilities were found"
#fi





#!/bin/bash

WATCH_DIR="/home/ec2-user/deployments"
file_timestamps=()

inotifywait -mr --timefmt '%d/%m/%y %H:%M:%S'  --format '%w%f' "$WATCH_DIR" -e modify,close_write,move | while read pathname;
do
 if [[ "$pathname" =~ \.zip$ ]]; then
    timestamp=$(stat -c '%Y' "$pathname")
    file_index=$(echo "$pathname" | sed 's/\//_/g')

    if [[ "${file_timestamps[$file_index]}" ]]; then
       if (( timestamp < ${file_timestamps[$file_index]} )); then
          echo "Possible file overwrite detected: $pathname"
          sh /home/ec2-user/prod_deploy.sh
       fi
    fi
    file_timestamps[$file_index]=$timestamp
 fi
done


report_runner() {
  if [ -z "$key_id" ] || [ -z "$secret" ]; then
    echo "The required parameters are missing"
  else
    pip install -r requirements.txt -q
    python3 monthly_report.py --arg1 "$key_id" --arg2 "$secret"
  fi
}

report_runner
