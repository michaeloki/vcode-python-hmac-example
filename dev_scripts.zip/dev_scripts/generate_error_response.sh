#!/bin/bash
#status_text="FAIL"
#summary_text=$1
#app_name="unknown project"
#filename="pipeline_generic_message.txt"
#python3 file_generator.py --arg1 "$status_text" --arg2 "$summary_text" --arg3 "$app_name" --arg4 "$filename"

#!/bin/bash
input_file="pipeline_stage_trackee.txt"

#function stop_feedback() {
#  msg=$1
#  scanTypeMsg=$2
#  echo "$msg"
#  if [ -f $input_file ]; then
#    content=$(cat $input_file)
#    modified_content=$(echo "$content" | jq '.scanType += ['\""$scanTypeMsg"\"']' )
#    echo "$modified_content" > $input_file
#    echo "The modified content of the $input_file file is $modified_content"
#  else
#    json_object=$(echo '{}' | jq '. + {"status": "FAIL", "summary":"'"$msg"'", "appName": "", "scanType": ["internal_dep_scan"], "message": "The internal dependency stage failed"}')
#    echo "$json_object" > $input_file
#    echo "$json_object was successfully saved in $(pwd)"
#  fi
#  exit 1
#}



#!/bin/bash
input_file="pipeline_stage_trackex.txt"

function stop_feedback() {
  msg=$1
  scanTypeMsg=$2
  echo "$msg"
  if [ -f $input_file ]; then
    content=$(cat $input_file)
    modified_content=$(echo "$content" | jq '.scanType += ['\""$scanTypeMsg"\"']' )
    echo "$modified_content" > $input_file
    echo "The modified content of the $input_file file is $modified_content"
  else
    if [[ $msg == *"Unable to scan and generate report"* ]]; then
      msg="Unable to scan and generate report"
    fi
   # clean_string=$(echo "$msg" | tr -cd '[:alnum:][:space:]')
    # clean_string=$(echo $msg | head -c 100)
    #json_object=$(echo '{}' | jq --null-input --argjson clean_string "$(echo $clean_string | tr -d '[:alnum:][:space:]"')" '. + {"status": "FAIL", "summary": $clean_string, "appName": "", "scanType": ["sample"], "message": "sth hapn"}')
    #json_string=$(echo "{}" | jq --null-input --argjson msg "$json_string_with_special_chars" '. + $msg')
    #message="$msg"
    json_object=$(echo '{}' | jq --argjson msg "$(echo $msg | jq -R .)" '. + {"status": "FAIL", "summary": $msg, "appName": "", "scanType": ["sample"], "message": "The internal dependency stage failed"}')
    #
    # json_object=$(echo '{}' | jq --null-input --argjson clean_string "$(echo $clean_string | jq -Rr .)" '. + {"status": "FAIL", "summary": $clean_string, "appName": "", "scanType": ["sample"], "message": "The internal dependency stage failed"}')
    # json_object=$(echo '{}' | jq --argjson msg "$(jq -n "$msg")" '. + {"status": "FAIL", "summary": $msg, "appName": "", "scanType": ["sample"], "message": "The internal dependency stage failed"}')
    # json_object=$(echo '{}' | jq '. + {"status": "FAIL", "summary":"'"$msg"'", "appName": "", "scanType": ["internal_dep_scan"], "message": "The internal dependency stage failed"}')
    echo "$json_object" > $input_file
    echo "$json_object was successfully saved in $(pwd)"
  fi
  exit 1
}


#
# SCRIPTERROR: Unable to determine project type. No target/*.jar or package.json found, or CALLING_SCAN_IOS_BCA/CALLING_SCAN_ANDR_APK defined