#!/bin/bash
# Replace with your project ID and upstream pipeline ID
project_id=643
upstream_pipeline_id=442061
# Get downstream pipelines triggered by the upstream pipeline
#
#curl --silent -X POST -g \
#          --header "PRIVATE-TOKEN: $GL_SECURITY_PAT" \
#
#downstream_pipelines=$(curl -F  token=HomzY_GzQuGd4GWQaxNy \ "https://gitlab.com/api/v4/projects/$project_id/pipelines?triggered_by=$upstream_pipeline_id" | jq '.')
## downstream_pipelines=$(curl --header "Private-Token: <your_access_token>" --silent "https://gitlab.com/api/v4/projects/$project_id/pipelines?triggered_by=$upstream_pipeline_id" | jq -r '.[] | .id')
## Iterate over downstream pipelines
#echo $downstream_downstream_pipelines
#for pipeline_id in $downstream_pipelines
#do
#  # Get commits for the downstream pipeline
#  commits=$(curl --silent "https://gitlab.com/api/v4/projects/$project_id/pipelines/$pipeline_id/commits" | jq -r '[.[] | .id] | .[]'])
#  # Check if any commit in the downstream pipeline matches the upstream pipeline's commit SHA
#  for commit in $commits
#  do
#    if [ "$commit" = "upstream_commit_sha" ]; then
#      echo "Downstream pipeline ID: $pipeline_id"
#      break 2
#    fi
#  done
#done
function stage_check {
  echo "==== Checking previous stages in $(pwd)===="
  if [ -f pipeline_stage_tracker.txt ] &&  grep -q "FAIL" "pipeline_stage_tracker.txt"; then
  # if [ "$(ls -la | grep "pipeline_stage_tracker.txt")" ] && grep -q "FAIL" "pipeline_stage_tracker.txt"; then
    echo "$(cat pipeline_stage_tracker.txt)"
    chmod +x ./cleanup.sh
    ./cleanup.sh
    exit 0
  else
    echo "SC-FNF"
  fi
}
stage_check
