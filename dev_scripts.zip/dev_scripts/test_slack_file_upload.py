import unittest
import unittest.mock as mock
from unittest.mock import patch
import argparse

from slack_sdk import WebClient
from slack_file_upload import upload_file_to_slack  # Replace 'your_module' with the actual module name


class TestUploadSlack(unittest.TestCase):

    @patch('slack_sdk.WebClient.files_upload_v2')
    @patch('slack_sdk.WebClient.auth_test')
    def test_upload_slack_client_init(self, mock_auth_test, mock_files_upload_v2):
        mock_auth_test.return_value = {'ok': True, 'access_token': 'xoxb-1234567890-1234567890-1234567890'}
        channel_id = 'C0123456'
        filename = 'example.txt'
        slack_bot_token = 'xoxb-1234567890-1234567890-1234567890'
        title = 'Example File'

        upload_file_to_slack(channel_id, filename, slack_bot_token, title)

        mock_files_upload_v2.assert_called_once_with(
            channel=channel_id,
            title=title,
            file=filename,
            initial_comment='File created'
        )



# class TestUploadSlack(unittest.TestCase):
#
#
#     @patch('slack_sdk.WebClient.files_upload_v2')
#     def test_upload_slack(self, mock_files_upload_v2):
#         channel_id = 'C0123456'
#         filename = 'example.txt'
#         slack_bot_token = 'xoxb-1234567890-1234567890-1234567890'
#         title = 'Example File'
#
#         upload_file_to_slack(channel_id, filename, slack_bot_token, title)
#
#         mock_files_upload_v2.assert_called_once_with(
#             channel=channel_id,
#             title=title,
#             file=filename,
#             initial_comment='File created'
#         )


    # @patch('argparse.ArgumentParser')
    # def test_upload_slack_argparse_init(self, mock_parser):
    #     channel_id = 'C0123456'
    #     filename = 'example.txt'
    #     slack_bot_token = 'xoxb-1234567890-1234567890-1234567890'
    #     title = 'Example File'
    #
    #     with mock.patch.object(argparse, 'parse_args') as mock_parse_args:
    #         mock_parse_args.return_value = mock.Mock(arg1=channel_id, arg2=filename, arg3=slack_bot_token, arg4=title)
    #
    #     upload_file_to_slack('arg1', 'arg2', 'arg3', 'arg4')
    #
    #     mock_parser.assert_called_once_with()
    #     mock_parse_args.assert_called_once_with()

    # @patch('argparse.ArgumentParser.parse_args')
    # def test_upload_slack_argparse_init(self, mock_parse_args):
    #     mock_parse_args.return_value = mock.Mock(arg1='arg1', arg2='arg2', arg3='arg3', arg4='arg4')
    #     channel_id = 'C0123456'
    #     filename = 'example.txt'
    #     slack_bot_token = 'xoxb-1234567890-1234567890-1234567890'
    #     title = 'Example File'
    #
    #     upload_file_to_slack(channel_id, filename, slack_bot_token, title)
    #
    #     mock_parse_args.assert_called_once_with()

    # @patch('argparse.ArgumentParser.parse_args')
    # def test_upload_slack_argparse_init(self, mock_parse_args):
    #     mock_parse_args.return_value = mock.Mock(arg1='arg1', arg2='arg2', arg3='arg3', arg4='arg4')
    #     channel_id = 'C0123456'
    #     filename = 'example.txt'
    #     slack_bot_token = 'xoxb-1234567890-1234567890-1234567890'
    #     title = 'Example File'
    #
    #     upload_file_to_slack(channel_id, filename, slack_bot_token, title)
    #
    #     mock_parse_args.assert_called_once_with()

    @patch('slack_sdk.WebClient.files_upload_v2')
    def test_upload_slack_argparse_init(self, mock_files_upload_v2):
        mock_files_upload_v2.return_value = {'ok': True, 'file': {'id': 'file_id'}}

        channel_id = 'C0123456'
        filename = 'example.txt'
        slack_bot_token = 'xoxb-1234567890-1234567890-1234567890'
        title = 'Example File'

        upload_file_to_slack(channel_id, filename, slack_bot_token, title)

        mock_files_upload_v2.assert_called_once_with(
            channel=channel_id,
            title=title,
            file=filename,
            initial_comment='File created'
        )

if __name__ == '__main__':
    unittest.main()
