var_comp = "Vulnerable Component: Logback Classic Module:1.2.12"
#
# print(f" {var_comp}")

print(var_comp[22:])

version_number = var_comp[22:].split(":")

print(f"version number is {version_number[1]}")
# first_string = "logback-classic"
# second_string = "logback classic module"
#
# if "logback" in second_string and "classic" in second_string:
#     print("The strings 'logback' and 'classic' are both part of 'logback classic module'")
# else:
#     print("The strings 'logback' and 'classic' are not both part of 'logback classic module'")
#
#
# first_string = "logback-classic"
# split_string = first_string.split("-")
# print(split_string[0])

comp_name_ver = "3.10.0.jar,"
local_ver = "3.10.0"
if local_ver in comp_name_ver:
    print("hi")
else:
    print("nee")

