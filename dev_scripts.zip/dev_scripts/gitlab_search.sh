#!/bin/bash

# === Configuration ===
GITLAB_HOST="https://gitlab.payconiq.io"  # Change if using self-hosted GitLab
ACCESS_TOKEN=""  # Replace with your GitLab token
TARGET_REPO="consumer/wiremock-server"  # Supplied repo name to search
#TARGET_REPO="consumer/wiremock-server"  # Supplied repo name to search
#TARGET_REPO="$1"  # Supplied repo name to search

#if [ -z "$TARGET_REPO" ]; then
#  echo "Please provide a repository name to search for."
#  echo "Usage: $0 <repo-name>"
#  exit 1
#fi

# === Search for matching projects ===
echo "Searching for projects matching: $TARGET_REPO"

RESPONSE=$(curl -s --header "PRIVATE-TOKEN: $ACCESS_TOKEN" \
  "$GITLAB_HOST/api/v4/search?scope=projects&search=$TARGET_REPO")
#
# echo "RESPONSE is $RESPONSE"
MATCH_COUNT=$(echo "$RESPONSE" | jq length)
echo "COUNT IS $MATCH_COUNT"
#
if [ "$MATCH_COUNT" -eq 0 ]; then
  echo "No matching repositories found."
  exit 1
fi

# === Pick the best match (first result) ===
BEST_MATCH_NAME=$(echo "$RESPONSE" | jq -r ".[0].name")
BEST_MATCH_URL=$(echo "$RESPONSE" | jq -r ".[0].ssh_url_to_repo")
#
echo "Found match: $BEST_MATCH_NAME"
echo "Cloning from: $BEST_MATCH_URL"
git clone "$BEST_MATCH_URL"
