#!/bin/bash
source common_response.sh

stop_feedback "Generic message 5" "scanType stage 5"