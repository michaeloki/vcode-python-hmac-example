#!/bin/bash

# Check if Maven is already installed
if [ -d "/usr/local/maven" ]; then
  echo "Maven is already installed. Skipping installation."
fi

# Download Maven
wget -q -O /tmp/maven.tar.gz https://dl.bintray.com/maven/maven-3.6.0-binaries/apache-maven-3.6.0-binaries.tar.gz

sudo mkdir /usr/local/maven
# Extract Maven
tar -xvf /tmp/maven.tar.gz -C /usr/local/maven

# Make Maven executable
chmod +x /usr/local/maven/bin/mvn

# Add Maven to system's PATH
echo "export PATH=$PATH:/usr/local/maven/bin" >> /etc/profile.d/maven.sh

# Reload system's PATH
source /etc/profile.d/maven.sh

# Verify Maven installation
echo "Maven installation successful!"
mvn --version

project_dir=$1

detect_project_type() {
  # Check for Java project
  if [ -d "$1/src/main/java" ] && [ -d "$1/src/main/resources" ]; then
    if [ -f "$1/pom.xml" ]; then
      echo "Maven"
      cd "$1" || exit
      mvn --version
      mvn jar:jar
    elif [ -f "$1/build.gradle" ]; then
      echo "Gradle"
    fi
    return
  fi

  # Check for Node.js project
  if [ -d "$1/src" ] && [ -f "$1/package.json" ]; then
    echo "Node.js"
    return
  fi

  # Check for Android project
  if [ -d "$1/src/main" ] && [ -d "$1/src/test" ] && [ -f "$1/AndroidManifest.xml" ]; then
    echo "Android"
    return
  fi

  # Check for iOS project
  if [ -d "$1/Classes" ] && [ -d "$1/Resources" ] && [ -f "$1/Info.plist" ]; then
    echo "iOS"
    return
  fi

  # If none of the above conditions match, assume it's not a project
  echo "Unknown"
}

# Call the function with the project directory as an argument
detect_project_type "$project_dir"