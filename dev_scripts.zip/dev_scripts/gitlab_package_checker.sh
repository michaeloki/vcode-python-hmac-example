#!/bin/bash

# Set your GitLab API token and the programming language you're interested in
API_TOKEN="YOUR_GITLAB_API_TOKEN"
LANGUAGE="TypeScript"

# Set the package you're searching for
PACKAGE="numpy"

# Set the maximum number of projects to check
MAX_PROJECTS=100

# Set the GitLab API endpoint
ENDPOINT="https://gitlab.com/api/v4"

# Get a list of projects that use the programming language
response=$(curl -s -H "Authorization: Bearer $API_TOKEN" "$ENDPOINT/projects?per_page=$MAX_PROJECTS&sort=created_at&order=asc&search=$LANGUAGE")

# Check if the package exists in each project
for project in $(echo "$response" | jq -r '.[] | .id'); do
  # Get the project's repository
  response=$(curl -s -H "Authorization: Bearer $API_TOKEN" "$ENDPOINT/projects/$project/repository/tree?per_page=100&ref=main")

  # Check if the package exists in the project's repository
  if echo "$response" | jq -r '.[] | select(.name == "'$PACKAGE'") | .name' &> /dev/null; then
    echo "The package $PACKAGE exists in project $project"
  fi
done