# Read the Excel file by checking the first line.
# Get the application profile and send a request to the Veracode API
# Check the resolution status and do the comparison between the output and the Excel sheet file value
# Insert the new result in the cell.
import csv

import pandas as pd
import sys
import requests
from pandas import read_excel

# import filemagic

if __name__ == "__main__":
    try:

        my_sheet = 'Monet'  # change it to your sheet name, you can find your sheet name at the bottom left of your excel file
        file_name = 'SCAJanFeb2024.xlsx'  # change it to the name of your excel file
        df = read_excel(file_name, sheet_name=my_sheet)
        # print(df.head())  # shows headers with top 5 rows
        # app_profile_name = df[list(df.keys())[8]]
        # print(f"...  {app_profile_name}")
        for value in df.values:
            print(value[8])
        # get_app_by_tag(header.KEY_ID, header.SECRET, 0)
        # 6813238d-7a95-44c3-b47b-035f8a677ea5
        # get_sandbox_report("5c732cd9-b46c-4966-a41a-2f164b6a9c45", header.KEY_ID, header.SECRET,
        #        "6813238d-7a95-44c3-b47b-035f8a677ea5")

        # http --auth-type=veracode_hmac GET "https://api.veracode.com/appsec/v1/applications?tag={tag}" response =
        # requests.get(api_base + "/applications/{applicationGuid}/sandboxes", response = requests.get(api_base +
        # "/applications?tag=" + tag, # response = requests.get(api_base +
        # "/applications?policy_compliance_checked_after=2024-08-11T08:23:59.000Z",
        # auth=RequestsAuthPluginVeracodeHMAC(api_key_id=header.KEY_ID, api_key_secret=header.SECRET), headers=headers)
        #with open('JanFeb2024_Extract.xlsx', 'w', newline='') as file:

            # try:
                # Load spreadsheet
                # xl = pd.ExcelFile('JanFeb2024_Extract.xlsx')

                # df = pd.read_excel("JanFeb2024_Extract.xlsx", engine='xlrd')

                # Load the entire workbook into a DataFrame
                # df = xl.parse(sheet_name=None)

                # Access the ninth column (0-indexed)
                # app_profile_name = df[list(df.keys())[8]]
                #
                # # Print the content
                # print(app_profile_name)
                # fix_status = ""
                # print("Send this to the Veracode API...and fetch the status of the profile")
                #
                # veracode_status = ""
                # print(f"The status from the API is .....{veracode_status}")
                # print("Insert the status into the resolution column")

                # file_path = 'JanFeb2024_Extract.xlsx'
                # file_type = magic.identify.api.magic_file()
                # #from_file(file_path)
                # print(file_type)  # Output: 'text/plain'

                #
                # df = pd.read_excel('JanFeb2024_Extract.xlsx', usecols='H', engine='openpyxl')
                #
                # for value in df.values:
                #     print(value[0])

                # workbook = openpyxl.load_workbook('JanFeb2024_Extract.xlsx')
                # sheet = workbook.active
                #
                # for row in sheet.iter_rows():
                #     print(row[7].value)

            #except Exception as ex:
            #    print(f"Exception is  {ex}")

                # writer = csv.writer(file)
                # writer.writerow(["Severity", "Scan Type", "Name", "CWE", "Date", "Product", "Component", "Version"])
        #
        # with open('updated_sast_results.csv', 'w', newline='') as sast_file: writer = csv.writer(sast_file)
        # writer.writerow(["Severity", "Scan Type", "Name", "CWE", "First Date", "Last Date", "Product", "File Name"])
    except requests.RequestException as e:
        print("Whoops!")
        print(e)
        sys.exit(1)
