import os
import subprocess


def check_spring_boot(project_dir):
    """
    Checks if a project directory is a Spring Boot project.

    Args:
        project_dir (str): Path to the project directory.

    Returns:
        bool: True if the project is a Spring Boot project, False otherwise.
    """
    spring_boot_indicators = [
        '.mvn',
        'pom.xml',
        'application.properties',
        'application.yml'
    ]

    for indicator in spring_boot_indicators:
        if os.path.exists(os.path.join(project_dir, indicator)):
            return True

    return False


def check_nodejs(project_dir):
    """
    Checks if a project directory is a Node.js project.

    Args:
        project_dir (str): Path to the project directory.

    Returns:
        bool: True if the project is a Node.js project, False otherwise.
    """
    nodejs_indicators = [
        'package.json',
        'node_modules',
        'node_modules.lock.json'
    ]

    for indicator in nodejs_indicators:
        if os.path.exists(os.path.join(project_dir, indicator)):
            return True

    return False


def check_project_type(project_dir):
    """
    Checks if a project directory is a Spring Boot or Node.js project.

    Args:
        project_dir (str): Path to the project directory.

    Returns:
        str: 'Spring Boot' if the project is a Spring Boot project, 'Node.js' if it's a Node.js project, None otherwise.
    """
    if check_spring_boot(project_dir):
        try:
            result = subprocess.run(["mvn", "jar:jar"], check=True, text=True, capture_output=True, cwd=project_dir)
            print("Command output:")
            print(result.stdout)
        except subprocess.CalledProcessError as e:
            print("Command failed with return code:", e.returncode)
            print("Error output:")
            print(e.stderr)


        return 'Spring Boot'
    elif check_nodejs(project_dir):
        return 'Node.js'
    else:
        return None


# Example usage:
project_dir = 'merchant-profiling-bpc-integration-service'
print(check_project_type(project_dir))