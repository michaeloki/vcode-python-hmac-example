#!/bin/bash

echo "manipulate a JSON file"
#play_link=$(jq '.[1].challenges[0].playLink' definitions.json)

#play_link=$(jq -r '.[] | .challenges[] | select(.playLink) | .playLink + "abc"' definitions.json)


#play_link=$(jq -r '.[] | .challenges[] | select(.playLink) | ".abc" + (.playLink | sub("^.") | ".") | sub("^abc") | .playLink' definitions.json)


# Read input from the console
echo "What is your base URL?"
read base_url

# Print the input back
echo "You entered: $base_url"

s
# Read JSON object from the file
json=$(cat definitions.json)


# Modify the "playLink" values --- REAL SOLUTION
#json=$(echo "$json" | jq '.[].challenges[].playLink |= "'$base_url'" + .')

# Modify the "playLink" values
#json=$(echo "$json" | jq '.[].challenges[].playLink |= . + "https://abc.com"')

# Print the updated JSON object
#echo "$json"


# Modify the "playLink" values

# json=$(echo "$json" | jq '.[][].challenges[].playLink |= sub(".*(?=/[^/]*$)", "https://abc.com", "g")')

json=$(echo "$json" | jq '.[][].challenges[].playLink |= "'$base_url'" + (. | ltrimstr(./*(.*\/)))')


echo "$json" > definitions.json

echo $play_link