import os
import json

# import websockets

filename = "data/pipeline_streams.json"
pipeline_object = {"app_profile": "merchant-portal-app", "pipeline_id": "7890383737", "messageSource": "upstream"}
try:
    with open(filename, 'r') as file:
        content = file.read()
        if content:
            print("File is not empty")
            with open(filename) as f:
                data = json.load(f)
                data.append(pipeline_object)
                # data['your_array'].append(pipeline_object)
            with open(filename, 'w') as f:
                json.dump(data, f)
        else:
            file_path = os.path.join('', filename)
            json_object = [pipeline_object]
            json_array = json.dumps(json_object)
            with open(file_path, 'w') as f:
                f.write(json_array)
            if os.path.isfile(file_path):
                print("The upstream payload was successfully created")
except FileNotFoundError:
    print("File not found")
