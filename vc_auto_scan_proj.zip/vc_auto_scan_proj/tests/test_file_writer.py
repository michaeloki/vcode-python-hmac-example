import pytest
import csv
from io import StringIO
from unittest.mock import patch

def file_creator(app_name: str, summary: str, status: str, timestamp: str):
    if not isinstance(app_name, str) or not isinstance(summary, str) or not isinstance(status, str) or not isinstance(timestamp, str):
        raise TypeError("All arguments must be strings")
    with open("test_sum_file_sample.csv", 'a', newline='') as csv_file_:
        csv_writer_ = csv.writer(csv_file_)
        csv_writer_.writerow(
            [
                app_name, summary, status, timestamp
            ]
        )

def test_file_creator():
    with patch('builtins.open', return_value=StringIO()) as mock_open:
        file_creator("Test App", "This is a test", "Success", "2022-01-01")
        mock_open.assert_called_once_with("test_sum_file_sample.csv", 'a', newline='')
        mock_open.return_value.__enter__.return_value.tell.assert_called_once_with()
        mock_open.return_value.__enter__.return_value.write.assert_called_once_with("Test App,This is a test,Success,2022-01-01\n")

def test_file_creator_invalid_app_name():
    with patch('builtins.open', return_value=StringIO()) as mock_open:
        with pytest.raises(TypeError):
            file_creator(123, "This is a test", "Success", "2022-01-01")
        mock_open.assert_called_once_with("test_sum_file_sample.csv", 'a', newline='')
        mock_open.return_value.__enter__.return_value.tell.assert_called_once_with()

def test_file_creator_invalid_summary():
    with patch('builtins.open', return_value=StringIO()) as mock_open:
        with pytest.raises(TypeError):
            file_creator("Test App", 123, "Success", "2022-01-01")
        mock_open.assert_called_once_with("test_sum_file_sample.csv", 'a', newline='')
        mock_open.return_value.__enter__.return_value.tell.assert_called_once_with()

def test_file_creator_invalid_status():
    with patch('builtins.open', return_value=StringIO()) as mock_open:
        with pytest.raises(TypeError):
            file_creator("Test App", "This is a test", 123, "2022-01-01")
        mock_open.assert_called_once_with("test_sum_file_sample.csv", 'a', newline='')
        mock_open.return_value.__enter__.return_value.tell.assert_called_once_with()

def test_file_creator_invalid_timestamp():
    with patch('builtins.open', return_value=StringIO()) as mock_open:
        with pytest.raises(TypeError):
            file_creator("Test App", "This is a test", "Success", 123)
        mock_open.assert_called_once_with("test_sum_file_sample.csv", 'a', newline='')
        mock_open.return_value.__enter__.return_value.tell.assert_called_once_with()

def test_file_creator_invalid_argument_type():
    with pytest.raises(TypeError):
        file_creator("Test App", "This is a test", "Success", "2022-01-01", "Invalid Argument")

def test_file_creator_invalid_argument_count():
    with pytest.raises(TypeError):
        file_creator("Test App")

def test_file_creator_invalid_argument_order():
    with pytest.raises(TypeError):
        file_creator("Test App", "This is a test", "Success")