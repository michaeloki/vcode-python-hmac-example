import unittest
from unittest.mock import patch

import slack_file_upload

class TestUploadSlack(unittest.TestCase):

    @patch('slack_sdk.WebClient.files_upload_v2')
    @patch('slack_sdk.WebClient.auth_test')
    def test_upload_slack_client_init(self, mock_auth_test, mock_files_upload_v2):
        mock_auth_test.return_value = {'ok': True, 'access_token': 'xoxb-1234567890-1234567890-1234567890'}
        channel_id = 'C0123456'
        filename = 'example.txt'
        slack_bot_token = 'xoxb-1234567890-1234567890-1234567890'
        title = 'Example File'

        slack_file_upload.upload_file_to_slack(channel_id, filename, slack_bot_token, title)

        mock_files_upload_v2.assert_called_once_with(
            channel=channel_id,
            title=title,
            file=filename,
            initial_comment='File created via the universal function😊'
        )


    @patch('slack_sdk.WebClient.files_upload_v2')
    def test_upload_slack_argparse_init(self, mock_files_upload_v2):
        mock_files_upload_v2.return_value = {'ok': True, 'file': {'id': 'file_id'}}

        channel_id = 'C0123456'
        filename = 'example.txt'
        slack_bot_token = 'xoxb-1234567890-1234567890-1234567890'
        title = 'Example File'

        slack_file_upload.upload_file_to_slack(channel_id, filename, slack_bot_token, title)

        mock_files_upload_v2.assert_called_once_with(
            channel=channel_id,
            title=title,
            file=filename,
            initial_comment='File created via the universal function😊'
        )

if __name__ == '__main__':
    unittest.main()
