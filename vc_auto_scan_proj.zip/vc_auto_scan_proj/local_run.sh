#!/bin/bash

VERACODE_API_ID=$(grep VERACODE_ID .env | cut -d '=' -f 2-)
VERACODE_API_SECRET=$(grep VERACODE_SECRET .env | cut -d '=' -f 2-)
chmod +x ./install.sh
./install.sh "$VERACODE_API_ID" "$VERACODE_API_SECRET" "sbom" #"setup" or "sbom"
