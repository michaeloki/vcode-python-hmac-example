#!/usr/bin/env bash

access_token=$1
veracode_api_key_id=$2
veracode_api_key_secret=$3
gt_pat=$4
channel_id=$5
slack_bot_token=$6
artefactory_user=$7
artefactory_pass=$8

json_file_name="test_applist.json"
input_file="sast_scan_result.txt"
sast_output_file="sast_scan_details.txt"
sca_output_file="scan_summary_file.csv"

function sast_scanner() {
  # === Configuration ===
GITLAB_HOST="https://gitlab.payconiq.io"
ACCESS_TOKEN="$1"

data=$(jq '.[]' $json_file_name)

# Check if the data is not empty
if [ -n "$data" ]; then
  curl -fsS https://tools.veracode.com/veracode-cli/install | sh #install Veracode CLI
  # Ensure ~/.veracode directory exists
  mkdir -p "$HOME/.veracode"
  set -euo pipefail


  cat <<EOF > "$HOME/.veracode/credentials"
   [default]
   veracode_api_id=veracode_api_key_id
   veracode_api_key=veracode_api_key_secret
EOF

  chmod 600 "$HOME/.veracode/credentials"
  echo "######### Current DIR is $(pwd)"
  chmod +x ./util/python_script_handler.sh


  jq -r '.[] | .app_name' $json_file_name | while read -r app_name; do
  echo "app name is $app_name"
  TARGET_REPO=$(echo "$app_name" | cut -d'/' -f2 | cut -d'[' -f1)
  echo "TARGET_REPO is $TARGET_REPO"

  if [ -z "$TARGET_REPO" ]; then
  echo "Please provide a repository name to search for."
  echo "Usage: $0 <repo-name>"
  exit 1
  fi

  # === Search for matching projects ===
  echo "Searching for projects matching: $TARGET_REPO"

  RESPONSE=$(curl -s --header "PRIVATE-TOKEN: $ACCESS_TOKEN" \
  "$GITLAB_HOST/api/v4/search?scope=projects&search=$TARGET_REPO")
  MATCH_COUNT=$(echo "$RESPONSE" | jq length)

  if [ "$MATCH_COUNT" -eq 0 ]; then
    echo "No matching repositories found for $TARGET_REPO."
    cd "/builds/sec/veracode-auto-scan-project"
    echo "Current DIR is $(pwd)"
    ls -l
    #chmod +x util/python_script_handler.sh
    ./util/python_script_handler.sh "$TARGET_REPO" "scan_status"
  fi

  # === Pick the best match (first result) ===
  BEST_MATCH_NAME=$(echo "$RESPONSE" | jq -r ".[0].name")
  BEST_MATCH_URL=$(echo "$RESPONSE" | jq -r ".[0].http_url_to_repo")

  set +e
  echo "Found match: $BEST_MATCH_NAME"
  echo "Cloning from: $BEST_MATCH_URL"
  REPO_URL="${BEST_MATCH_URL#https://}"
  git clone https://oauth2:${gt_pat}@$REPO_URL
  set -e
  echo "Run VC scan here..."
  set +e
  #  mvn --version
  #  node -v
  # gradle -v # install gradle
  echo "###### Check 1:::Current DIR is $(pwd) and target repo is $TARGET_REPO"
#  if [ -d "$TARGET_REPO/src/main/java" ] && [ -d "$TARGET_REPO/src/main/resources" ]; then
  if [ -f "$TARGET_REPO/pom.xml" ]; then
    echo "##### maven project was detected#####"
    ls -l
    MVN_CONFIG_FILE="settings.xml"
    sed -i 's|\(<username>\)[^<]*\(<\/username>\)|\1'"$artefactory_user"'\2|' "$MVN_CONFIG_FILE"
    sed -i 's|\(<password>\)[^<]*\(<\/password>\)|\1'"$artefactory_pass"'\2|' "$MVN_CONFIG_FILE"
    echo "whoami $(whoami)"
    mkdir ~/.m2
    cp "settings.xml" ~/.m2
    cd "$TARGET_REPO" || exit
    # mvn -q jar:jar
    mvn package -Dmaven.test.skip=true -Dmaven.repo.remote=https://artifactory.payconiq.io/artifactory/ -X
    #mvn clean install -Dmaven.repo.remote=https://artifactory.payconiq.io/artifactory/
    ./veracode static scan "$TARGET_REPO".jar >> $input_file 2>&1
    echo "View the input file below"
    cat $input_file
    rm -rf "$TARGET_REPO"
    cd ..
    echo "###### Check 3:::Current DIR is $(pwd)"
  elif [ -f "$TARGET_REPO/build.gradle" ]; then
      echo "Gradle"
  fi
#    return
#  fi

  # Check for Node.js project
  if [ -d "$TARGET_REPO/src" ] && [ -f "$TARGET_REPO/package.json" ]; then
    echo "Node.js"
    # return
  fi

  # Check for Android project
  if [ -d "$TARGET_REPO/src/main" ] && [ -d "$TARGET_REPO/src/test" ] && [ -f "$TARGET_REPO/AndroidManifest.xml" ]; then
    echo "Android"
    # return
  fi

  # Check for iOS project
  if [ -d "$TARGET_REPO/Classes" ] && [ -d "$TARGET_REPO/Resources" ] && [ -f "$TARGET_REPO/Info.plist" ]; then
    echo "iOS"
    # return
  fi


  set -e
  echo "Update the report file"
  echo "Delete the cloned folder..."
  rm -rf "$BEST_MATCH_NAME"


#  curl -X POST https://slack.com/api/chat.postMessage \
#    -H "Authorization: Bearer $SLACK_BOT_TOKEN" \
#    -H "Content-type: application/json" \
#    --data "{\"channel\":\"#veracode-auto-scan\",\"text\":"Critical findings will be listed here"}"
  done
  # Remove all non-printable characters
  awk '{
    gsub(/\x1B\[[0-9;]*[A-Za-z]/, "");   # strip ANSI escape sequences
    gsub(/[\x00-\x1F\x7F]/, "");         # strip other control chars
    print
  }' "$input_file" > "$sast_output_file"

  echo "Cleaned file saved as $sast_output_file in $(pwd)"
  ./slack_api.sh "$channel_id" "$slack_bot_token" "slack_file_upload"

else
  echo "No data found in the JSON file."
fi

}

if [ ! -f ".env" ]; then
  echo "Using CI/CD variable"
  sast_scanner "$access_token"
  else
    echo "Read the .env file on local and call the SAST function"
    ACCESS_TOKEN=$(grep ACCESS_TOKEN .env | cut -d '=' -f 2-)
    sast_scanner "$ACCESS_TOKEN"
fi
