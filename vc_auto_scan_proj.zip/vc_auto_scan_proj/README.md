# veracode-auto-scan

## Getting started

This project calls scans all the active projects on Veracode. The scans include Software Composition Analysis (SCA) and
Static Application Security Testing (SAST)

# Local installation
Run `sh install.sh`

# Unit Testing
Run `python -m unittest tests/test_slack_file_upload.py`
