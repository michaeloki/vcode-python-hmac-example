## To-Do List
1. Get a list of Veracode projects - Done
2. Get SBOM report for all the projects - Done
3. Scan the SBOM file for each app profile - Done
4. Change the json file name back to app_list.json - 
5. Create the structure of the report file -

## Optional To-Do List
i.   Get a list of Gitlab projects. - DONE
ii.  Detect the programming language. -
iii. Package the app. -
iv.  Scan the executable on Veracode. -

## Sub-tasks
1. Create a token that can access the list of projects on Gitlab.
2. Test the Gitlab access via curl.
3. Create a traversal function that handles monorepos.
4. Create a lightweight version of the Veracode-integration CI/CD stages.
5. Schedule the scans on Gitlab
6. Send Slack notifications