import csv
import sys
import requests
import argparse
import os
import json
from veracode_api_signing.plugin_requests import RequestsAuthPluginVeracodeHMAC
from datetime import datetime
import time

api_base = "https://api.veracode.com"

headers = {"User-Agent": "VC_AUTO_SCAN"}

tag = "Security"

formatted_datetime = ""

generic_page_number = 0

generic_sbom_file_name = "sca_sbom_file.json"

report_file = "app_list.json" #report_test_list

final_report_file = "full_auto_scan_report.csv" #auto_scan.csv

scan_summary_file = "scan_summary_file.csv"

def sbom_file_sca_scanner(profile: str):
    # print("Return the SBOM that contains your SCA agent-based scan results for your project")
    sbom_file_path = generic_sbom_file_name
    try:
        with open(sbom_file_path, "rb") as f:
            files = {
                "sbom-file": (os.path.basename(sbom_file_path), f, "application/octet-stream")
            }

            response = requests.post(
                "https://api.veracode.com/srcclr/sbom/v1/manage/scan",
                files=files,
                auth=RequestsAuthPluginVeracodeHMAC()
            )
            print(f"Status Code: {response.status_code}")
            try:
                if response.ok:
                    sbom_data = response.json()
                    all_findings = sbom_data["vulnerabilities"]
                    for vuln_data in all_findings:
                        with open(final_report_file, 'a', newline='') as csv_file:
                            csv_writer = csv.writer(csv_file)
                            csv_writer.writerow(
                                [vuln_data["id"], vuln_data["description"], vuln_data["ratings"][0]["severity"], profile,
                                 vuln_data["advisories"][0]["title"], vuln_data["advisories"][0]["url"],
                                 vuln_data["affects"][0]["ref"], vuln_data["recommendation"]])
                    time.sleep(6)
                else:
                    print(f"Response code is: {response.status_code}")
                    print(f"Response message is: {response.text}")

            except requests.RequestException as re:
                print(f"SBOM_FILE_SCANNER:::Exception: {re}")
                #print("Response Body:", response.text)

    except requests.RequestException as re:
        print("SBOM Orgs " + str(re))
        sys.exit(1)

def sbom_sca_agent(guid: str, profile: str, key_id: str, secret: str):
    try:
        response = (requests.get
                    ("https://api.veracode.com/srcclr/sbom/v1/targets/" + guid + "/cyclonedx?type=application",
                     auth=RequestsAuthPluginVeracodeHMAC
                     (api_key_id=key_id,
                      api_key_secret=secret),
                     headers=headers))
        if response.ok:
            sca_data = response.json()
            json_payload = json.dumps(sca_data, indent=4)
            file_path = os.path.join('', generic_sbom_file_name)
            with open(file_path, 'w') as f:
                f.write(json_payload)
            if os.path.isfile(file_path):
                sbom_file_sca_scanner(profile)
        else:
            print(f" {response.status_code}")
            if response.status_code == 404:
                scan_desc = response.json()["_embedded"]["errors"][0]["detail"]
                with open(scan_summary_file, 'a', newline='') as csv_new_file:
                    csv_writer = csv.writer(csv_new_file)
                    csv_writer.writerow([profile,scan_desc,"Not scanned",datetime.now()])
            if response.status_code == 403:
                print(f"App name with 403 is {profile}")

    except requests.RequestException as re:
        print("SBOM Orgs " + str(re))
        sys.exit(1)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--arg1", type=str, help="First string argument:key_id")
    parser.add_argument("--arg2", type=str, help="Second string argument:secret")
    args = parser.parse_args()

    try:
        current_datetime = datetime.now()
        formatted_datetime = current_datetime.strftime('%d_%m_%Y_%H_%M_%S')
        with open(scan_summary_file, 'a', newline='') as static_file:
            static_writer = csv.writer(static_file)
            static_writer.writerow(
                ["App", "Summary", "Status", "Date"])
        with open(final_report_file, 'a', newline='') as static_file:
            static_writer = csv.writer(static_file)
            static_writer.writerow(
                ["CVE", "Description", "Severity", "App", "Title", "URL", "Component", "Recommendation"])
        try:
            with open(report_file, 'r') as file:
                data = json.load(file)
                for app_data in data:
                    try:
                        sbom_sca_agent(app_data["guid"], app_data["app_name"], args.arg1, args.arg2)
                    except KeyError:
                        print("Key error")
        except Exception as ex:
            print(f"File Exception not found in {ex}.")
    except FileNotFoundError as e:
        print("Critical Exception!")
        sys.exit(1)
