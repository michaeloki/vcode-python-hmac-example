#!/bin/bash

echo "A little housekeeping"
key_id=$1
secret=$2
fn_call=$3

function install_dependencies() {

_VC_ID=$1
_VC_SECRET=$2

if python3 --version &>/dev/null; then
    pip3_check=$(whereis pip3)
    if [ -z "$pip3_check" ]; then
      apt-get -y install python3-venv python-pip-whl python3-distutils python3-lib2to3 python3.9-venv > /dev/null 2>&1
    fi
    if python3 -m pip list | grep -i requests; then
      python3 -m venv vcenv
      source vcenv/bin/activate
      pip3 install -r requirements.txt -q > /dev/null 2>&1
      if [ "$fn_call" == "setup" ]; then
        python3 get_all_profiles.py --arg1 "$_VC_ID" --arg2 "$_VC_SECRET"
      fi
      if [ "$fn_call" == "sbom" ]; then
        python3 sbom_processor.py --arg1 "$_VC_ID" --arg2 "$_VC_SECRET"
      fi
      deactivate
    else
      echo "Installing dependencies..."
      apt-get -y install python3-venv python-pip-whl python3-distutils python3-lib2to3 python3.9-venv > /dev/null 2>&1
      python3 -m venv vcenv
      source vcenv/bin/activate
      pip3 install -r requirements.txt -q > /dev/null 2>&1
      if [ "$fn_call" == "setup" ]; then
        python3 get_all_profiles.py --arg1 "$_VC_ID" --arg2 "$_VC_SECRET"
      fi
      if [ "$fn_call" == "sbom" ]; then
        python3 sbom_processor.py --arg1 "$_VC_ID" --arg2 "$_VC_SECRET"
      fi
      if pip3 list | grep -q requests; then
        deactivate
      fi
    fi
else
    echo "Python 3 is not installed. Please install Python 3 first."
    exit 1
fi
}

if [ ! -f ".env" ]; then
  echo "Using CI/CD variables"
  install_dependencies "$key_id" "$secret" "$fn_call"
  else
    echo "Read the .env file and call the python script with the vars"
    VERACODE_ID=$(grep VERACODE_ID .env | cut -d '=' -f 2-)
    VERACODE_SECRET=$(grep VERACODE_SECRET .env | cut -d '=' -f 2-)
    install_dependencies "$VERACODE_ID" "$VERACODE_SECRET" "$fn_call"
fi
