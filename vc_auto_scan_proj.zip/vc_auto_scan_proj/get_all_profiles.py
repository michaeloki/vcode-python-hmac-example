import sys
import requests
import argparse
import os
import json
from veracode_api_signing.plugin_requests import RequestsAuthPluginVeracodeHMAC
from datetime import datetime

api_base = "https://api.veracode.com"

headers = {"User-Agent": "VC_AUTO_SCAN"}

tag = "Security"

formatted_datetime = ""

generic_page_number = 0

report_file = "app_list.json"

def get_app_by_tag(key_id: str, secret: str, page_number: int, current_date: str):
    print("Get app by tag")
    try:
        tag_response = (requests.get
                        (api_base + "/appsec/v1/applications?page=" + str(page_number) + "&size=200",
                         auth=RequestsAuthPluginVeracodeHMAC
                         (api_key_id=key_id,
                          api_key_secret=secret),
                         headers=headers))
        if tag_response.ok:
            data = tag_response.json()
            all_findings = data["_embedded"]["applications"]
            num_of_findings = len(all_findings)
            print(f"The Number of app profiles is {num_of_findings}")
            payload = []
            for index, appx in enumerate(data["_embedded"]["applications"]):
                # Write this to a JSON file and exclude app names with "ARCHIVED", "COMMON" and "COMMONS-SHARED"
                app_name = appx["profile"]["name"].upper()
                if ("COMMONS-SHARED" not in app_name and "ARCHIVED" not in app_name and "COMMON" not in app_name
                        and "MOCK" not in app_name):
                    print(appx["profile"]["name"].upper() + " has no forbidden word")
                    payload.append({"app_name": appx['profile']['name'], "guid": appx["guid"]})
                    json_payload = json.dumps(payload, indent=4)
                    file_path = os.path.join('', report_file)
                    with open(file_path, 'w') as f:
                        f.write(json_payload)
                else:
                    print(f"prohibited word is in {app_name}")
                    # if os.path.isfile(file_path):
                    #     print("The JSON payload was successfully created")
    except requests.RequestException as re:
        print("Static scan failed with " + str(re))
        sys.exit(1)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--arg1", type=str, help="First string argument:key_id")
    parser.add_argument("--arg2", type=str, help="Second string argument:secret")

    args = parser.parse_args()

    try:
        current_datetime = datetime.now()
        formatted_datetime = current_datetime.strftime('%d_%m_%Y_%H_%M_%S')
        get_app_by_tag(args.arg1, args.arg2, generic_page_number, formatted_datetime)
    except requests.RequestException as e:
        print("Critical Exception!")
        # print(e)
        sys.exit(1)
