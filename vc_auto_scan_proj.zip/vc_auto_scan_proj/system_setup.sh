#!/bin/bash
distro_name=$(uname -a)
echo "Please wait while we provision your system..."
echo "Your Linux distro is $distro_name"


#Call Gitlab