#!/bin/bash
VERACODE_API_ID=$1
VERACODE_API_SECRET=$2

if [ ! -f "app_list.json" ]; then
  echo "App list is not available"
  else
    echo "App list is available"
    echo "Call SBOM processor..."
    chmod +x ./install.sh
    ./install.sh "$VERACODE_API_ID" "$VERACODE_API_SECRET" "sbom"
fi
