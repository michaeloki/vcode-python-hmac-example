import os
import subprocess

import argparse


def check_spring_boot(project_dir: str):
    spring_boot_indicators = [
        '.mvn',
        'pom.xml',
        'application.properties',
        'application.yml'
    ]

    for indicator in spring_boot_indicators:
        if os.path.exists(os.path.join(project_dir, indicator)):
            return True

    return False


def check_nodejs(project_dir):
    nodejs_indicators = [
        'package.json',
        'node_modules',
        'node_modules.lock.json'
    ]

    for indicator in nodejs_indicators:
        if os.path.exists(os.path.join(project_dir, indicator)):
            return True

    return False


def check_project_type(project_dir):
    if check_spring_boot(project_dir):
        try:
            result = subprocess.run(["mvn", "jar:jar"], check=True, text=True, capture_output=True, cwd=project_dir)
            print("Command output:")
            print(result.stdout)
            print("Run Veracode CLI here...")
            # delete the binary file after scanning it with the CLI
            print(f"Delete the binary target/{project_dir}.jar file")
            subprocess.run(["rm -rf", "target/{project_dir}.jar"])


        except subprocess.CalledProcessError as e:
            print("Command failed with return code:", e.returncode)
            print("Error output:")
            print(e.stderr)


        return 'Spring Boot'
    elif check_nodejs(project_dir):
        return 'Node.js'
    else:
        return None

# project_dir = 'merchant-profiling-bpc-integration-service'
# print(check_project_type(project_dir))

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--arg1", type=str, help="First argument:project_dir")

    args = parser.parse_args()
    print(check_project_type(args.arg1))