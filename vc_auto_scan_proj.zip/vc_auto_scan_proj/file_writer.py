import argparse
import csv
import sys
import requests
from datetime import datetime


def file_creator(app_name: str, summary: str, status: str, timestamp: str):
    with open("scan_summary_file.csv", 'a', newline='') as csv_file_:
        csv_writer_ = csv.writer(csv_file_)
        csv_writer_.writerow(
            [
                app_name, summary, status, timestamp
            ]
        )

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--arg1", type=str, help="First string argument:TARGET_REPO")
    parser.add_argument("--arg2", type=str, help="Second string argument:summary")
    parser.add_argument("--arg3", type=str, help="Third string argument:status")

    args = parser.parse_args()

    try:
        current_datetime = datetime.now()
        formatted_datetime = current_datetime.strftime('%d_%m_%Y_%H_%M_%S')
        with open("scan_summary_file.csv", 'a', newline='') as csv_file:
            csv_writer = csv.writer(csv_file)
            csv_writer.writerow(
                [
                    "App Name", "Summary", "Status", "Date"
                ]
            )
        file_creator(args.arg1, args.arg2, args.arg3, formatted_datetime)
    except requests.RequestException as e:
        print("Critical Exception!")
        print(e)
        sys.exit(1)
