#!/bin/bash

channel_id=$1
slack_bot_token=$2
fn_call=$3

function install_dependencies() {
  sast_file="sast_scan_details.txt"
  sca_unscanned_file="scan_summary_file.csv"
  sca_scan_file="full_auto_scan_report.csv"
  sca_size=${#sca_unscanned_file}
  echo "####### SCA_scan size is $sca_size and function call is $fn_call"
  sast_title="Veracode SAST Scan Results"
  sca_unscanned_title="Veracode SCA status for unscanned projects"
  sca_scan_title="Veracode SCA Scan Results"



if python3 --version &>/dev/null; then
    pip3_check=$(whereis pip3)
    if [ -z "$pip3_check" ]; then
      apt-get -y install python3-venv python-pip-whl python3-distutils python3-lib2to3 python3.9-venv > /dev/null 2>&1
    fi
    if python3 -m pip list | grep -i requests; then
      python3 -m venv vcenv
      source vcenv/bin/activate
      pip3 install -r requirements.txt -q
      if [ "$fn_call" == "slack_file_upload" ]; then
        echo "SFL"
#        python3 slack_file_upload.py --arg1 "$channel_id" --arg2 "$(pwd)/$sast_file" --arg3 "$slack_bot_token" --arg4 "$sast_title"
#        python3 slack_file_upload.py --arg1 "$channel_id" --arg2 "$(pwd)/$sca_unscanned_file" --arg3 "$slack_bot_token" --arg4 "$sca_unscanned_title"
#        python3 slack_file_upload.py --arg1 "$channel_id" --arg2 "$(pwd)/$sca_scan_file" --arg3 "$slack_bot_token" --arg4 "$sca_scan_title"
      fi
      deactivate
    else
      echo "Installing dependencies..."
      apt-get -y install python3-venv python-pip-whl python3-distutils python3-lib2to3 python3.9-venv > /dev/null 2>&1
      python3 -m venv slenv
      source slenv/bin/activate
      pip3 install -r requirements.txt -q > /dev/null 2>&1
      if [ "$fn_call" == "slack_file_upload" ]; then
        echo "About to call slack_file_upload"
#        python3 slack_file_upload.py --arg1 "$channel_id" --arg2 "$(pwd)/$sast_file" --arg3 "$slack_bot_token" --arg4 "$sast_title"
#        python3 slack_file_upload.py --arg1 "$channel_id" --arg2 "$(pwd)/$sca_unscanned_file" --arg3 "$slack_bot_token" --arg4 "$sca_unscanned_title"
#        python3 slack_file_upload.py --arg1 "$channel_id" --arg2 "$(pwd)/$sca_scan_file" --arg3 "$slack_bot_token" --arg4 "$sca_scan_title"
      fi
    fi
else
    echo "Python 3 is not installed. Please install Python 3 first."
    exit 1
fi
}

install_dependencies
