import os
from dotenv import load_dotenv

FRAUD_API_URL="https://frauddetection.netcraft.com/api/v1/"
DDW_API_URL="https://discovery.netcraft.com/api/v1/"
TAKEDOWN_API_URL="https://takedown.netcraft.com/api/v1/"
# Load environment variables from a file named '.env'
advertEndpoints = set()
advertEndpoints.add("/advertsearch/results")
advertEndpoints.add("/appsearch/results")
advertEndpoints.add("/socialsearch/results")
advertEndpoints.add("/manualmonitoring/list")

takedownEndpoints = set()
takedownEndpoints.add("/attacks")
#takedownEndpoints.add("/attacks?group_id=")

ddwEndpoints = set()
ddwEndpoints.add("/results")
ddwEndpoints.add("/intelligence")

load_dotenv()

# Access the environment variable
AUTH_TOKEN = os.environ['AUTH_TOKEN']

headers = {
    "Accept": "application/json",
    "Authorization": AUTH_TOKEN,
    "User-Agent": "EPI-Netcraft"
}
