# Load the data
def load_data(df, destination):
    if df.empty:
        print("No data to load")
        return
    df.to_csv(destination, index=False)
    print(f"Data loaded to {destination}")
