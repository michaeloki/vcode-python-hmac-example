# Extract the data
import requests
from config import FRAUD_API_URL, headers, advertEndpoints
from config import DDW_API_URL
from config import TAKEDOWN_API_URL


def extract_fraud_data(url):
    global api_response
    try:
        print(f"url is {url}")
        response = requests.get(FRAUD_API_URL + url, headers=headers)
        response.raise_for_status()
        api_response = response.json()
        return api_response

    except requests.RequestException as e:
        print(f"Error during GET request: {e.response}")
        return None


def extract_ddw_data(url):
    try:
        response = requests.get(DDW_API_URL + url, headers=headers)
        response.raise_for_status()
        return response.json()
    except requests.RequestException as e:
        print(f"Error during GET request: {e}")
        return None


def extract_takedown_data(url):
    try:
        response = requests.get(TAKEDOWN_API_URL + url, headers=headers)
        response.raise_for_status()
        return response.json()
    except requests.RequestException as e:
        print(f"Error during GET request: {e}")
        return []
