# Transform the data
import pandas as pd

def transform_data(data, request_name):
    global df
    if not data:
        return pd.DataFrame()

    try:
        print(f"request_name is {request_name}")
        match request_name:
            case "advertsearch":
                records = [{
                    "id": app["id"],
                    "title": app["title"],
                    "display_url": app["display_url"],
                    "url": app["url"],
                    "search_term": app["search_term"],
                    "search_engine": app["search_engine"],
                    "brand": app["brand"],
                    "last_seen": app["last_seen"],
                    "country_codes": app["countrycodes"][0],
                    "by": app["review"].get("by"),
                    "category": app["review"].get("category"),
                    "content": app["content"],
                    "date": app["review"].get("date"),
                } for app in data["data"]]
                df = pd.DataFrame(records)
            case "appsearch":
                records = [{
                    "store_id": app["store_id"],
                    "name": app["name"],
                    "brand": app["brand"],
                    "by": app["review"].get("by"),
                    "category": app["review"].get("category"),
                    "date": app["review"].get("date")
                } for app in data["data"]]
                df = pd.DataFrame(records)
            case "socialsearch":
                records = [{
                    "site": app["site"],
                    "name": app["name"],
                    "url": app["url"],
                    "brand": app["brand"],
                    "profile_image": app["profile_image"],
                    "by": app["review"].get("by"),
                    "category": app["review"].get("category"),
                    "comment": app["review"].get("comment"),
                    "date": app["review"].get("date")
                } for app in data["data"]]
                df = pd.DataFrame(records)
            case "manualmonitoring":
                records = [{
                    "type": app["type"],
                    "submitted_by": app["submitted_by"],
                    "value": app["value"],
                    "submitted_time": app["submitted_time"],
                    "status": app["status"],
                    "value_human": app["value_human"]
                } for app in data["entries"]]
                df = pd.DataFrame(records)
            case "attacks":
                df = pd.DataFrame(data)
                df = df[['attack_url', 'reported_url', 'target_brand', 'domain', 'host']]
                df.columns = ['attack_url', 'reported_url', 'target_brand', 'domain', 'host']
            case "intelligence":
                records = [{
                    "acknowledged": app["acknowledged"].get("value"),
                    "dates": app["dates"].get("content_found"),
                    "intelligence_created": app["dates"].get("intelligence_created"),
                    "priority": app["priority"].get("value"),
                    "source": app["source"].get("name"),
                    "type": app["type"].get("name"),
                    "value": app["value"].get("value"),
                    "rule": app["rule"].get("name"),
                    "entities": app["entities"][0]["name"],
                    "result": app["result"].get("uri"),
                } for app in data["data"]]
                df = pd.DataFrame(records)
        return df
    except Exception as ex:
        print(f"Exception is {ex}")
    print(f"df is {df}")
    return df
