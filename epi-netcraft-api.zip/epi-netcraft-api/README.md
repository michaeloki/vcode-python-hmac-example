# epi-netcraft-data-api
This API pulls data from Netcraft


## Setup
Generate your auth token via your Netcraft API account
Create a .env file and add `AUTH_TOKEN="Bearer *********************"`

## Endpoints
Fraud Detection Base URL: https://frauddetection.netcraft.com/api/v1/ 
 /advertsearch/results
 /appsearch/results
 /socialsearch/results
 /manualmonitoring/list



Takedown Base URL: https://takedown.netcraft.com/api/v1/
 /attacks
 /attacks?group_id={id}

DDW Base URL: https://discovery.netcraft.com/api/v1/
 /results
 /intelligence
