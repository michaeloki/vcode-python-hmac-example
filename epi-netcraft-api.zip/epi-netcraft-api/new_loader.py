
import json
import re
import urllib

class Loader:
    def to_csv(self, df, name):
        print(f"file name is {name}")
        # name = re.search(r'(?<==)[^&]*$', name).group()

        file_name = name.replace("/", "_")
        print(file_name)


        df.to_csv(f"{file_name}.csv", index=False)
