import requests
from config import FRAUD_API_URL, headers, advertEndpoints

class Extractor:
    def fetch(self, item):
        url = f"https://frauddetection.netcraft.com/api/v1/{item}"
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        return response.json()