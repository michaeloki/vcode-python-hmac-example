import pandas as pd

class Transformer:
    def transform(self, json_data):
        df = pd.DataFrame(json_data)
        df["transformed"] = True
        return df