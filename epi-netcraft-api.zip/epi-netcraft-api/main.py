import re

from etl.extractor import extract_fraud_data
from etl.extractor import extract_ddw_data
from etl.extractor import extract_takedown_data
from etl.transformer import transform_data
from etl.loader import load_data
global last_url

def run_fraud_etl(url):
    if url == "/manualmonitoring/list":
        raw_data = extract_fraud_data(url)
        transformed_data = transform_data(raw_data, "manualmonitoring")
        load_data(transformed_data, "manualmonitoring_list" + ".csv")
    try:
        raw_data = extract_fraud_data(url)
        endpoint = raw_data['data'][0].get('web_view_url')
        endpoint = re.search(r'(?<==)[^&]*$', endpoint).group()
        transformed_data = transform_data(raw_data, endpoint)
        load_data(transformed_data, endpoint+".csv")
        if url == "/advertsearch/results":
            run_fraud_etl("/appsearch/results")
        if url == "/appsearch/results":
            run_fraud_etl("/socialsearch/results")
        if url == "/socialsearch/results":
            run_fraud_etl("/manualmonitoring/list")
    except Exception as ex:
        print(f"Exception is {ex} and url is {url}")

def run_ddw_etl(url):
    raw_data = extract_ddw_data(url)
    transformed_data = transform_data(raw_data, "intelligence")
    load_data(transformed_data, "intelligence.csv")

def run_take_down_etl(url):
    raw_data = extract_takedown_data(url)
    transformed_data = transform_data(raw_data, "attacks")
    load_data(transformed_data, "takedown.csv")

if __name__ == "__main__":
    run_fraud_etl("/advertsearch/results")
    run_ddw_etl("/intelligence")
    run_take_down_etl("/attacks")
