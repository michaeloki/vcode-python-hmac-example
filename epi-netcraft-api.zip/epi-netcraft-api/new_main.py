

from new_extractor import Extractor
from new_transformer import Transformer
from new_loader import Loader

# from etl.extractor import extract_fraud_data
# from etl.extractor import extract_ddw_data
# from etl.extractor import extract_takedown_data
# from etl.transformer import transform_data
# from etl.loader import load_data
config_set = {"advertsearch/results", "appsearch/results"}
#advertEndpoints.add("/advertsearch/results")
#advertEndpoints.add("/appsearch/results")
def run_etl():
    extractor = Extractor()
    transformer = Transformer()
    loader = Loader()

    for item in config_set:
        try:
            raw_data = extractor.fetch(item)
            transformed_df = transformer.transform(raw_data)
            loader.to_csv(transformed_df, name=item)
            print(f"Processing is done: {item}")
        except Exception as e:
            print(f"ERROR processing {item}: {e}")

run_etl()