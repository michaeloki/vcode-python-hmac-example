#!/bin/bash
# Setup the environment for the web socket app
echo "Relax while we setup your environment"
if python3 --version &>/dev/null; then
    # Check if pip is installed
    pip3_check=$(whereis pip3)
    echo "pip3 is at $pip3_check"
    if [ -z "$pip3_check" ]; then
      apt-get -y install python3-venv python-pip-whl python3-distutils python3-lib2to3 python3.9-venv > /dev/null 2>&1
    fi
    if python3 -m pip list | grep -i requests; then
      echo "Creating a virtual environment"
      python3 -m venv sockenv
      source sockenv/bin/activate
      cd app || return
      python3 socket_server.py
      cd api || return
      python3 api.py
    else
      echo "Installing dependencies and packages..."
      apt-get -y install python3-venv python-pip-whl python3-distutils python3-lib2to3 python3.9-venv > /dev/null 2>&1
      python3 -m venv sockenv
      source sockenv/bin/activate
      pip3 install -r requirements.txt -q
      cd app || return
      python3 socket_server.py
      cd api || return
      python3 api.py
    fi
else
    echo "Python 3 is not installed. We'll now install Python 3"
    sudo yum update -y
    sudo yum install -y python3
    if python3 --version &>/dev/null; then
      echo "Python3 installation was successful. Please run this script again to install the required packages.."
    else
      echo "Sorry, we couldn't install python 3"
      exit 1
    fi
    exit 0
fi
