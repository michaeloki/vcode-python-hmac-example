import sys
from flask import Flask, request, jsonify
import socketio
import time
import json
import logging
import os
# from dotenv import load_dotenv

# load_dotenv()

#app_id = os.getenv("PIPELINE_COM_CODE")
#socket_server_url = os.getenv("SOCKET_SERVER_URL")

app_id = "9NmmVLAG3wYBsiJdmBZN4GDsoH5lxvSC7Kme"
# socket_server_url = "http://security_pipeline_integration:5000"
socket_server_url = "http://security_pipeline_integration:5000"
# socket_server_url = "http://pipeline_socket_integration-socketApp-1:5000"

logging.basicConfig(stream=sys.stdout)

app = Flask(__name__)

output = ""

sio = socketio.Client()

connected = False


def update_sleep_time_function(wait_time: int):
    return wait_time


sleep_time = update_sleep_time_function(20)


@sio.on("connect")
def on_connect():
    global connected
    print("Connected to server")
    connected = True


@sio.on("disconnect")
def on_disconnect():
    global connected
    print("Disconnected from server")
    connected = False


@sio.on("message")
def on_message(data):
    print(f"Received message from server: {data}")
    global output
    output = data
    global connected
    connected = False
    global sleep_time
    sleep_time = update_sleep_time_function(0)
    # sio.disconnect()


@app.route('/api', methods=['POST'])
def handle_post_request():
    try:
        data = request.get_json()
        print(f"==== data from API CALL ===== and connected is {connected}")
        logging.log(1, f"==== data from API CALL ===== and connected is {connected} ", "")
        incoming_data = json.dumps(data)
        print(f"Converted JSON data :::: ")
        logging.log(1, f"Converted JSON data :::: ", "")
        incoming_payload = json.loads(incoming_data)
        com_code = incoming_payload["comCode"]
        if com_code == app_id:
            # Connect to the server
            if not sio.connected:
                sio.connect(socket_server_url)
                print("===== calling socket server and sending data [57] =====")
                sio.emit("pipeline_event", data)
            else:
                print("===== calling socket server and sending data [70] =====")
                sio.emit("pipeline_event", data)
            # if connected:
            #     print("===== calling socket server and sending data [70] =====")
            #     sio.emit("pipeline_event", data)

            # if sio.connected: # connected

            while connected:
                time.sleep(sleep_time)
            print(f"output in api.py is ${output}")
            sio.disconnect()

            return jsonify(output)
        else:
            return jsonify({"status": "Invalid API code"})

    except Exception as e:
        logging.warning(f"Converted JSON data ::::  {str(e)}")
        return jsonify({"error": str(e)})


@app.route('/health')
def health_check():
    return jsonify({"message": "API is up"})


@app.route('/healthCheck')
def socket_health_check():
    if not sio.connected:
        sio.connect(socket_server_url)
        sio.emit("pipeline_event",
                 {"comCode": app_id, "appProfile": "internal", "requestId": "20000",
                  "messageSource": "healthCheck"})

        logging.log(1, f"==== The API is pinging the socket server ", "")
    while connected:
        time.sleep(5)
    return jsonify(output)


@app.route('/downstream', methods=['POST'])
def process_downstream_request():
    try:
        data = request.get_json()
        print(f"==== downstream request from API CALL {data} ===== connected is {connected}")

        if not sio.connected:
            sio.connect(socket_server_url)
            print(f"The API is sending this JSON data {data} on behalf of the downstream pipeline [85]")
            print("====PENDING EMIT HERE====")
            # sio.emit("pipeline_event", data)
        if connected:
            print(f"The API is sending this JSON data {data} on behalf of the downstream pipeline [88]")
            sio.emit("pipeline_event", data)
            return jsonify({"message": "Downstream was successfully saved! [90]"})

        while connected:  # connected
            time.sleep(5)
        #     sio.disconnect()
        return jsonify({"message": "Downstream was successfully saved!"})
    except Exception as e:
        print(f"Exception occurred with {str(e)}")
        return jsonify({"error": str(e)})


if __name__ == '__main__':
    from waitress import serve

    serve(app, host='0.0.0.0', port=5002)
