#!/bin/bash

python3 api.py