#!/bin/bash

echo "Let's set up your local variables. These values won't be pushed to git you'll find them in app/ and api folders"
app_id=$(cat /dev/urandom | LC_ALL=C tr -dc 'a-zA-Z0-9' | fold -w 36 | head -n 1)
echo "Let's create the variables for the SOCKET container"
rm ./app/.env
echo 'PIPELINE_COM_CODE="'"$app_id"'"' >> ./app/.env
read -r -p "What will be your SOCKET_CONTAINER_NAME: " SOCKET_CONTAINER_NAME
echo 'SOCKET_CONTAINER_NAME="'"$SOCKET_CONTAINER_NAME"'"' >> ./app/.env
read -r -p "Enter your desired DOCKET_NETWORK_NAME: " DOCKET_NETWORK_NAME
echo 'SEC_PIP_DOCKET_NETWORK_NAME="'"$DOCKET_NETWORK_NAME"'"' >> ./app/.env
read -r -p "Enter your desired SEC_SOCKET_SRV_IMAGE: " SEC_SOCKET_SRV_IMAGE
echo 'SEC_SOCKET_SRV_IMAGE="'"$SEC_SOCKET_SRV_IMAGE"'"' >> ./app/.env
read -r -p "Enter your desired SEC_SOCK_CONT_PORT: " SEC_SOCK_CONT_PORT
echo 'SEC_SOCK_CONT_PORT='"$SEC_SOCK_CONT_PORT"'' >> ./app/.env
read -r -p "Enter your desired SEC_HOST_PORT  you must use this port in the Dockerfile in /app: " SEC_HOST_PORT
echo 'SEC_HOST_PORT='"$SEC_HOST_PORT"'' >> ./app/.env


echo "Let's now set the variables for the API container"
rm ./api/.env
echo 'PIPELINE_COM_CODE="'"$app_id"'"' >> ./api/.env
read -r -p "What will be your API_CONTAINER_NAME: " API_CONTAINER_NAME
echo 'API_CONTAINER_NAME="'"$API_CONTAINER_NAME"'"' >> ./api/.env
echo 'SEC_PIP_DOCKET_NETWORK_NAME="'"$DOCKET_NETWORK_NAME"'"' >> ./api/.env
read -r -p "Enter your desired API_SERVER_IMAGE: " SEC_PPL_API_SRV_IMAGE
echo 'SEC_PPL_API_SRV_IMAGE="'"$SEC_PPL_API_SRV_IMAGE"'"' >> ./api/.env
read -r -p "Enter your desired API CONTAINER PORT: " SEC_API_PPL_CONT_PORT
echo 'SEC_API_PPL_CONT_PORT='"$SEC_API_PPL_CONT_PORT"'' >> ./api/.env
read -r -p "Enter your desired API HOST PORT you must use this port in the Dockerfile in /api: " SEC_API_PPL_HOST_PORT
echo 'SEC_API_PPL_HOST_PORT='"$SEC_API_PPL_HOST_PORT"'' >> ./api/.env
echo 'SOCKET_SERVER_URL="http://'$SOCKET_CONTAINER_NAME':'$SEC_SOCK_CONT_PORT'"' >> ./api/.env
