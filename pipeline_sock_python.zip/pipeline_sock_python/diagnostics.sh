#!/bin/bash

network_name="sec_pipeline_network"
port=8002
hostname="localhost"

echo "Troubleshooting is about to start"
echo "Let's check the running docker containers"
docker ps -a
echo "If you can't find your docker container then it means you should build and run it"
echo "Let's see if the API is up and running...."
wget $hostname:$port/
echo "If there is no JSON response it means the api container is not running on port 8002"
echo "Listing containers on the $network_name docker network"
docker network inspect -f '{{json .}}' $network_name | jq -r '.Containers[] | .Name'
echo "if your desired container is missing it means it is not connected to the docker network"
