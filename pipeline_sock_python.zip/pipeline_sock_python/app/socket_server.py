import socketio
import json
import os
import eventlet
import logging
import sys
# from dotenv import load_dotenv
#
# load_dotenv()
#
# app_id = os.getenv("PIPELINE_COM_CODE")
# container_name = os.getenv("SOCKET_CONTAINER_NAME")

app_id = "9NmmVLAG3wYBsiJdmBZN4GDsoH5lxvSC7Kme"


sio = socketio.Server(cors_allowed_origins="*")
app = socketio.WSGIApp(sio)
filename = "data/pipeline_streams.json"
downstream_filename = "data/pipeline_data_residue.json"
prevent_double_entry = False
logging.basicConfig(stream=sys.stdout)


@sio.event
def connect(sid, environ):
    print(f"Client {sid} connected")


@sio.on("pipeline_event")
def handle_pipeline_event(sid, data):
    try:
        print(f"Received data from client {sid}: {data}")
        global prevent_double_entry
        prevent_double_entry = False
        incoming_data = json.dumps(data)
        print(f"Converted JSON data :::: {incoming_data}")
        incoming_payload = json.loads(incoming_data)
        message_source = incoming_payload["messageSource"]
        print(f"The message source is {message_source}")
        upstream_id_in_sec_pipeline = incoming_payload["requestId"]
        logging.warning("====== requestId === is  [32] " + str(upstream_id_in_sec_pipeline))
        app_profile = incoming_payload["appProfile"]
        print(f"app_profile is {app_profile}")
        incoming_payload = json.loads(incoming_data)
        com_code = incoming_payload["comCode"]
        if com_code == app_id:
            if message_source == "upstream":
                try:
                    with open(filename, 'r') as file:
                        content = file.read()
                        if content:
                            with open(filename) as f:
                                json_data = json.load(f)
                                json_data.append(data)
                            with open(filename, 'w') as f:
                                json.dump(json_data, f)
                                print("The payload was successfully updated [56]")
                                # check if the requestId is in the pipeline_data_residue.json
                        else:
                            file_path = os.path.join('', filename)
                            json_object = [data]
                            json_array = json.dumps(json_object)
                            with open(file_path, 'w') as f:
                                f.write(json_array)
                                if os.path.isfile(file_path):
                                    print("The payload was successfully created in the data source")
                    with open(downstream_filename, 'r') as sec_pipeline_file:
                        pending_server_response = sec_pipeline_file.read()
                        print("I just opened the downstream file and I'm about to read it ")
                        if pending_server_response:
                            with open(downstream_filename) as s_file:
                                sec_pipeline_data = json.load(s_file)
                                print("online 49")
                                for sec_json_str in sec_pipeline_data:
                                    sec_json_obj = json.dumps(sec_json_str)
                                    final_json_obj = json.loads(sec_json_obj)
                                    if final_json_obj['requestId'] == upstream_id_in_sec_pipeline and \
                                            final_json_obj['appProfile'] == app_profile:
                                        print(f"The commit id is {upstream_id_in_sec_pipeline} [67]")
                                        pipe_status = final_json_obj['status']
                                        summary = final_json_obj['summary']
                                        sio.emit("message", {"appProfile": f"{app_profile}",
                                                             "requestId": f"{upstream_id_in_sec_pipeline}",
                                                             "status": f"{pipe_status}",
                                                             "summary": f"{summary}",
                                                             "messageSource": "downstream"}, room=sid)
                                        return
                except FileNotFoundError:
                    logging.warning("File not found")
            if message_source == "downstream":
                try:
                    with open(filename, 'r') as f:
                        json_data = json.load(f)
                        for json_str in json_data:
                            converted_obj = json.dumps(json_str)
                            json_obj = json.loads(converted_obj)
                            if json_obj['requestId'] == upstream_id_in_sec_pipeline:
                                if not prevent_double_entry:
                                    try:
                                        with open(downstream_filename, 'r') as downstream_file:
                                            downstream_content = downstream_file.read()
                                            print(f"WHAT IS THIS ---====++++ ${downstream_content}")
                                            print("+++++++ Opening downstream file +++++++++++++++")
                                            if downstream_content:
                                                print("+++++++ downstream_content +++++++++++++++")
                                                with open(downstream_filename) as fr:
                                                    current_data = json.load(fr)
                                                    current_data.append(data)
                                                    print(f"==== Appended data === [96] ")
                                                    logging.log(1, f"==== Appended data === [97] ", "")
                                                    print("+++++++ downstream_filename 101 +++++++++++++++")
                                                with open(downstream_filename, 'w') as spf:
                                                    json.dump(current_data, spf)
                                                    print(
                                                        f"==== The payload was successfully updated === [97] === ["f"100.100] ")
                                                    logging.log(1,
                                                                f"==== The payload was successfully updated === [97] ",
                                                                "")
                                                    print("The payload was successfully updated")
                                                    prevent_double_entry = True
                                                    # sio.emit("message", data, room=sid)
                                            else:
                                                print("THE FILE IS EMPTY")
                                                sec_file_path = os.path.join('', downstream_filename)
                                                sec_json_object = [data]
                                                sec_json_array = json.dumps(sec_json_object)
                                                with open(sec_file_path, 'w') as sf:
                                                    sf.write(sec_json_array)
                                                    if os.path.isfile(sec_file_path):
                                                        print(
                                                            "The payload was successfully created in the residue file")
                                    except Exception as ee:
                                        print(f"====downstream_file exception ${ee} =====")
                                if prevent_double_entry:
                                    sec_file_path = os.path.join('', downstream_filename)
                                    sec_json_object = [data]
                                    sec_json_array = json.dumps(sec_json_object)
                                    with open(sec_file_path, 'w') as sf:
                                        sf.write(sec_json_array)
                                        if os.path.isfile(sec_file_path):
                                            print("The payload was successfully created in the residue file")
                except Exception as e:
                    print(f"Exception ==++++100.1119 ${e} ===")
                # print(f"I am emitting ${data}")
                sio.emit("message", data, room=sid)
            if message_source == "healthCheck":
                logging.warning("====== healthCheck === is  [111] Server is up")
                sio.emit("message", {"server_status": "The socket server is up"}, room=sid)
        else:
            print("Invalid API code")
            sio.emit("message", {"message": "The client called this service with an invalid API_ID"}, room=sid)
    except Exception as e:
        print(f"Exception is {e}")

if __name__ == "__main__":
    eventlet.wsgi.server(eventlet.listen(("0.0.0.0", 5000)), app)
