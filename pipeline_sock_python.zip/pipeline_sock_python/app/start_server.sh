#!/bin/bash

python3 -m venv

source venv/bin/activate

echo "TRYING TO TUN PYTHON3"

python socket_server.py