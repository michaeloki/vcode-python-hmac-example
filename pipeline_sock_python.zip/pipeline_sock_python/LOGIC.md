## Handling drop-offs
- In the upstream section of the socket_server, check if the pipelineId is in the pipeline_data_residue.json [do this in the socket_server.py file]
- If the pipelineId is in the pipeline_data_residue.json file, return the result immediately
- Else save the upstream request in pipeline_streams.json as usual