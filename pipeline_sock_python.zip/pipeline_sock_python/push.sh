#!/bin/bash

echo "This Gitlab Runner is fine"
#docker images
echo "Checking the docker status..."

SEC_SOCKET_SRV_IMAGE=$1
SEC_PPL_API_SRV_IMAGE=$2
echo "The variables I got are $SEC_SOCKET_SRV_IMAGE and $SEC_PPL_API_SRV_IMAGE"
 cd upload || return
 chmod +x ./socket_dockerise.sh
 chmod +x ./api_dockerise.sh
 echo "Calling socket_dockerise with these files"
 rc-service docker
 docker images
 sh socket_dockerise.sh "$SEC_SOCKET_SRV_IMAGE"
 sh api_dockerise.sh "$SEC_PPL_API_SRV_IMAGE"
