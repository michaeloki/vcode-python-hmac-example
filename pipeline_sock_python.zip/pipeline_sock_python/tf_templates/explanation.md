Explanation
Variables: Holds the necessary inputs such as AWS account ID, region, GitLab OIDC provider, GitLab project ID,
and CodeBuild project name. Provider: Configures the AWS provider to use the specified region.
IAM Role: Creates an IAM role with a trust relationship allowing GitLab to assume the role using OIDC.
IAM Policy: Defines a policy granting necessary permissions to interact with AWS CodeBuild.
Policy Attachment: Attaches the created policy to the IAM role.
Output: Provides the ARN of the created IAM role. 
This Terraform template ensures that the IAM role is created with the correct trust relationship and permissions to
allow GitLab to start AWS CodeBuild projects.