#!/bin/bash

network_name="sec_pipeline_network"

socket_server_container="security_pipeline_integration"
api_server_container="security_pipeline_api"

api_image="security_api_server_image"
socket_image="socket_server_image"
#docker stop $socket_server_container
#docker stop api_server_container
#docker container rm $socket_server_container
#docker container rm $api_server_container
docker rm -f $socket_server_container
docker rm -f $api_server_container
docker rmi $api_image
docker rmi $socket_image
docker network rm $network_name
