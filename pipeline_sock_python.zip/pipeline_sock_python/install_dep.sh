#!/bin/bash

cd api || return
pip3 install -r requirements.txt
cd app || return
pip3 install -r requirements.txt

# Check if yum is available
if hash yum 2>/dev/null; then
    echo "Installing deps using yum..."
    sudo yum install epel-release
    sudo yum install jq
    yum install wget
   #  sudo yum install -y aws-cli
else
    # Try with apt-get if yum is not available
    if hash apt-get 2>/dev/null; then
        echo "Installing deps using apt-get..."
        sudo apt-get update
        # sudo apt-get install -y awscli
        sudo apt-get install jq -y
        sudo apt-get install wget -y
    elif hash apt 2>/dev/null; then
        echo "Installing deps using apt..."
        apt update
        apt install jq -y
        apt install wget
        # sudo apt install -y awscli
    elif hash brew 2>/dev/null; then
        echo "Installing deps using homebrew..."
        # brew install awscli
        brew install wget
        brew install jq
    else
        echo "No package manager found to install dependencies."
    fi
fi