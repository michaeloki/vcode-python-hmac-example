# Pipeline Socket Integration
This web socket project is a bridge between the upstream and downstream pipelines. 
It manages the bidirectional communication between the two entities.
This approach was chosen because real-time response is needed by the concurrent pipelines that will connect to the API 
for the enforcement of hard-blocking.

# Overview
The upstream (developer) pipeline triggers the downstream (security) pipeline via a "security template".
A CURL request (inside the security template) is made to the flask API of this project which connects to a web socket
for the sake of real-time delivery of responses and concurrency. The security pipeline sends a JSON response to the API 
and the web socket "notifies" the upstream pipeline by sending a response via the API.

# Local Setup
- Install docker desktop on your machine
- Set your python interpreter to 3.9 in your IDE for your virtual environment.
- Choose .venv in your IDE or create a virtual environment. This is very important.
- Open a terminal and run `sh install_dep.sh`
- Open a terminal and run `sh local_var_setup.sh` and follow the prompts 
- Open a terminal and run `sh local_socket_dockerise.sh` on your machine to start the socket server
- Open a terminal and run `sh local_api_dockerise.sh` to start the API on your machine 
- The socket server must be up before starting the API, otherwise the POST requests from the client (pipelines) won't fire
- Navigate to the client folder and run `sh sec_template_curl.sh`. This makes a synchronous request by calling the API.
- Run `sh sec_pipeline_curl.sh` . Ensure the requestId matches the one you entered in `sec_template_curl.sh` 
- The JSON object in `sh sec_pipeline_curl.sh` serves as the response for the request made by `sec_template_curl.sh` 

# Local Debugging
- Install python3 on your laptop
- Open a terminal and run `sh system_setup.sh`
- Open a terminal and run `pip3 install -r requirements.txt` in the `app` and `api` folders
- Edit the value of `PIPELINE_COM_CODE` in `app/api.py` and `api/socket_server.py`
- Open a terminal and run `python3 app/socket_server.py`
- Open a terminal and run `python3 api/api/py`
- Edit the value of `requestId` in `app/api.py` and `api/socket_server.py`. The two files must have the same `requestId`
- Navigate to the `client` folder and run `sh sec_template_curl.sh && sh sec_pipeline_curl.sh`

# Production
- Push the code to the main branch
- Ensure the socket and API containers are connected to the same docker network of the security and upstream pipelines.
- Call http://your-container-name:8002/healthCheck to confirm the API is connected to the socket server.
- Call http://your-container-name:8002/ to confirm the API is up and running.
- Run `sudo systemctl status pipeline-monitor.service` to view the status of the deployment directory watcher.
- Run `sudo systemctl daemon-reload && sudo systemctl restart pipeline-monitor.service` if you make changes to the file_watcher script
# Troubleshooting
- If the API fails to connect to the socket server run `sh diagnostics.sh`
