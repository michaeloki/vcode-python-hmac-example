#!/bin/bash

while IFS= read -r var name; do
  declare "$var"
done < ./app/.env

SOCKET_CONTAINER_NAME=$(echo $SOCKET_CONTAINER_NAME | tr -d '"')
SEC_PIP_DOCKET_NETWORK_NAME=$(echo $SEC_PIP_DOCKET_NETWORK_NAME | tr -d '"')
SEC_SOCKET_SRV_IMAGE=$(echo $SEC_SOCKET_SRV_IMAGE | tr -d '"')
SEC_SOCK_CONT_PORT=$(echo $SEC_SOCK_CONT_PORT | tr -d '"')
SEC_HOST_PORT=$(echo $SEC_HOST_PORT | tr -d '"')

echo "Relax while we create a docker container for the socket"
#cd app || return
#pwd
#ls

echo "SOCKET_CONTAINER_NAME is $SOCKET_CONTAINER_NAME"
echo "SEC_PIP_DOCKET_NETWORK_NAME is $SEC_PIP_DOCKET_NETWORK_NAME"
echo "SEC_SOCKET_SRV_IMAGE IS $SEC_SOCKET_SRV_IMAGE"
echo "SEC_SOCK_CONT_PORT is $SEC_SOCK_CONT_PORT"
echo "SEC_HOST_PORT is $SEC_HOST_PORT"
docker build -t $SEC_SOCKET_SRV_IMAGE app
echo "The docker image is about to run"
docker run -d --name $SOCKET_CONTAINER_NAME -p $SEC_HOST_PORT:$SEC_SOCK_CONT_PORT $SEC_SOCKET_SRV_IMAGE
docker network create $SEC_PIP_DOCKET_NETWORK_NAME
docker network connect $SEC_PIP_DOCKET_NETWORK_NAME $SOCKET_CONTAINER_NAME
echo "List of containers connected to $SEC_PIP_DOCKET_NETWORK_NAME "
docker network inspect -f '{{json .}}' $SEC_PIP_DOCKET_NETWORK_NAME | jq -r '.Containers[] | .Name'
