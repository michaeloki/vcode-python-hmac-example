#!/bin/bash

ACCESS_KEY_ID=$ACCESS_KEY_ID
SECRET_ACCESS_KEY=$SECRET_ACCESS_KEY

AWS_DEFAULT_REGION=$AWS_DEFAULT_REGION
ECR_URL=$AWS_ECR_URI

LOGIN_PASSWD=$(aws ecr get-login-password --region $AWS_DEFAULT_REGION)

AUTH=$(echo -n "$ECR_URL:$LOGIN_PASSWD" | base64)

cat <<EOF > docker-config.json
{
 "auths": {
   "$ECR_URL": {
     "auth": "$AUTH"
   }
 }
}
EOF

echo "Docker login config created: docker-config.json"
