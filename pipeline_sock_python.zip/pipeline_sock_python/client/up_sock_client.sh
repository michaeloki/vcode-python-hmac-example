#!/bin/bash


# Make the POST request
requestId="7776543348608" # requestId COMMIT_SHA
PIPELINE_COM_CODE="YX3mbZL@LVMBMvIT1fRwIgztz@7Pe8QFbC" #Exclude this in the upstream pipeline
function sendRequest() {
response=$(curl -k -X POST -H "Content-Type: application/json" -d '{"comCode": "'$PIPELINE_COM_CODE'","appProfile": "merchant-portal-srv-1", "requestId": "'$requestId'", "messageSource": "upstream"}' https://localhost/app2/api)
echo "$response"
pipeline_status=$(echo "$response" | grep -o '"status":"[^"]*' | grep -o '[^"]*$')
commitId=$(echo "$response" | grep -o '"requestId":"[^"]*' | grep -o '[^"]*$')
echo "What is the status ??? $pipeline_status and the ID is $requestId"
if [ "$commitId" == "$requestId" ]; then
  if [ "$pipeline_status" == "PASS" ] ; then
    echo "Successful Scan"
    exit 0
  fi
  if [ "$pipeline_status" == "FAIL" ] ; then
    echo "Failed Scan"
    exit 1
  fi
  if [ "$pipeline_status" == "Invalid API code" ] ; then
    echo "Invalid "
    exit 1
  fi
fi
if [ "$response" != "" ] && [ "$commitId" != "$requestId" ] ; then
    sendRequest
fi
}
# server_response=sendRequest
#status=$?
#if [ $status -ne 0 ]; then
#  echo "Error $status occurred"
#fi
sendRequest




#pipeline_status=$(echo "$response" | grep -o '"status":"[^"]*' | grep -o '[^"]*$')
#pipelineId=$(echo "$response" | grep -o '"pipelineId":"[^"]*' | grep -o '[^"]*$')
#echo "What is the status ??? $pipeline_status"
#if [ "$pipelineId" == "$requestId" ]; then
#  if [ "$pipeline_status" == "PASS" ] ; then
#    echo "Successful Scan"
#    exit 0
#  fi
#  if [ "$pipeline_status" == "FAIL" ] ; then
#    echo "Failed Scan"
#    exit 1
#  fi
#  else
#    echo "run again"
#fi



#your_code() {
#  # Your code here
#  calc=$((2+2))
#  echo "calc answer is $calc"
#  return $calc
#}

#
#
#
#
#status=$?
#[ $status -ne 0 ] && echo "Scan failed" && stop_feedback "${scan_output}" "$scanTypeMsg"
#
#if your_code; then
#  echo "Success"
#else
#  echo "Error occurred, handling error..."
#  # Handle the error here
#  status=$?
#  if [ $status -ne 0 ]; then
#    echo "Error $status occurred"
#  fi
#fi


# Parse the JSON object and check the status here

## Check if the request was successful (status code 200)
#if [ "$response" == "200" ]; then
#  data=$(curl -s http://localhost:5001/api)
#  echo "Server data is $data"
#fi