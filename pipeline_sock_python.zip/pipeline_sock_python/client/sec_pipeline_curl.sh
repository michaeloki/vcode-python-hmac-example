#!/bin/bash

while IFS= read -r var name; do
  declare "$var"
done < ../app/.env

requestId="7776543348612"
echo "Ensure the requestId of $requestId is also in the sec_template_curl.sh file"
PIPELINE_COM_CODE=$(echo $PIPELINE_COM_CODE | tr -d '"')
response=$(curl -k -X POST -H "Content-Type: application/json" -d '{"comCode": "'$PIPELINE_COM_CODE'","appProfile": "merchant-portal-srv-1", "requestId": "'$requestId'", "status": "PASS", "summary": "No issues!", "messageSource": "downstream"}' https://localhost/app2/downstream)
echo "$response"
