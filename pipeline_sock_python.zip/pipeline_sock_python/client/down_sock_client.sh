#!/bin/bash

requestId="7776543348608"
PIPELINE_COM_CODE="YX3mbZL@LVMBMvIT1fRwIgztz@7Pe8QFbC" #This should come from Gitlab



response=$(curl -X POST -H "Content-Type: application/json" -d '{"comCode": "'$PIPELINE_COM_CODE'","appProfile": "merchant-portal-srv-1", "requestId": "'$requestId'", "status": "PASS", "summary": "No issues!", "messageSource": "downstream"}' http://127.0.0.1:8002/downstream)
echo "$response"
# Make the POST request
#response=$(curl -X POST -H "Content-Type: application/json" -d '{"comCode": "777654334838", "appProfile": "merchant-portal-srv-1", "pipelineId": "777654334838", "status": "PASS"}' http://localhost:5001/downstream)
# "'"$requestId" '"
#response=$(curl -X POST -H "Content-Type: application/json" -d '{"appProfile": "merchant-portal-srv-1", "pipelineId":  "'$requestId'", "status": "PASS", "summary": "No issues!", "messageSource": "'"$messageSource"'"}' http://localhost:333
# Now, $response contains the server's response
#echo "$response"

# Check if the status is successful
## Check if the request was successful (status code 200)
#if [ "$response" == "200" ]; then
#  # If successful, fetch the data
#  data=$(curl -s http://localhost:5001/api)
#  echo "Downstream Server data is $data"
#fi