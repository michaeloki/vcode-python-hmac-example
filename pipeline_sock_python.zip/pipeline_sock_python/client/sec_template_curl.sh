#!/bin/bash

while IFS= read -r var name; do
  declare "$var"
done < ../api/.env

requestId="7776543348612"
PIPELINE_COM_CODE=$(echo $PIPELINE_COM_CODE | tr -d '"')
function sendRequest() {
response=$(curl -X POST -H "Content-Type: application/json" -d '{"comCode": "'$PIPELINE_COM_CODE'","appProfile": "merchant-portal-srv-1", "requestId": "'$requestId'", "messageSource": "upstream"}' https://localhost/api)
echo "$response"
pipeline_status=$(echo "$response" | grep -o '"status":"[^"]*' | grep -o '[^"]*$')
commitId=$(echo "$response" | grep -o '"requestId":"[^"]*' | grep -o '[^"]*$')
echo "What is the status ??? $pipeline_status and the ID is $requestId"
if [ "$commitId" == "$requestId" ]; then
  if [ "$pipeline_status" == "PASS" ] ; then
    echo "Successful Scan"
    exit 0
  fi
  if [ "$pipeline_status" == "FAIL" ] ; then
    echo "Failed Scan"
    exit 1
  fi
  if [ "$pipeline_status" == "Invalid API code" ] ; then
    echo "Invalid "
    exit 1
  fi
fi
if [ "$response" != "" ] && [ "$commitId" != "$requestId" ] && [ "$pipeline_status" != "Invalid API code" ] ; then
    sendRequest
fi
}
sendRequest
