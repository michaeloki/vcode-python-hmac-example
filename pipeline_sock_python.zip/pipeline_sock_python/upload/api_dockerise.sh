#!/bin/bash

SEC_PPL_API_SRV_IMAGE=$1
echo "Relax while we create a docker container for the API server in PRODUCTION"
cd ../api || return
pwd
echo "About to create a docker build"
docker build -t $SEC_PPL_API_SRV_IMAGE .
