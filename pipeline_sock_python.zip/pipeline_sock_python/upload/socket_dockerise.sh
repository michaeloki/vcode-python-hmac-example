#!/bin/bash

SEC_SOCKET_SRV_IMAGE=$1
echo "Relax while we create a docker container for the socket server in PRODUCTION"
cd ../app || return
pwd
echo "About to create a docker build"
echo "Listing all files in this dir...... $(ls)"
echo "IMAGE NAME IS $SEC_SOCKET_SRV_IMAGE"
docker build -t "socket-image" .
echo "....Show containers..."
docker ps
docker info
#docker build -t $SEC_SOCKET_SRV_IMAGE .
