#!/bin/bash

while IFS= read -r var name; do
  declare "$var"
done < ./api/.env

SEC_PPL_API_CONTAINER_NAME=$(echo $API_CONTAINER_NAME | tr -d '"')
SEC_PIP_DOCKET_NETWORK_NAME=$(echo $SEC_PIP_DOCKET_NETWORK_NAME | tr -d '"')
SEC_PPL_API_SRV_IMAGE=$(echo $SEC_PPL_API_SRV_IMAGE | tr -d '"')
SEC_API_PPL_CONT_PORT=$(echo $SEC_API_PPL_CONT_PORT | tr -d '"')
SEC_API_PPL_HOST_PORT=$(echo $SEC_API_PPL_HOST_PORT | tr -d '"')


echo "Relax while we create a docker container for the API"
cd api || return
docker build -t $SEC_PPL_API_SRV_IMAGE .
docker run -d --name $SEC_PPL_API_CONTAINER_NAME -p $SEC_API_PPL_HOST_PORT:$SEC_API_PPL_CONT_PORT $SEC_PPL_API_SRV_IMAGE
docker network connect $SEC_PIP_DOCKET_NETWORK_NAME $SEC_PPL_API_CONTAINER_NAME
echo "List of containers connected to $SEC_PIP_DOCKET_NETWORK_NAME"
docker network inspect -f '{{json .}}' $SEC_PIP_DOCKET_NETWORK_NAME | jq -r '.Containers[] | .Name'
