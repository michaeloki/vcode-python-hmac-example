#!/usr/bin/env node

import generator from './generate-truststore.js';
import minimist from 'minimist';
let instruction = parseCliOpts();
import moment from 'moment';

generator.readCsv(instruction.ca_csv_path).then(entries => {
    let cas_present_in_bundle;
    let pem_bundle_certs;
    let prom = generator.readPemFile(instruction.pemfile_path).then(pem_certs => {
        pem_bundle_certs = pem_certs;
        // Only keep certificates that are also present in CA bundle, to keep them aligned.
        cas_present_in_bundle = entries.filter(ca_entry => {return pem_bundle_certs.has(ca_entry['SHA-256 Fingerprint'])});
    }, e => {throw e})

    prom.then(() => {
        // Filter on compliance.
        let assessed_cas = generator.assessEntriesOnRules(cas_present_in_bundle);

        // If already have tracking data, use it.
        let existing_cas = null;
        let read_status_prom = generator.readAssessedCaFile(instruction.ca_status_file).then(existing_cas_from_file => {
            existing_cas = existing_cas_from_file;
        }, error => {
            console.log(`Unable to read existing CA's from ${instruction.ca_status_file}:\n${error}`);
        });

        Promise.allSettled([read_status_prom]).then(() => {
            generator.mergeCategorizeAssessedCaMaps(existing_cas, assessed_cas).then(result => {

                // Only proceed if changes detected.
                if (!result.added.size && !result.removed.size) {
                    console.log('No changes detected compared to current status.');
                    if (instruction.force_generate) {
                        console.log('--force-generate given, proceeding');
                    } else {process.exit(2);}
                }

                generator.writeAssessedCaFile(result.result_combined, instruction.ca_status_file).then(() => {}, e => {throw e});

                // Generate bundle file.
                let distilled_certs = generator.filterCaBundleByCertMap(result.not_violating, pem_bundle_certs);
                let ca_bundle = generator.certificatesToPemBundle(distilled_certs);
                generator.writeFile(instruction.ca_bundle_output_file, ca_bundle).then(path => {
                    console.log(`Wrote distilled CA bundle into [${path}]`)}, e => {throw e});

                // Generate markdown report output.
                if (instruction.markdown_report_output_file) {
                    let table_fields_compliant = {
                        'Owner': 'ca.Owner',
                        'Certificate Issuer Organization': 'ca.Certificate Issuer Organization',
                        'Common Name or Certificate Name': 'ca.Common Name or Certificate Name',
                        'Geographic Focus': 'ca.Geographic Focus',
                        'Valid To': 'ca.Valid To [GMT]',
                        'SHA-256 Fingerprint': 'ca.SHA-256 Fingerprint'
                    }
                    let markdown_table_compliant = generator.renderCaMap(result.not_violating, 'markdown-table', table_fields_compliant);

                    let table_fields_non_compliant = {
                        'Owner': 'ca.Owner',
                        'Certificate Issuer Organization': 'ca.Certificate Issuer Organization',
                        'Common Name or Certificate Name': 'ca.Common Name or Certificate Name',
                        'Geographic Focus': 'ca.Geographic Focus',
                        'Valid To': 'ca.Valid To [GMT]',
                        'Violation': 'violating_rule',
                        'SHA-256 Fingerprint': 'ca.SHA-256 Fingerprint'
                    }
                    let markdown_table_non_compliant = generator.renderCaMap(result.violating, 'markdown-table', table_fields_non_compliant);
                    generator.writeFile(instruction.markdown_report_output_file, renderMarkdownReport(markdown_table_compliant, markdown_table_non_compliant)).then(path => {
                        console.log(`Wrote markdown report into [${path}]`)}, e => {throw e});
                }

                // CLI output.
                console.log(`Violating CA's:\n${generator.renderCaMap(result.violating, 'cli-violating-rules')}`);
                if (result.removed.size) {
                    console.log(`Removed CA's from list: \n${generator.renderCaMap(result.removed, 'cli')}\n\n`);
                }
                if (result.added.size) {
                    console.log(`Added CA's to list: \n${generator.renderCaMap(result.added, 'cli')}\n\n`);
                }

            }, e => {throw e})
        })
    })

}, e => {throw e})

function parseCliOpts() {
    let argv = minimist(process.argv.slice(2));

    // Mozilla's certdata file resulting PEM file.
    if (!argv.pemfile) {
        showHelpExit('Flag --pemfile missing');
    }
    let pemfile = argv.pemfile;

    // Mozilla's CA overview CSV file.
    if (!argv['ca-csv']) {
        showHelpExit('Flag --ca-csv missing');
    }
    let ca_csv = argv['ca-csv'];

    // CA status JSON file.
    let ca_status_file = 'ca_list.json';
    if (argv['ca-status-file']) {
        ca_status_file = argv['ca-status-file'];
    } else {
        console.log(`--ca-status-file not provided, will assume ${ca_status_file} to track changes`);
    }

    // CA bundle output file (PEM)
    let ca_bundle_output_file = 'ca_bundle_generated.pem';
    if (argv['ca-bundle-output']) {
        ca_bundle_output_file = argv['ca-bundle-output'];
    } else {
        console.log(`--ca-bundle-output not provided, will assume ${ca_bundle_output_file} to output PEM bundle`);
    }

    // Force generate.
    let force_generate = (argv['force-generate']);

    return {
        /** @type String */
        pemfile_path: pemfile,

        /** @type String */
        ca_csv_path: ca_csv,

        /** @type String */
        ca_status_file: ca_status_file,

        /** @type String */
        ca_bundle_output_file: ca_bundle_output_file,

        /** @type String */
        markdown_report_output_file: argv['markdown-report'],

        /** @type Boolean */
        force_generate: force_generate,
    }
}

function showHelpExit(issue = null) {
    let template = `This utility can parse a Mozilla generated CA CSV file from\n` +
        `  > https://ccadb-public.secure.force.com/mozilla/IncludedCACertificateReportCSVFormat ,\n` +
        `and distill Ca's from it that comply with the rules in [ca-rules.js].\n` +
        `After that it will parse a CA (PEM) bundle file, generated with Curl's [mk-ca-bundle.pl],\n` +
        `and distill from it the compliant CA's, to generate a new bundle file and Java truststore.\n\n` +
        `Provide the following parameters:\n` +
        `  --pemfile:       resulting PEM CA bundle from [mk-ca-bundle.pl].\n` +
        `  --ca-csv:  Mozilla's CSV with all CAs. See https://wiki.mozilla.org/CA/Included_Certificates  > Included CA Certificates (CSV).\n` +
        `  --ca-status-file:     (optional) file to track changes. Defaults to [ca_list.json] .\n` +
        `  --ca-bundle-output:    (optional) distilled CA bundle, PEM format. Defaults to [ca_bundle.pem]\n` +
        `  --markdown-report :   (optional) filepath to output markdown report in.\n` +
        `  --force-generate:     (optional) generate all output, even if no changes are present.\n\n` +

        `Exit status codes:\n` +
        ` - 0: generated new set\n` +
        ` - 1: error\n` +
        ` - 2: no changes\n`
    ;

    if (issue) console.log(`Error: ${issue}\n\n`);
    console.log(template);
    process.exit(1);
}

function renderMarkdownReport(table_compliant, table_non_compliant) {
    return `# CA truststore overview\n\n` +
        `_Generated: ${moment().format()}_\n\n` +
        `## Compliant CA's\n` +
        `${table_compliant}\n\n` +
        `## Non compliant CA's\n\n` +
        `${table_non_compliant}\n\n`;
}