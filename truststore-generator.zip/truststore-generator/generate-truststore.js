import fs from 'fs';
import csv_parser from 'csv-parser';
import { strict as assert } from 'assert';
import moment from 'moment';
import rules from './ca-rules.js';
import {Certificate} from '@fidm/x509';
import crypto from 'crypto'

export default {

    readCsv: function(filepath) {
        return new Promise((resolve, reject) => {
            let entries = [];
            fs.createReadStream(filepath)
                .pipe(csv_parser())
                .on('data', (entry) => {
                    try {entries.push(new this.CaEntry(entry))}
                    catch(e) {
                        console.error(`CSV entry [${entry['Owner']}/SHA256: ${entry['SHA-256 Fingerprint']}] malformed. Skipping.`);
                    }
                })
                .on('error', error => {reject(`Problem parsing CSV [${filepath}]:\n${error}`)})
                .on('end', () => {
                    if (entries.length) {
                        resolve(entries);
                    } else {
                        reject(`No entries ?!`);
                    }
                });
        })
    },

    /**
     *
     * @param {Array<CaEntry>} entries
     * @return {Map<AssessedCaEntry>}
     *   Map of AssessedCaEntry objects, keyed by SHA256 hash.
     */
    assessEntriesOnRules: function(entries) {
        let assessed = new Map();
        entries.forEach(entry => {
            let assesed_ca = new this.AssessedCaEntry(entry, true, null);
            try {
                rules.dateValidity(entry);
                rules.geographical_focus(entry);
                rules.trustBits(entry);
                rules.noAppliedConstraints(entry);
                rules.blockList(entry);

                // Add entry as non-violating.
                assesed_ca.violating = false;
            } catch(e) {
                // Add violating entry.
                assesed_ca.violating = true;
                assesed_ca.violating_rule = `${e.message} (${e.actual})`;
            }
            assessed.set(entry['SHA-256 Fingerprint'], assesed_ca);
        })
        return assessed;
    },

    /**
     *
     * @param {Map<AssessedCaEntry>} entries
     * @param {string} filepath
     */
    writeAssessedCaFile: function(entries, filepath) {
        return new Promise((resolve, reject) => {
            // Remove Map key, marshall Moment fields.
            let array_form = Array.from(entries.entries(), map_value => {
                let value = map_value[1];
                let clone_entry = new this.AssessedCaEntry(Object.assign({}, value.ca), value.violating, value.violating_rule);

                // Marshal date fields. Assume Moment types.
                ['Valid From [GMT]', 'Valid To [GMT]', 'Distrust for TLS After Date'].forEach(field => {
                    clone_entry.ca[field] = (clone_entry.ca[field]) ? clone_entry.ca[field].format('YYYY.MM.DD') : null;
                })
                clone_entry.removed_date = (clone_entry.removed_date) ? clone_entry.removed_date.format('YYYY.MM.DD') : null;

                return clone_entry;
            })

            this.writeFile(filepath, JSON.stringify(array_form)).then(resolve, reject);
        });
    },

    /**
     *
     * @param {Map<AssessedCaEntry>} entries_existing
     * @param {Map<AssessedCaEntry>} entries_fresh
     * @return {MergedCaListOutput}
     *   Key-sorted maps of CA entries.
     */
    mergeCategorizeAssessedCaMaps: function(entries_existing, entries_fresh) {
        entries_existing = (entries_existing) ? entries_existing : new Map();

        let result_map = new Map();
        let removed_map = new Map();
        let added_map = new Map();
        return new Promise(resolve => {
            entries_fresh.forEach((ca_entry, sha256) => {
                if (entries_existing.has(sha256)) {
                    let existing = entries_existing.get(sha256);
                    if (ca_entry.violating && existing.violating) {
                        // Update removed date.
                        ca_entry.removed_date = existing.removed_date;
                    } else if (!ca_entry.violating && existing.violating) {
                        // Re-add!
                        added_map.set(sha256, ca_entry);
                    } else if (ca_entry.violating && !existing.violating) {
                        // Remove!
                        removed_map.set(sha256, ca_entry);
                    }
                } else if (!ca_entry.violating) {
                    // Didn't exist earlier and is not violating. Added!
                    added_map.set(sha256, ca_entry);
                }
                result_map.set(sha256, ca_entry);
            });

            // Scan old entries to keep them on the list for historical purpose,
            // and also mark them 'removed' if they don't appear in the new list.
            entries_existing.forEach((ca_entry, sha256) => {
                if (!result_map.has(sha256)) {
                    // Make sure it's marked violating.
                    ca_entry.violating_rule = `CA must be on current Mozilla list`;
                    if (!ca_entry.violating) {
                        ca_entry.violating = true;
                        ca_entry.removed_date = moment();
                        removed_map.set(sha256, ca_entry);
                    }
                    result_map.set(sha256, ca_entry);
                }
            });

            // Compose result object, sort everything.
            let result = new this.MergedCaListOutput();
            result.result_combined = new Map([...result_map].sort((a, b) => String(a[0]).localeCompare(b[0])));
            result.removed = new Map([...removed_map].sort((a, b) => String(a[0]).localeCompare(b[0])));
            result.added = new Map([...added_map].sort((a, b) => String(a[0]).localeCompare(b[0])));
            result.not_violating = new Map([...result_map].filter((a, b) => {return (!a[1].violating)}));
            result.violating = new Map([...result_map].filter((a, b) => {return (a[1].violating)}));
            resolve(result);
        });
    },

    /**
     *
     * @param {string} filepath
     * @return {Promise<Map<AssessedCaEntry>>}
     */
    readAssessedCaFile: function(filepath) {
        return new Promise((resolve, reject) => {
            let assessedCas = new Map();
            fs.promises.readFile(filepath, 'utf8')
                .then(content => {
                    let array_entries;
                    try {
                        array_entries = JSON.parse(content);
                    } catch (e) {
                        array_entries = [];
                    }
                    array_entries.forEach(entry => {
                        // Unmarshal date fields. Assume Moment types.
                        entry.removed_date = (entry.removed_date) ? moment.utc(entry.removed_date, "DD-MM-YYYY") : null;
                        let ca = new this.CaEntry(entry.ca, false);
                        assessedCas.set(entry.ca['SHA-256 Fingerprint'],
                            new this.AssessedCaEntry(ca, entry.violating, entry.violating_rule, entry.removed_date));
                    });
                    resolve(assessedCas);
                }, reject);
        });
    },

    /**
     * @param {String} filepath
     * @param {string | Uint8Array} content
     * @return {Promise<String>}
     *   Resolving with filepath, rejecting with message.
     */
    writeFile: function(filepath, content) {
        return new Promise((resolve, reject) => {
            fs.promises.writeFile(filepath, content)
                .then(() => {
                    resolve(filepath);
                })
                .catch(() => {
                    reject(`Unable to write report into ${filepath}`);
                });
        })
    },

    /**
     * Return the intersection (present in both) of 'ca_map' and 'certificates'.
     *
     * @param {Map<AssessedCaEntry>} ca_map
     * @param {Map<String, CertFromPem>} certificates from PEM file
     * @return {Map<String,CertFromPem>}
     *   Certificates from bundle, filtered by map entries.
     */
    filterCaBundleByCertMap: function(ca_map, certificates) {
        let result = new Map();
        certificates.forEach((cert, fingerprint) => {
            if (ca_map.has(fingerprint)) {
                result.set(fingerprint, cert);
            }
        })
        return result;
    },

    /**
     * PEM bundle to certs.
     * @param {string} filepath
     * @return {Map<String, CertFromPem>}
     */
    readPemFile: function(filepath) {
        return new Promise((resolve, reject) => {
            fs.promises.readFile(filepath, 'utf8')
                .then(content => {
                    let certPems = [];
                    let lines = content.split(/\r?\n/g);
                    let certPem = '';
                    lines.forEach(line => {
                        line = line.trim();
                        if (line.match(/-BEGIN CERTIFICATE-/)) {
                            certPem = line; // reset.
                        } else if (line.match(/-END CERTIFICATE-/)) {
                            certPem += '\n' + line;
                            certPems.push(certPem);
                            certPem = ''; // reset.
                        } else if (line !== '' || certPem !== '') {
                            certPem += '\n' + line;
                        }
                    });

                    let certs = new Map();
                    certPems.forEach(certPem => {
                        let cert = new this.CertFromPem(certPem);
                        certs.set(this.certFingerprint(cert), cert);
                    })

                    resolve(certs);
                }, reject);
        });
    },

    /**
     * @param {CertFromPem} cert
     * @return {string}
     */
    certFingerprint: function(cert) {
        return crypto.createHash('sha256').update(cert.certificate.raw).digest('hex').toUpperCase();
    },

    /**
     * @param {Map<String,CertFromPem>} certificates
     * @return string
     */
    certificatesToPemBundle: function(certificates) {
        let pems = [];
        certificates.forEach((cert, fingerprint) => {
            let OUName_atr = cert.certificate.subject.attributes.find(a => a.name === 'organizationalUnitName');
            let OUName = (OUName_atr) ? OUName_atr.value : '-';
            let OName_atr = cert.certificate.subject.attributes.find(a => a.name === 'organizationName');
            let OName = (OName_atr) ? OName_atr.value : '-';
            let CN_atr = cert.certificate.subject.attributes.find(a => a.name === 'commonName');
            let CN = (CN_atr) ? CN_atr.value : '-';
            let pem = `# O: ${OName}\n` +
                `# OU: ${OUName}\n` +
                `# CN: ${CN}\n` +
                `# Fingerprint: ${fingerprint}\n` +
                '# ====\n' +
                cert.pem;
            pems.push(pem);
        });

        return pems.join('\n\n');
    },

    /**
     * @param {Map<String,AssessedCaEntry>} ca_map
     * @param {String} format
     *   Options: cli, cli-violating-rules, markdown-table
     * @param {Object<String>} fields
     *   For markdown tables, fields to show.
     *   For nested fields, use 'property.subproperty.subproperty' notation.
     *   Assign an key to label the table headers.
     * @return {String}
     */
    renderCaMap: function(ca_map, format = 'cli', fields = []) {
        if (format === 'cli') {
            let lines = [];
            ca_map.forEach((ca_entry) => {
                lines.push(` - ${ca_entry.ca['SHA-256 Fingerprint']} / ${ca_entry.ca['Owner']}  / ${ca_entry.ca['Common Name or Certificate Name']}`)
            });
            return lines.join('\n');
        }

        else if (format === 'cli-violating-rules') {
            let lines = [];
            ca_map.forEach((ca_entry) => {
                lines.push(
                    ` - ${ca_entry.ca['SHA-256 Fingerprint']} / ${ca_entry.ca['Owner']}  / ${ca_entry.ca['Common Name or Certificate Name']}\n` +
                    `   Violating: ${ca_entry.violating_rule}`);
            });
            return lines.join('\n');
        }

        else if (format === 'markdown-table') {
            let header = '|' + Object.keys(fields).join('|') + '|\n' +
                '|' + Object.keys(fields).map(n => {return '---'}).join('|') + '|';
            let lines = [];
            ca_map.forEach((ca_entry) => {
                let line = '|' + Object.keys(fields).map(label => {
                    let field_parts = fields[label].split('.');
                    let val = field_parts.reduce((a, v) => a[v], ca_entry);
                    if (val instanceof moment) {val = val.format('DD-MM-YYYY')}
                    if (typeof val === 'boolean') {val = (val) ? 'yes' : 'no'}
                    if (field_parts[field_parts.length-1] === 'SHA-256 Fingerprint') {
                        val = `[${val}](https://crt.sh/?d=${val})`
                    }
                    return val;
                }).join('|') + '|';
                lines.push(line);
            });
            return `${header}\n${lines.join('\n')}`;
        }
    },

    CaEntry: class {

        /** @type {String}*/
        'Owner' = null;

        /** @type {String} */
        'Certificate Issuer Organization' = null;

        /** @type {String} */
        'Common Name or Certificate Name' = null;

        /** @type {String} */
        'SHA-256 Fingerprint' = null;

        /** @type {Moment} */
        'Valid From [GMT]' = null;

        /** @type {Moment} */
        'Valid To [GMT]' = null;

        /** @type {String} */
        'Trust Bits' = null;

        /** @type {Moment} */
        'Distrust for TLS After Date' = null;

        /** @type {String} */
        'Geographic Focus' = null;

        /** @type {String} */
        'Mozilla Applied Constraints' = null;

        /**
         * @param {Object} entry
         * @param {boolean} assert
         *   Assert values and fail.
         */
        constructor(entry, assert = true) {
            if (assert) {
                this.assertFormat(entry);
            }

            this['Owner'] = entry['Owner'];
            this['Certificate Issuer Organization'] = entry['Certificate Issuer Organization'];
            this['Common Name or Certificate Name'] = entry['Common Name or Certificate Name'];
            this['SHA-256 Fingerprint'] = entry['SHA-256 Fingerprint'];
            this['Valid From [GMT]'] = (entry['Valid From [GMT]']) ? moment.utc(entry['Valid From [GMT]'], "YYYY.MM.DD") : null;
            this['Valid To [GMT]'] = (entry['Valid To [GMT]']) ? moment.utc(entry['Valid To [GMT]'], "YYYY.MM.DD") : null;
            this['Trust Bits'] = entry['Trust Bits'];
            this['Distrust for TLS After Date'] = (entry['Distrust for TLS After Date']) ? moment.utc(entry['Distrust for TLS After Date'], "YYYY.MM.DD") : null;
            this['Geographic Focus'] = entry['Geographic Focus'];
            this['Mozilla Applied Constraints'] = entry['Mozilla Applied Constraints'];
        }

        assertFormat(entry) {
            assert(entry['Owner'], 'Owner');
            assert(entry['Certificate Issuer Organization'], 'Certificate Issuer Organization');
            assert(entry['Common Name or Certificate Name'], 'Common Name or Certificate Name');
            assert(entry['SHA-256 Fingerprint'], 'SHA-256 Fingerprint');
            assert.match(entry['Valid From [GMT]'], /^[0-9]{4}\.[0-9]{2}\.[0-9]{2}$/, 'Valid From [GMT]');
            assert(entry['Valid To [GMT]'], 'Valid To [GMT]');
            assert(entry['Trust Bits'], 'Trust Bits');
            // assert(entry['Distrust for TLS After Date']);
            // assert(entry['Mozilla Applied Constraints']);
            assert(entry['Geographic Focus'], 'Geographic Focus');
            return entry;
        }
    },

    AssessedCaEntry: class {
        /** @type {CaEntry} */
        ca = null;

        /** @type {boolean} */
        violating = true;

        /** @type {string} */
        violating_rule = '';

        /** @type {Moment} */
        removed_date = null;

        constructor(ca, violating, violating_rule, removed_date) {
            this.ca = ca;
            this.violating = violating;
            this.violating_rule = violating_rule;

            if (violating) {
                this.removed_date = (removed_date) ? removed_date : moment();
            }
        }
    },

    MergedCaListOutput: class {
        /** @type {Map<AssessedCaEntry>} */
        result_combined = new Map();
        /** @type {Map<AssessedCaEntry>} */
        removed = new Map();
        /** @type {Map<AssessedCaEntry>} */
        added = new Map();
        /** @type {Map<AssessedCaEntry>} */
        violating = new Map();
        /** @type {Map<AssessedCaEntry>} */
        not_violating = new Map();
    },

    CertFromPem: class {
        /** @type {string} */
        pem = null;

        /** @type {Certificate} */
        certificate = null;

        constructor(pem) {
            this.certificate = Certificate.fromPEM(pem);
            this.pem = pem;
        }
    }
}
