import fs from 'fs';
import csv_parser from 'csv-parser';
import { strict as assert } from 'assert';
import moment from 'moment';

export default {

    /**
     * Assert geographical focus.
     * @param {CaEntry} entries
     */
    geographical_focus: function(entry) {
        // Geographical focus.
        let geo = entry["Geographic Focus"].split(/, |,/).map(value => {return value.toLowerCase()});
        if (geo.includes('global') || geo.includes('europe') || geo.includes('usa')) {
            // If focus is global / europe, there can be only one other country, and must be whitelisted.
            geo = geo.filter(value => {return value !== 'global' && value !== 'europe'}); // Remove global/europe before testing rest.
            if (geo.length) {
                let other = geo.pop();
                assert.match(other, /germany|netherlands|belgium|usa|uk|north america/,
                    'For EU/Global scope, other country MUST be nl/be/ge/usa/uk/north america');
            }
        } else {
            // Not global.
            assert.equal(geo[0], 'netherlands', 'For non-global, only NL allowed');
            assert.equal(geo.length, 1, 'For non-global, only 1 exclusive country allowed');
        }
    },

    /**
     * Test date validity.
     *
     * @param {CaEntry} entry
     */
    dateValidity: function(entry) {
        if (entry["Distrust for TLS After Date"]) {
            assert(entry["Distrust for TLS After Date"].isAfter(moment()), `"Distrust for TLS After Date" must be in the future`);
        }
        assert(entry["Valid From [GMT]"].isBefore(moment()), '"Valid From [GMT]" must be in the past');
        assert(entry["Valid To [GMT]"].isAfter(moment()), '"Valid To [GMT]" must be in the future');
    },

    /**
     * Assert trustbits (use for TLS, Email, ...).
     * @param {CaEntry} entry
     */
    trustBits: function(entry) {
        assert.match(entry["Trust Bits"].toLowerCase(), /.*websites.*/, 'CA must be meant for "Websites" use');
    },

    /**
     * CA cannot have constraints from Mozilla.
     * @param {CaEntry} entry
     */
    noAppliedConstraints: function(entry) {
        assert.equal(entry["Mozilla Applied Constraints"], '', 'CA must not have Mozilla applied constraints')
    },

    /**
     * Blocked CA's.
     * @param {CaEntry} entry
     */
    blockList: function(entry) {
        [
            /.*internet security research group.*/i, // Let's encrypt.
            /.*comodo.*/, // Used for lot of free SSL vendors.
        ].forEach(pattern => {
            assert.doesNotMatch(entry["Certificate Issuer Organization"].toLowerCase(),
                pattern,
                `CA must not be on the blocklist [${pattern}]`);
        });
    }
}
