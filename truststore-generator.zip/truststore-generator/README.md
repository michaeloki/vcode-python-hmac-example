# Truststore generator

This generated creates a truststore based on Mozilla's baseline,
and applies certain rules to accept or deny CA's.

Criteria for the Ideal (EU scoped and filtered) truststore are described here: https://payconiq.atlassian.net/wiki/spaces/IT/pages/1139540638/IDeal+2.0+-+CA+truststore+for+trusting+third+parties .

See the [report](/sec/truststore-generator/-/blob/master/report.md) for current status on CA's.

## Java truststore

This CI generates a PKCS#12 truststore for use with Java: `ca_bundle_generated.p12`.  
Just like the default truststore, the password is `changeit`.

**Before use, check its checksum according to `ca_bundle_generated.p12.sha256`.**

To generate it, the resulting PEM file is first converted with `keyutil-0.4.0.jar` into a JKS,  
and in turn converted into the right PKCS#12 format.

Tool used is from https://github.com/use-sparingly/keyutil/releases/download/0.4.0/keyutil-0.4.0.jar .

## CA bundle
This tool generates a filtered and compliant CA bundle in PEM format: `ca_bundle_generated.crt` .  

**Before use, check its checksum according to `ca_bundle_generated.crt.sha256`.** 

## Source of reliable CA list (not the certs themselves)

From Mozilla:
https://wiki.mozilla.org/CA/Included_Certificates  > [Included CA Certificates (CSV)](https://ccadb.my.salesforce-sites.com/mozilla/IncludedCACertificateReportCSVFormat)


The fetching of data is subject to public (TLS) key pinning.  
See `.gitlab-ci.yml` .

To change pinning, e.g. when certificate was changed,  
generate SHA256 hash of DER formatted _public key_ (not the cert itself):

```bash
export pubkey_host=ccadb.my.salesforce-sites.com
echo | openssl s_client -servername "$pubkey_host" -connect "${pubkey_host}:443" | openssl x509 -pubkey -noout | openssl pkey -pubin -outform DER | openssl dgst -sha256 -binary | base64
```


## Certificate file origin

Use Curl's mozilla parser:
https://raw.githubusercontent.com/curl/curl/master/scripts/mk-ca-bundle.pl

Get mozilla's CA list from:
```
https://hg.mozilla.org/releases/mozilla-beta/raw-file/tip/security/nss/lib/ckfw/builtins/certdata.txt
```

Execute
```bash
perl mk-ca-bundle.pl -n > ca-bundle.crt
```

