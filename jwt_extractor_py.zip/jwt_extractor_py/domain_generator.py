import pandas as pd

# Data from previous step
data = {
    'Domain Name': [
        'werofintech.com',
        'werowallet.net',
        'weroinvest.io',
        'weromoney.co',
        'werobank.finance',
        'werocrypto.tech',
        'weroblockchain.com',
        'werowallet.io',
        'weromoney.co',
        'werobank.finance',
        'wer0fintech.com',
        'wer0invest.net',
        'wer0wallet.io',
        'wer0money.co',
        'wer0bank.finance',
        'wer0crypto.tech',
        'wer0blockchain.com',
        'wer0wallet.io',
        'wer0money.co',
        'wer0bank.finance',
        'epifintech.com',
        'epipayment.net',
        'epiinvest.io',
        'epiwallet.co',
        'epimoney.finance',
        'epicrypto.tech',
        'epibank.com',
        'epiwallet.io',
        'epimoney.co',
        'epibank.finance',
        'epicompanyfintech.com',
        'epicompanypayment.net',
        'epicompanyinvest.io',
        'epicompanywallet.co',
        'epicompanymoney.finance',
        'epicompanycrypto.tech',
        'epicompanyblockchain.com',
        'epicompanywallet.io',
        'epicompanymoney.co',
        'epicompanybank.finance',
        'weroepiwallet.io',
        'wer0epicompanycrypto.tech',
        'epimoneybank.finance',
        'weroepicompanyfintech.com',
        'weroinvestcrypto.co',
        'wer0paymentblockchain.net',
        'epiwalletmoney.io',
        'epicompanybankinvest.finance',
        'weroepicompanyblockchain.com',
        'epicompanymoneybank.finance'
    ]
}

# Create DataFrame
df = pd.DataFrame(data)

# Save to Excel
df.to_excel('fintech_domain_names.xlsx', index=False)

print('Excel sheet with domain names created successfully!')