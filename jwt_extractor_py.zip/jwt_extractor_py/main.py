import jwt

# >>> encoded = jwt.encode({"some": "payload"}, "secret", algorithm="HS256")
# >>> print(encoded)
encoded = "eyJraWQiOiJpcG1iZjEiLCJ0eXAiOiJKV1QiLCJhbGciOiJFUzI1NiJ9.eyJzdWIiOiJQUk9GSUxFOmZodlVkQ00wQU53MFVLWGN6QXlCaVZnODBGRkFyRUU3IiwicmVzb3VyY2UiOiJQQUdFOlBST0ZJTEVfUkVHSVNUUkFUSU9OX1BBR0UiLCJzdWJfaW5mbyI6IlBZQ1FOTDIwQUJDIiwiaXBfYWRkcmVzcyI6IjgwLjExMi4xMTIuMTg3IiwiZXhwIjoxNzIzMjE2MzA2LCJub25jZSI6Imh5aUJ4ZzBpRHdQNlNHMjZNUEFidE5GdkIwR3E2dTk1IiwianRpIjoiNTE2NzVkN2ItYTJkZi00ZTBhLTg5MWUtMWRjYWU2MmNhMTc1IiwiYXV0aG9yaXRpZXMiOlsiUFJPRklMRV9SRUdJU1RSQVRJT05fUEFHRSJdLCJ1c2VyX2FnZW50IjoiUG9zdG1hblJ1bnRpbWUvNy4zOS4wIn0.9-T-JYZKiXUSIMVTVNPKjMdwIYa0BvwWcIC6RBts9UcCNkbkdGynmsHk0utMGDcfak8L_nJ1WUyIR-6J405l-Q"
# result = jwt.decode(encoded, "secret", algorithms=["ES256"])
# # {'some': 'payload'}
# print(result)
encoded2 = "eyJraWQiOiJpcG1iZjEiLCJ0eXAiOiJKV1QiLCJhbGciOiJFUzI1NiJ9.eyJzdWIiOiJQUk9GSUxFOjBzeFQ2dlBjRkRLM2thRU1weUVMVHl1eEx6Z2xVZ2M3IiwicmVzb3VyY2UiOiJQQUdFOlBST0ZJTEVfUkVHSVNUUkFUSU9OX1BBR0UiLCJzdWJfaW5mbyI6IlBZQ1FOTDIwQUJDIiwiaXBfYWRkcmVzcyI6IjgwLjExMi4xMTIuMTg3IiwiZXhwIjoxNzIzMjEzOTY4LCJub25jZSI6IkxuS3hDMXZjcTZDaTBqWnM2V0JaclMwTXF3QWdTMTdOIiwianRpIjoiODUzYzNkNDYtNjkwMC00ZDc4LWIxYjYtNmI1N2FkMzQzZDQxIiwiYXV0aG9yaXRpZXMiOlsiUFJPRklMRV9SRUdJU1RSQVRJT05fUEFHRSJdLCJ1c2VyX2FnZW50IjoiUG9zdG1hblJ1bnRpbWUvNy4zOS4wIn0.e9IQvsvNNOQL-HzSfafnBMxpYXFzILF3sLf6YE7ahGWC8Rw1uFz3naRibvK9V94of1DD_ksN8XTvYs4EhD04QQ"

payload = jwt.decode(encoded2, options={"verify_signature": False},)
#
# print(payload)
nonce = payload.get('nonce')
jti = payload.get('jti')

print(f"For this JWT, the jti {jti} is and the nonce is {nonce}")

# # Load your public key
# with open('public.pem', 'r') as f:
#     public_key = f.read()
#
# # Decode the JWT
# try:
#     payload = jwt.decode(encoded2, public_key, algorithms=['ES256'])
#     print(payload)
# except jwt.ExpiredSignatureError:
#     print("Signature has expired")
# except jwt.InvalidTokenError:
#     print("Invalid token")

#print(payload)
# {
#   "sub": "PROFILE:VSDpgunLS2kKTi08t0EDMKnspJ1ZpSvf",
#   "sub_info": "PYCQNL20ABC",
#   "exp": 1723211396,
#   "resource": "PAGE:PROFILE_REGISTRATION_PAGE_V2",
#   "jti": "de6e6927-6ad6-4068-954c-d3a71d2f8f85"
# }
